#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

def take_snapshot(t):
    i = 0; t = 0.001*t
    if t < 0: 
        t = -t; snapshots.append(t)
        snapshots_done.append(0)
    while i < len(snapshots):
        if t >= snapshots[i] and snapshots_done[i] == 0:
            snapshots_done[i] = 1
            j = 0
            while j < len(layers):
                fn = layers[j]+'_snap_t='+str(t)+'s.txt'
                if nsims == 1:
                    fsnap = open(outdir0+'/'+layers[j]+'/'+fn, 'w')
                else:
                    outdir = outdir0+'/output_'+fsim[isim-1]  
                    fsnap = open(outdir+'/'+layers[j]+'/'+fn, 'w')
                fsnap.write('%15s'%'ID'+'%15s'%'Model')
                fsnap.write('%10s'%'x'+'%10s'%'y'+'%15s'%'V_m')
                pn = list(modparas[0].keys())
                k = 0
                while k < len(pn):
                    fsnap.write('%20s'%pn[k])
                    k = k + 1
                fsnap.write('\r')
                k = 0
                while k < len(layernodes[j]):
                    p = tp.GetPosition((layernodes[j][k],))
                    x0 = p[0][0]; y0 = p[0][1]
                    s = nest.GetStatus((layernodes[j][k],))
                    m = s[0]['model']; m = str(m).split()[0]
                    fsnap.write('%15d'%layernodes[j][k])
                    fsnap.write('%15s'%m)
                    fsnap.write('%10.1f'%x0)
                    fsnap.write('%10.1f'%y0)
                    fsnap.write('%15.2f'%s[0]['V_m'])
                    ij = 0
                    while ij < len(modparas[0]):
                        fsnap.write('%20.5e'%s[0][pn[ij]])
                        ij = ij + 1
                    fsnap.write('\r')
                    k = k + 1
                fsnap.close()
                j = j + 1
            break
        i = i + 1
    
def data_line(s):
   dl = 0; i = 0
   while i < len(htrn):
      if htrn[i] in s:
         dl = 1; break
      i = i + 1
   return dl

def diff(first, second):
    second = set(second)
    return [item for item in first if item not in second]

def filter(x,dt,fc,ftype='bessel',btype='lowpass',poles=4,norm='mag',backwards=0):
    fn = 0.5/dt; fc = np.array(fc); Wn = fc/fn
    if ftype == 'bessel':
        fb,fa = scipy.signal.bessel(poles,btype=btype,norm=norm,Wn=Wn)
    if ftype == 'butter':
        fb,fa = scipy.signal.butter(poles,btype=btype,Wn=Wn)
    if backwards == 0:
        zi = signal.lfilter_zi(fb, fa)
        y,_ = signal.lfilter(fb, fa, x, zi=zi*x[0])
    else:    
        y = signal.filtfilt(fb, fa, x)
    return y
    
def downsample(v):
    if ftype == 'bessel': 
        v = filter(v,0.001*sdt,fc,ftype=ftype,btype=btype,poles=poles,norm=norm,backwards=backwards)
    if ftype == 'butter': 
        v = filter(v,0.001*sdt,fc,ftype=ftype,btype=btype,poles=poles,backwards=backwards)
    v = v[n0:nts:nsteps] 
    return v

def check_std(s,sd):
    if sd == 0.0:
        return 1.0
        print(s+' SD = 0!')
    else:
        return sd

def setpara(p0, v, op):
    if op == '*':
        return p0*v
    elif op == '/':
        return p0/v
    elif op == '-':
        return p0-v
    elif op == '+':
        return p0+v
    else:
        return v
        
def copyFile(src, dest):
    try:
        shutil.copy(src, dest)
    # eg. src and dest are the same file
    except shutil.Error as e:
        print('Error: %s' % e)
    # eg. source or destination doesn't exist
    except IOError as e:
        print('Error: %s' % e.strerror)
    
def nearest_spike(t, spt, i0=0):
    if len(spt) == 0: return [0, -1.0, -1.0]
    i = i0
    while i < len(spt):
        if spt[i] > t: break
        i = i + 1
    if i > 0 and i < len(spt):
        nsp = [i-1, spt[i-1], spt[i]] 
    elif i == 0:
        nsp = [0, -1.0, spt[i]] 
    else:
        nsp = [i-1, spt[i-1], -1.0]
    return nsp
    
def pooled_frates(j):    #calculate pooled firing rates
    if t >= tbreak[j] and donet[j] == 0:
        i = 0
        while i < nlayers:
            if nExcells[i] > 0:
                fr = 1000*nExsp[i]/(nExcells[i]*(t-tbreak[j-1]))
                frateEx[j].append(fr)
            else:
                frateEx[j].append(0)
            if nIncells[i] > 0:
                fr = 1000*nInsp[i]/(nIncells[i]*(t-tbreak[j-1]))
                frateIn[j].append(fr)
            else:
                frateIn[j].append(0)
            nExsp[i] = 0.0; nInsp[i] = 0.0
            i = i + 1
        donet[j] = 1  
        
def frates(j):    #calculate cellular firing rates
    if do_cell_firing_rates == 0: return
    if t >= tbreak[j] and donetf[j] == 0:
        mult = 1000/(t-tbreak[j-1]); i = 0
        #mult = 1000/simt; i = 0
        while i < nlayers:   
            fr = []; frD = []; frU = []
            if nExcells[i] > 0:
                k = 0
                while k < nExcells[i]:
                    #print('>>>',i,k)
                    fr.append(mult*nExcellsp[i][k])
                    #fr.append(nExcellsp[i][k])
                    k = k + 1
            frateExcells[j].append(fr)
            fr = []
            if nIncells[i] > 0:
                k = 0
                while k < nIncells[i]:
                    fr.append(mult*nIncellsp[i][k])
                    #fr.append(nIncellsp[i][k])
                    k = k + 1
            frateIncells[j].append(fr)
            nExcellsp[i] = []
            if i < nlayers:
                nIncellsp[i] = []
            ij = 0
            while ij < nExVm[i]:
                nExcellsp[i].append(0)
                ij = ij + 1
            ij = 0
            while ij < nInVm[i]:
                nIncellsp[i].append(0)
                ij = ij + 1
            i = i + 1
        donetf[j] = 1   
        
def save_firing_rates(ffr, ud, stats, c, ncells, fratecells, grandCrate):
  if do_cell_firing_rates == 0: return
  ffr.write(c+': ') 
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()
      ffr.write(Deltat+', ')    #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  j = 1
  if stats > 0:
      ffr.write('Layer'.ljust(17))
      while j <= nt:
          ffr.write('Mean'.ljust(17))
          ffr.write('SD'.ljust(17))
          ffr.write('CV'.ljust(17))
          ffr.write('Q25'.ljust(17))
          ffr.write('Q50'.ljust(17))
          ffr.write('Q75'.ljust(17))
          ffr.write('N'.ljust(17))
          j = j + 1
      ffr.write('\r')
  i = 0
  while i < nlayers:
      if ncells[i] > 0:
          ffr.write(layers[i].ljust(17))
          j = 1         #write mean firing rates and accumulate data for grand mean rates
          while j <= nt:
              if j == 1: cfr = open(outdir+'/'+layers[i]+'/'+layers[i]+'_'+c[0:1]+ud+'_firing_rates.txt', 'w')
              cfr.write('\r')
              Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
              cfr.write(Deltat+'   N = '+str(len(fratecells[j][i]))+'\r')
              cfr.write('Hz\r')
              k = 0
              while k < len(fratecells[j][i]):
                  cfr.write('%9.2f'%fratecells[j][i][k]+'\r')
                  k = k + 1
              if j == nt: cfr.close()
              if 'C' in layers[i]: 
                  grandCrate[j] = grandCrate[j] + fratecells[j][i]
              m = np.mean(fratecells[j][i])
              ffr.write((('%17.2f'%m).lstrip()).ljust(17))
              if stats > 0:
                  sd = np.std(fratecells[j][i])
                  q1 = np.percentile(fratecells[j][i],25.0)
                  q2 = np.percentile(fratecells[j][i],50.0)
                  q3 = np.percentile(fratecells[j][i],75.0)
                  n = len(fratecells[j][i])
                  ffr.write((('%17.2f'%sd).lstrip()).ljust(17))
                  ffr.write((('%17.2f'%(sd/m)).lstrip()).ljust(17))
                  ffr.write((('%17.2f'%q1).lstrip()).ljust(17))
                  ffr.write((('%17.2f'%q2).lstrip()).ljust(17))
                  ffr.write((('%17.2f'%q3).lstrip()).ljust(17))
                  ffr.write((('%17d'%n).lstrip()).ljust(17))
              j = j + 1
          ffr.write('\r')
      i = i + 1
  ffr.write('\r')
  
def save_grand_firing_rates(ffr, stats, layergrps, grandrates):
  if do_cell_firing_rates == 0: return
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat+', ')    #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  j = 1
  if stats > 0:
      ffr.write('Layer'.ljust(17))
      while j <= nt:
          ffr.write('Mean'.ljust(17))
          ffr.write('SD'.ljust(17))
          ffr.write('CV'.ljust(17))
          ffr.write('Q25'.ljust(17))
          ffr.write('Q50'.ljust(17))
          ffr.write('Q75'.ljust(17))
          ffr.write('N'.ljust(17))
          j = j + 1
      ffr.write('\r')
  i = 0
  while i < len(layergrps):
      ffr.write(layergrps[i].ljust(17))
      j = 1 
      while j <= nt:
          m = np.mean(grandrates[i][j])
          ffr.write((('%17.2f'%m).lstrip()).ljust(17))
          if stats > 0:
              sd = np.std(grandrates[i][j])
              q1 = np.percentile(grandrates[i][j],25.0)
              q2 = np.percentile(grandrates[i][j],50.0)
              q3 = np.percentile(grandrates[i][j],75.0)
              n = len(grandrates[i][j])
              ffr.write((('%17.2f'%sd).lstrip()).ljust(17))
              ffr.write((('%17.2f'%(sd/m)).lstrip()).ljust(17))
              ffr.write((('%17.2f'%q1).lstrip()).ljust(17))
              ffr.write((('%17.2f'%q2).lstrip()).ljust(17))
              ffr.write((('%17.2f'%q3).lstrip()).ljust(17))
              ffr.write((('%17d'%n).lstrip()).ljust(17))
          j = j + 1
      ffr.write('\r')
      i = i + 1
  ffr.write('\r')  


  