#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

simparan = []; simparav1 = []; simparav2 = []; itb = 0
paranames = []; paravalues = []; paravalues0 = []; paraop = []
fsim = []; layertext = []; modeltext = []; tbreakn = [0]
if neup_inf == 'yes':
    parafn = input_folder+'/'+state_+parafn0
else:
    parafn = state_+parafn0
if parafiles > 1 or parafiles0 > 0:
    parafn = parafn+'_'+str(parafiles0+inetsims+1)
f = open(parafn+'.txt'); l = f.readlines(); f.close()
i = 0; donet2 = 1; doneP = 0; nsims = 1
while i < len(l):
    if len(l[i].strip()) > 1:
        if 'simulations' in l[i]:
            p = l[i].split()  #number of sims
            nsims = int(p[1])
            if nsims > 1:
                j = 0
                while j < nsims:
                    fsim.append(str(j+1))
                    j = j + 1
        else:
            break
    i = i + 1
if i < len(l) and '#' not in l[i]: 
    p = l[i].split()
    if len(p) > 4: 
      j = 4
      while j < len(p):
        tbreakn.append(1000*float(p[j]))
        j = j + 1
      if tbreakn[len(tbreakn)-1] < tstop:
        tbreakn.append(tstop)
    i = i + 1; ip = 0
    while i < len(l):
        p = l[i].split()
        if len(p) == 0 or '#' in l[i]: break
        pn =  p[2].split('(')
        layertext.append(p[0])
        modeltext.append(p[1])
        simparan.append(pn[0])
        simparav1.append(float(p[3]))
        if len(p) > 4: 
          simparav2.append([])
          simparav2[ip].append(float(p[3]))
          j = 4
          while j < len(p):
            simparav2[ip].append(float(p[j]))
            j = j + 1
          if tbreakn[len(tbreakn)-1] < tstop:
            simparav2[ip].append(float(p[j-1]))
        ip = ip + 1
        i = i + 1
saveparas = 0
while i < len(l):
    if len(l[i].strip()) > 1: break
    i = i + 1
if i < len(l):
      if '#' not in l[i]: l[i] = '#   '+l[i]; saveparas = 1
      nsims = 0; paran = l[i].split(); i = i + 1
      while i < len(l) and len(l[i]) > 1:
        nsims = nsims + 1
        if saveparas == 1: l[i] = str(nsims).ljust(5)+l[i]
        p = l[i].split(); paradata = []
        fsim.append(p[0]); k = 0
        while k < len(paran)-1:                
          paradata.append(float(p[k+1]))
          k = k + 1
        paravalues.append(paradata); k = 0
        if nsims == 1:
            while k < len(paran)-1:
              pn =  paran[k+1].split('(')
              paraop.append(pn[0][len(pn[0])-1:len(pn[0])])
              paranames.append(pn[0].strip('*/-+'))
              paravalues0.append(0.0)
              k = k + 1
        i = i + 1
if saveparas > 0:
    f = open(parafn+'.txt','w'); i = 0
    while i < len(l):
        f.write(l[i])
        i = i + 1
    f.close()
saveparas = 0

synparan = []; synparav1 = []; synparav2 = []; itbs = 0
sourcelayertext = []; sourcemodeltext = []; syntransmitter = []
targetlayertext = []; targetmodeltext = []; tbreaks = [0]
if synp_inf == 'yes':
    synparafn = input_folder+'/'+state_+synparafn0
else:
    synparafn = state_+synparafn0
if synparafiles > 1 or synparafiles0 > 0:
    synparafn = synparafn+'_'+str(synparafiles0+inetsims+1)
f = open(synparafn+'.txt'); l = f.readlines(); f.close()
i = 0
while i < len(l):
    if len(l[i].strip()) > 1: break
    i = i + 1
p = l[i].split(); 
if len(p) > 7:
  j = 7
  while j < len(p):
    tbreaks.append(1000*float(p[j]))
    j = j + 1
  if tbreaks[len(tbreaks)-1] < tstop:
    tbreaks.append(tstop)
i = i + 1; ip = 0
while i < len(l):
    p = l[i].split()
    if len(p) == 0 or '#' in l[i]: break
    sourcelayertext.append(p[0])
    sourcemodeltext.append(p[1])
    targetlayertext.append(p[2])
    targetmodeltext.append(p[3])
    syntransmitter.append(p[4])
    synparan.append(p[5])
    synparav1.append(float(p[6]))
    if len(p) > 7:
      synparav2.append([])
      synparav2[ip].append(float(p[6]))
      j = 7
      while j < len(p):
        synparav2[ip].append(float(p[j]))
        j = j + 1
      if tbreaks[len(tbreaks)-1] < tstop:
        synparav2[ip].append(float(p[j-1]))
    ip = ip + 1
    i = i + 1
if store_conids == 'no' and len(synparan) > 0:
    j = 0; conids = []
    while j < len(condicts):
        ip = 0; conids.append([])
        while ip < len(synparan):
            adjcon = [0,0,0,0,0]
            if sourcelayertext[ip] == '*' or sourcelayertext[ip] in sourcenames[j]: adjcon[0] = 1
            if targetlayertext[ip] == '*' or targetlayertext[ip] in targetnames[j]: adjcon[1] = 1
            if sourcemodeltext[ip] == '*' or sourcemodeltext[ip] in sourcemodels[j]: adjcon[2] = 1
            if targetmodeltext[ip] == '*' or targetmodeltext[ip] in targetmodels[j]: adjcon[3] = 1
            if syntransmitter[ip] == '*' or syntransmitter[ip]  in transmitters[j]: adjcon[4] = 1
            if 0 not in adjcon:
                cons = nest.GetConnections(sourcenodes[j],targetnodes[j],transmitters[j])
                conids[j] = cons; break
            ip = ip + 1
        j = j + 1

#total simulation time is divided into three periods (tbreak) 
#for calculating pooled firing rates. tbreakn and tbreaks are
#for parameter changes. Data are saved after simt ms.
        
"""
if array_job_var != '' and indep_sims == 'yes':
    msdV = np.random.randint(100000,999999+1)
    pyrngs = [np.random.RandomState(s) for s in range(msdV, msdV+N_vp)]
    layer_rng = [np.random.RandomState(seed = msdV+2*N_vp+1)]
"""

simt = simt0; simdt = simdt0
time0 = time.time(); simt = int(simt/itdt)*itdt
simdt = int(simdt/itdt)*itdt; nt = 3
settle = int(settle/itdt)*itdt; dt = int(dt/itdt)*itdt
toptime = int(toptime/itdt)*itdt; nav = int(toptime/dt)
if tbreak[2] >= tbreak[3]:
    tbreak[1] = tbreak[3]/3
    tbreak[2] = 2*tbreak[3]/3
tbreak[3] = int(tbreak[3]/itdt)*itdt
tbreak[2] = int(tbreak[2]/itdt)*itdt
tbreak[1] = int(tbreak[1]/itdt)*itdt
ntn = len(tbreakn); i = 0
while i < ntn:
    tbreakn[i] = int(tbreakn[i]/itdt)*itdt
    i = i + 1
nts = len(tbreaks); i = 0
while i < nts:
    tbreaks[i] = int(tbreaks[i]/itdt)*itdt
    i = i + 1

mis = -999.0; do_cell_firing_rates = 0; nEx = nc; nIn = nc
print_time = False; nf = 0

if doTMS > 0:
    if TMSruns > 1 or netsims == 1: 
        nsims = TMSruns
    else:
        nsims = Number_of_simulations
    if nsims == 1: doTMS = -1
    if nsims > 1:
        j = 0
        while j < nsims:
            fsim.append(str(j+1))
            j = j + 1
dtTMS = 0.0
if doTMS > 0 and nsims > 1: 
    dtTMS = (toff-ton)/(nsims-1)
    nitdt = int(dtTMS/itdt)
    if np.mod(nitdt,2) > 0: nitdt = nitdt + 1
    dtTMS = nitdt*itdt
    if dtTMS > 0:
        if simt >= dtTMS: 
            simt = dtTMS
        else:
            nsimt = int(dtTMS/simt)
            if np.mod(nsimt,2) > 0: nsimt = nsimt + 1
            simt = float(int(dtTMS/nsimt))
if simdt > simt: simdt = simt
save_simt = simt; save_simdt = simdt
if saveall > 0:    #doesn't work for TM and TC
    i = 0
    while i < nlayers:
        if 'TM' not in layers[i] and 'TC' not in layers[i]: savetop.append(layers[i])
        i = i + 1

#rasters don't seem to work now but in pronciple allow
#saving of topographic data for a subset of cells    
saveallraster = 0; saverast = []
rasternels = -1   #100   <0 => rasternels = rows*cols
if saveallraster > 0:    #needs fixing
    i = 0
    while i < nlayers:
        saverast.append(layers[i])
        i = i + 1
else:                 #needs fixing
    saverast = []
    #saverast = ['LC1L4', 'LC1L56', 'LC2L4', 'LC2L56', 'LC3L4', 'LC3L56']

frateExcells = []; frateIncells = []
frateEx = []; frateIn = []
i = 0
while i <= nt:
    frateEx.append([])    #lists for pooled firing rates
    frateIn.append([])
    frateExcells.append([])    #lists for cellular firing rates
    frateIncells.append([])
    i = i + 1


nf0 = 0
if output_folder.find('/') == 0:
    outdir0 = output_folder
    try:
        os.mkdir(outdir0)
    except OSError:
        print('Output folder already exists')
    s = output_folder.split('/')
    subfolder = s[len(s)-1]
else:
    outdir0 = input_folder+'/'+output_folder
if len(sim_name) > 0:
    pnv = ''
    if len(netparan) > 0: 
        i = 0
        while i < len(netparan):
            pnv = pnv + '_'+netparan[i]+'='+str(netpara[inetsims][i])
            i = i + 1
    if output_folder.find('/') == 0:
        outdir0 = output_folder+'/'+subfolder+'_'+sim_name[inetsims]+pnv
    else:
        outdir0 = input_folder+'/'+output_folder+'_'+sim_name[inetsims]+pnv
if del_out == 'yes': 
    shutil.rmtree(outdir0, ignore_errors=True)
    os.system('rm -r '+outdir0)
os.mkdir(outdir0)
printfile = open(outdir0+'/output.txt','w')

if doTMS != 0:
    fntms = outdir0+'/TMS_times.txt'
    ftms = open(fntms, 'w')
    ftms.write('%10s'%'Time(ms)\r')
    ftms.close()
    if TMSruns == 1: nsims = 1
if nsims > 1:   #make subfolders if more than one simulation
    nz = len(str(nsims)); isim = 1
    fmt = "{:0>"+str(nz)+"d}"
    while isim <= nsims:
        outdir = outdir0+'/output_'+ fmt.format(isim)
        os.mkdir(outdir)
        i = 0    
        while i < nlayers:
          os.mkdir(outdir+'/'+layers[i])
          i = i + 1
        isim = isim + 1
else:
    i = 0    
    while i < nlayers:   
        os.mkdir(outdir0+'/'+layers[i])
        i = i + 1

user_neuron_parameters()
user_synapse_parameters()

isim = 1; outdir = outdir0 
while isim <= nsims:
  simt = save_simt
  if isim == 1:
      print('      total layers = ',nlayers,file=printfile)
      print('       total cells = ',ncells,file=printfile)
      print('    total synapses = ',ncons,file=printfile)
      print('network build time = %5.1f'%network_build_time+' s',file=printfile)
      print('\r')
      print('\r',file=printfile)
      if len(net_status) > 0:
          print('Network status after building network:')
          for keys,values in net_status[0].items():
              print(keys,values)
          print('Network status after building network:',file=printfile)
          for keys,values in net_status[0].items():
              print(keys,values,file=printfile)
          print('\r',file=printfile)
          print('\r')
          print('Network status after adding recorders and stimulators:',file=printfile)
          print('Network status after adding recorders and stimulators:')
      s0 = nest.GetStatus((0,))
      for keys,values in s0[0].items():
          print(keys,values)
      for keys,values in s0[0].items():
          print(keys,values,file=printfile)
  print('\r',file=printfile)
  print('\r')
  if nsims > 1: print('TMS run: '+str(isim))
  if nsims > 1: print('TMS run: '+str(isim),file=printfile)
  print('Network RNG seed = ',netmsd)
  print('Network RNG seed = ',netmsd,file=printfile)
  print('Other RNG seed = ',msd)
  print('Other RNG seed = ',msd,file=printfile)
  print('Simulation interval: ',simt,' ms\r')
  print('Simulation interval: ',simt,' ms',file=printfile)
  print('Initializing\r')
  print('Initializing\r',file=printfile)
  if nsims > 1: outdir = outdir0+'/output_'+ fmt.format(isim)
  if (inetsims == 0 and isim == 1) or resetnetwork > 0: nest.ResetNetwork()
  nest.SetStatus([0],{"print_time": print_time})

  f = []; fn = []; ExIsynSumcol = []; colnam = []; colsExFR = []
  colsExsp = []; colsInsp = []; fspEx = []; fspIn = []
  ExIsynSumf = []; ExIsynSumfn = []; ntop = 0; nrast = 0
  fnspEx = []; fnspIn = []; nExsp = []; nInsp = []
  nExcellsp = []; nIncellsp = []
  fntop = []; ftopout = []; ftop = []; topheader = []
  ExFRfn = []; ExFRf = []; InFRfn = []; InFRf = []; colsInFR = []
  fspExVm = []; fspInVm = []; fnth = []; fnspInVm = []
  fnspExVm = []; cbardone = np.zeros((nlayers,3))
  rastheader = []; frast = []; fnrast = []; donet = [0,0,0,0]
  donetf = [0,0,0,0]; minicount = []; minirate = []
  
  frateExcells = []; frateIncells = []
  frateIn = []; frateEx = []; i = 0
  while i <= nt:
    frateEx.append([])    #lists for firing rates
    frateIn.append([])
    frateExcells.append([])    #lists for cellular firing rates
    frateIncells.append([])
    i = i + 1
  TMSdone = 1; tTMS = ton
  if doTMS == 1: 
      if TMSruns > 1 or netsims == 1:
          tTMS = tTMS + (isim-1)*dtTMS
          if isim > 1: savetop = []
      elif len(netparan) == 0:
          if array_job_id == None:
              tTMS = tTMS + inetsims*dtTMS
              if inetsims > 1: savetop = []
          else:
              tTMS = tTMS + (netsims-1)*dtTMS
              if netsims > 1: savetop = []
  if doTMS != 0:
    if TMSpulse > 0:
          tpulse = settle+tTMS-1.0; TMSdur = 1.0
          i = 0
          while i < len(tms_exsg):
              nest.SetStatus(tms_exsg[i], {'amplitude_times': [tpulse, tpulse+TMSdur], 'amplitude_values': [TMSpulse, 0.0]})
              i = i + 1
          i = 0
          while i < len(tms_insg):
              nest.SetStatus(tms_insg[i], {'amplitude_times': [tpulse, tpulse+TMSdur], 'amplitude_values': [TMSpulse, 0.0]})
              i = i + 1
    TMSdone = 0
      
  #for each layer:
  i = 0    
  while i < nlayers:
      nln = len(layernodes[i])
      
      ip = 0
      while ip < len(simparan):
          if 'T' in layers[i] and simparan[ip] == 'TEx_bomb_rate':
              nest.SetStatus(Ex_bomb_pg[i], {'rate': simparav1[ip]})
          if ('LC' in layers[i] or 'RC' in layers[i]) and simparan[ip] == 'CEx_bomb_rate':
              nest.SetStatus(Ex_bomb_pg[i], {'rate': simparav1[ip]})
          if ('LR' in layers[i] or 'LR' in layers[i]) and simparan[ip] == 'Ret_bomb_rate':
              nest.SetStatus(In_bomb_pg[i], {'rate': simparav1[ip]})
          if 'T' in layers[i] and simparan[ip] == 'TIn_bomb_rate':
              nest.SetStatus(In_bomb_pg[i], {'rate': simparav1[ip]})
          if ('LC' in layers[i] or 'RC' in layers[i]) and simparan[ip] == 'CIn_bomb_rate':
              nest.SetStatus(In_bomb_pg[i], {'rate': simparav1[ip]})
          ip = ip + 1    
              
      #randomize the inital Vm and set parameter values (if different from defaults)
      if (inetsims == 0 and isim == 1) or resetnetwork > 0: 
          node_info   = nest.GetStatus(layernodes[i])
          local_nodes = [(ni['global_id'], ni['vp']) for ni in node_info if ni['local']]
          for gid,vp in local_nodes:
              nest.SetStatus([gid], {'V_m': pyrngs[vp].triangular(popVmin,mode,popVmax)})
      if len(gCV) > 0 and layers[i] in model_gs_layers:
          j = 0
          while j < nln:
              ln = layernodes[i][j]
              status = nest.GetStatus((ln,))
              s = str(status[0]['model'])
              if s in model_gs_models:
                  vp = status[0]['vp']; ip = 0
                  while ip < len(model_gs):
                      mu_g = status[0][model_gs[ip]]
                      if len(gCV) == 1:
                          gCVval = gCV[0]
                      else:
                          gCVval = gCV[ip]
                      if mu_g != 0:
                          if g_distrib == 'normal':
                              g = pyrng0[vp].normal(mu_g,gCVval*mu_g,1)
                          else:
                              gmin = mu_g*(1-gCVval); gmax = mu_g*(1+gCVval)
                              g = pyrng0[vp].triangular(gmin,mu_g,gmax)
                          if len(min_max_g) > 0:
                              if mu_g > 0 and g[0] < min_max_g[ip]: g[0] = min_max_g[ip]
                              if mu_g < 0 and g[0] > min_max_g[ip]: g[0] = min_max_g[ip]
                          nest.SetStatus((ln,), {model_gs[ip]: g[0]})
                      ip = ip + 1
              j = j + 1
      if len(simparan) > 0 or len(paranames) > 0:
          j = 0
          while j < nln:
              status = nest.GetStatus((layernodes[i][j],))
              ip = 0
              while ip < len(simparan):
                  if layertext[ip] in layers[i] or layertext[ip] == '*':
                      setburster = 0
                      if 'IB' in modeltext[ip]:
                          ib = 0
                          while ib < len(L56IB):
                              if layernodes[i][j] in L56IB[ib]:
                                  if len(L56IBnd) == 0: 
                                      setburster = 1
                                      break
                                  elif len(L56IBnd) > 0 and layernodes[i][j] not in L56IBnd[ib]:
                                      setburster = 1
                                      break
                              ib = ib + 1
                      if 'ND' in modeltext[ip]:
                          ib = 0
                          while ib < len(L56IBnd):
                              if layernodes[i][j] in L56IBnd[ib]: 
                                  setburster = 1
                                  break
                              ib = ib + 1
                      if modeltext[ip] in str(status[0]['model']) or modeltext[ip] == '*' or setburster == 1:
                          if simparan[ip] in str(status):
                              nest.SetStatus((layernodes[i][j],),{simparan[ip]: simparav1[ip]})
                  ip = ip + 1
              ip = 0
              while ip < len(paranames):
                  if paranames[ip] in str(status):
                      if isim == 1: paravalues0[ip] = status[0][paranames[ip]] 
                      nest.SetStatus((layernodes[i][j],),{paranames[ip]: setpara(paravalues0[ip], paravalues[isim-1][ip], paraop[ip])})
                  ip = ip + 1
              j = j + 1
        
      #initialise some lists
      nExsp.append(0); nInsp.append(0)
      nExcellsp.append([]); nIncellsp.append([])
      j = 0
      while j < nExVm[i]:
          nExcellsp[i].append(0)
          j = j + 1
      j = 0
      while j < nInVm[i]:
          nIncellsp[i].append(0)
          j = j + 1
      j = 0; snapshots_done = []
      while j < len(snapshots):
          snapshots_done.append(0)
          j = j + 1
          
      #files for time series
      j = 0; f.append([]); fn.append([])
      while j < len(dosave):
          fname = outdir+'/'+layers[i]+'/'+layers[i]+'_'+dosave[j]+'.txt'
          fout = open(fname, 'w')
          fn[i].append(fname)
          f[i].append(fout)
          j = j + 1
      ExFRfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_ExFR.txt')
      fout = open(ExFRfn[i], 'w')
      ExFRf.append(fout)
      colsExFR.append(0)
      InFRfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_InFR.txt')
      fout = open(InFRfn[i], 'w')
      InFRf.append(fout)
      colsInFR.append(0)
      ExIsynSumfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_ExIsynSum.txt')
      fout = open(ExIsynSumfn[i], 'w')
      ExIsynSumf.append(fout)
      ExIsynSumcol.append(0)
      colnam.append([]); ijk = 0
      while ijk < len(dosave):
        colnam[i].append(0)
        ijk = ijk + 1
      
      j = 0   #files for topographic data
      while j < len(savetop):
          if savetop[j] == layers[i]:
            fname = outdir+'/'+layers[i]+'/'+layers[i]
            fntop.append(fname)
            ftop.append([]); topheader.append([])
            ijk = 0
            while ijk < len(dotop):
                if dotop[ijk] in record:
                    ftopout = open(fname+'_'+dotop[ijk]+'_top.txt', 'w')
                    ftop[ntop].append(ftopout)
                    topheader[ntop].append(0)
                ijk = ijk + 1
            ntop = ntop + 1
          j = j + 1
   
      j = 0   #files for raster data - doesn't seem to work
      while j < len(saverast):
          if saverast[j] == layers[i]:
            fname = outdir+'/'+layers[i]+'/'+layers[i]
            fnrast.append(fname)
            frast[nrast] = []; rastheader.append(0)
            ijk = 0
            while ijk < len(dotop):
                if dotop[ijk] in record:
                  frastout = open(fname+'_'+dotop[ijk]+'_raster.txt', 'w')
                  frast[nrast].append(frastout)
                ijk = ijk + 1
            nrast = nrast + 1
          j = j + 1
          
      #Set up spike and down/up files, initialize nExsp and nInsp          
      fnspEx.append(outdir+'/'+layers[i]+'/'+layers[i]+'_Ex_sp.txt')
      if saveallspikes > 0: fout = open(fnspEx[i], 'w')  #if saving all spike times for all Ex cells (a lot of data)
      fspEx.append(fout)
      fnspExVm.append(outdir+'/'+layers[i]+'/'+layers[i]+'_Ex_Vm_sp.txt')
      fout = open(fnspExVm[i], 'w')   #otherwise just save spike times for the cells selected for Vm saving
      fspExVm.append(fout)
      colsExsp.append(0)
      nExsp.append(0);

      #similarly for inhibitory neurons
      fnspIn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_In_sp.txt')
      if saveallspikes > 0: fout = open(fnspIn[i], 'w')
      fspIn.append(fout)
      fnspInVm.append(outdir+'/'+layers[i]+'/'+layers[i]+'_In_Vm_sp.txt')
      fout = open(fnspInVm[i], 'w')
      fspInVm.append(fout)
      colsInsp.append(0)
      nInsp.append(0)

      i = i + 1

                     
  #adjust connection properties
  if len(synparan) > 0:
    j = 0
    while j < len(condicts):
      ip = 0 
      while ip < len(synparan):
          adjcon = [0,0,0,0,0]
          if sourcelayertext[ip] == '*' or sourcelayertext[ip] in sourcenames[j]: adjcon[0] = 1
          if targetlayertext[ip] == '*' or targetlayertext[ip] in targetnames[j]: adjcon[1] = 1
          if sourcemodeltext[ip] == '*' or sourcemodeltext[ip] in sourcemodels[j]: adjcon[2] = 1
          if targetmodeltext[ip] == '*' or targetmodeltext[ip] in targetmodels[j]: adjcon[3] = 1
          if syntransmitter[ip] == '*' or syntransmitter[ip]  in transmitters[j]: adjcon[4] = 1
          if 0 not in adjcon: 
              nest.SetStatus(conids[j],{synparan[ip]: synparav1[ip]})              
          ip = ip + 1
      j = j + 1
      
  #settling time
  if settle > 0.0 and ((inetsims == 0 and isim == 1) or resetnetwork > 0):
      if settle < simt: settle = simt
      nsettle = int(settle/simt)
      settle = nsettle*simt
      print ('%g'%settle+' ms settling time\r')
      print ('%g'%settle+' ms settling time\r',file=printfile)
      if zero_gsyn  == 1:
          gampa0 = []; gnmda0 = []; ggabaa0 = []; ggabab0 = []
          i = 0
          while i < nlayers:
              gampa0.append([])
              gnmda0.append([])
              ggabaa0.append([])
              ggabab0.append([])
              j = 0   
              while j < len(layernodes[i]):
                  s = nest.GetStatus((layernodes[i][j],))
                  gampa0[i].append(s[0]['g_peak_AMPA'])
                  gnmda0[i].append(s[0]['g_peak_NMDA'])
                  ggabaa0[i].append(s[0]['g_peak_GABA_A'])
                  ggabab0[i].append(s[0]['g_peak_GABA_B'])
                  nest.SetStatus((layernodes[i][j],), {
                  'g_peak_AMPA': 0.0, 'g_peak_NMDA': 0.0, 
                  'g_peak_GABA_A': 0.0, 'g_peak_GABA_B': 0.0})
                  j = j + 1
              i = i + 1
      ij = 0
      while ij < nsettle:
          nest.Simulate(simt)
          i = 0
          while i < nlayers:
              nest.SetStatus(ExVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(Ex_spikes[i],{'n_events': 0})      #clear list for next simulation interval
              nest.SetStatus(InVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(In_spikes[i],{'n_events': 0})      #clear list for next simulation interval
              i = i + 1 
          nest.SetStatus(sample_times,{'n_events': 0})
          ij = ij + 1
      if zero_gsyn  == 1:
          i = 0
          while i < nlayers:
              j = 0   
              while j < len(layernodes[i]):
                  nest.SetStatus((layernodes[i][j],), {
                  'g_peak_AMPA': gampa0[i][j], 'g_peak_NMDA': gnmda0[i][j], 
                  'g_peak_GABA_A': ggabaa0[i][j], 'g_peak_GABA_B': ggabab0[i][j]})
                  j = j + 1
              i = i + 1

  #start simulation
  print ('Starting simulation\r')
  print ('Starting simulation\r',file=printfile)
  t0 = nest.GetStatus((0,),'time')[0]; t = 0.0  
  print('Start time = ',0.001*t0,' s')
  print('\r')
  print('Start time = ',0.001*t0,' s',file=printfile)
  print('\r',file=printfile,flush=True)
  while t < tstop:
      if tstop-t < simt: simt = tstop-t
      simtime0 = time.time()
      tsave = t + simt; simdt = save_simdt
      while t < tsave:
          if tsave-t < simdt: simdt = tsave-t
          if len(snapshots) > 0: take_snapshot(t)
          user_models()
          nest.Simulate(simdt)
          t = t + simdt
          if len(snapshots) > 0: take_snapshot(t)
      #print('Literal '+str(simt)+' ms run time = '+'%5.1f'%(time.time()-simtime0)+' s')
      #print('Literal '+str(simt)+' ms run time = '+'%5.1f'%(time.time()-simtime0)+' s',file=printfile)
      dmm = nest.GetStatus(sample_times)
      ts = dmm[0]["events"]["times"]
      nest.SetStatus(sample_times,{'n_events': 0})
      ts = ts - t0; nts = len(ts)
      user_analysis()             
      if antialias == 'yes': ts = ts[n0:nts:nsteps] #downsample
          
      i = 0                      #for each layer
      while i < nlayers:
          if 'LC1' in layers[i]: iarea = 0
          if 'LC2' in layers[i]: iarea = 1
          if 'LC3' in layers[i]: iarea = 2
          if 'RC1' in layers[i]: iarea = 3
          if 'RC2' in layers[i]: iarea = 4
          if 'RC3' in layers[i]: iarea = 5
          #setup for topographic and raster plots
          xtop = np.arange((cols[i]+1))
          ytop = np.arange((rows[i]),-1,-1)
          nmods = len(elements[i])
          trp = np.zeros((2))
          layernels = rows[i]*cols[i]
          if rasternels > layernels or rasternels < 0:
              r1 = 1; r2 = rows[i]
              c1 = 1; c2 = cols[i]
              nels = layernels
          else:
              rc = np.sqrt(rasternels)
              r1 = int(0.5*(rows[i] - rc)) + 1
              r2 = int(r1 + rc - 1)
              c1 = r1; c2 = r2
              nels = rasternels
          yp = np.arange(nels,-1,-1); 
          zp = np.zeros((nmods,1,nels))
          ijk = 0; zav = []
          while ijk < len(dotop):
              zav.append(np.zeros((nmods,rows[i],cols[i])))
              ijk = ijk + 1
          
          #collect time series and spike time data
          Ex_iampa = []; Ex_inmda = []; Ex_igabaa = []; Ex_igabab = []
          allgampa = []; allgnmda = []; allggabaa = []; allggabab = []
          allinap = []; allikna = []; allih = []; allit = []
          cEx_Vm = []; cEx_theta = []; cIn_Vm = []; cIn_theta = []
          cEx_gampa = []; cEx_gnmda = []; cIn_gampa = []; cIn_gnmda = []
          cEx_ggabaa = []; cEx_ggabab = []; cIn_ggabaa = []; cIn_ggabab = []
          cEx_inap = []; cEx_ikna = []; cIn_inap = []; cIn_ikna = []
          cEx_ih = []; cEx_it = []; cIn_ih = []; cIn_it = []
          allVm = []; Ex_Vm = []; Ex_spiket = []; Ex_spikeid = []
          all = []; In_Vm = []; In_spiket = []; In_spikeid = []
          Ex_gampa = []; Ex_gnmda = []; Ex_ggabaa = []; Ex_ggabab = []
          Ex_inap = []; Ex_ikna = []; Ex_ih = []; Ex_it = []
          In_gampa = []; In_gnmda = []; In_ggabaa = []; In_ggabab = []
          In_inap = []; In_ikna = []; In_ih = []; In_it = []
          Ex_theta = []; In_theta = []; alltheta = [] 

          if nExVm[i] > 0:
              cd = nest.GetStatus(ExVm[i])
              idi = np.argsort(cd[0]["events"]["senders"])
              gid = cd[0]["events"]["senders"][idi]
              Vmi = cd[0]["events"]["V_m"][idi]
              gampai = cd[0]["events"]["g_AMPA"][idi]
              gnmdai = cd[0]["events"]["g_NMDA"][idi]
              ggabaai = cd[0]["events"]["g_GABA_A"][idi]
              ggababi = cd[0]["events"]["g_GABA_B"][idi]
              if 'I_NaP' in dosave: inapi = -cd[0]["events"]["I_NaP"][idi]
              if 'I_KNa' in dosave: iknai = -cd[0]["events"]["I_KNa"][idi]
              if 'I_h' in dosave: ihi = -cd[0]["events"]["I_h"][idi]
              if 'I_T' in dosave: iti = -cd[0]["events"]["I_T"][idi]
              if 'theta' in dosave: thetai = cd[0]["events"]["theta"][idi]
              tsi = cd[0]["events"]["times"][idi]
              e = nest.GetStatus((gid[0],))
              E_rev_AMPA = e[0]['E_rev_AMPA']
              E_rev_NMDA = e[0]['E_rev_NMDA']
              E_rev_GABA_A = e[0]['E_rev_GABA_A']
              E_rev_GABA_B = e[0]['E_rev_GABA_B']
              j = 0; ij = 0; ii = 0; Ex_cells = []
              while ij < nExVm[i]:
                  tsj = np.argsort(tsi[j:j+nts])
                  Vmj = Vmi[j:j+nts][tsj]
                  if antialias == 'yes': Vmj = downsample(Vmj)
                  allVm.append(Vmj); Ex_Vm.append(Vmj)
                  gampaj = gampai[j:j+nts][tsj]
                  if antialias == 'yes': gampaj = downsample(gampaj)
                  if 'g_AMPA' in dosave: allgampa.append(gampaj); Ex_gampa.append(gampaj)
                  gnmdaj = gnmdai[j:j+nts][tsj]
                  if antialias == 'yes': gnmdaj = downsample(gnmdaj)
                  if 'g_NMDA' in dosave: allgnmda.append(gnmdaj); Ex_gnmda.append(gnmdaj)
                  ggabaaj = ggabaai[j:j+nts][tsj]
                  if antialias == 'yes': ggabaaj = downsample(ggabaaj)
                  if 'g_GABA_A' in dosave: allggabaa.append(ggabaaj); Ex_ggabaa.append(ggabaaj)
                  ggababj = ggababi[j:j+nts][tsj]
                  if antialias == 'yes': ggababj = downsample(ggababj)
                  if 'g_GABA_B' in dosave: allggabab.append(ggababj); Ex_ggabab.append(ggababj)
                  if 'I_NaP' in dosave:
                      inapj = inapi[j:j+nts][tsj]
                      if antialias == 'yes': inapj = downsample(inapj)
                      allinap.append(inapj); Ex_inap.append(inapj)
                  if 'I_KNa' in dosave:
                      iknaj = iknai[j:j+nts][tsj]
                      if antialias == 'yes': iknaj = downsample(iknaj)
                      allikna.append(iknaj); Ex_ikna.append(iknaj)
                  if 'I_h' in dosave:
                      ihj = ihi[j:j+nts][tsj]
                      if antialias == 'yes': ihj = downsample(ihj)
                      allih.append(ihj); Ex_ih.append(ihj)
                  if 'I_T' in dosave:
                      itj = iti[j:j+nts][tsj]
                      if antialias == 'yes': itj = downsample(itj)
                      allit.append(itj); Ex_it.append(itj)
                  if 'theta' in dosave: 
                      thetaj = thetai[j:j+nts][tsj]
                      if antialias == 'yes': thetaj = downsample(thetaj)
                      alltheta.append(thetaj); Ex_theta.append(thetaj)
                  iampa = gampaj*(Vmj-E_rev_AMPA)
                  inmda = gnmdaj*(Vmj-E_rev_NMDA)
                  igabaa = ggabaaj*(Vmj-E_rev_GABA_A)
                  igabab = ggababj*(Vmj-E_rev_GABA_B)
                  Ex_iampa.append(iampa); Ex_inmda.append(inmda)
                  Ex_igabaa.append(igabaa); Ex_igabab.append(igabab)
                  if ii < len(cEx[i]) and gid[j] == cEx[i][ii]:
                      cEx_Vm.append(Vmj); Ex_cells.append(cEx[i][ii])
                      if 'g_AMPA' in dosave: cEx_gampa.append(gampaj)
                      if 'g_NMDA' in dosave: cEx_gnmda.append(gnmdaj)
                      if 'g_GABA_A' in dosave: cEx_ggabaa.append(ggabaaj)
                      if 'g_GABA_B' in dosave: cEx_ggabab.append(ggababj)
                      if 'I_NaP' in dosave: cEx_inap.append(inapj)
                      if 'I_KNa' in dosave: cEx_ikna.append(iknaj)
                      if 'I_h' in dosave: cEx_ih.append(ihj)
                      if 'I_T' in dosave: cEx_it.append(itj)
                      if 'theta' in dosave: cEx_theta.append(thetaj)
                      ii = ii + 1
                  j = j + nts
                  ij = ij + 1
              dsd = nest.GetStatus(Ex_spikes[i])
              Ex_spikeid =  dsd[0]["events"]["senders"].tolist()
              Ex_spiket = dsd[0]["events"]["times"].tolist()
              nest.SetStatus(ExVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(Ex_spikes[i],{'n_events': 0})      #clear list for next simulation interval

          if nInVm[i] > 0:
              cd = nest.GetStatus(InVm[i])
              idi = np.argsort(cd[0]["events"]["senders"])
              gid = cd[0]["events"]["senders"][idi]
              Vmi = cd[0]["events"]["V_m"][idi]
              if 'g_AMPA' in dosave: gampai = cd[0]["events"]["g_AMPA"][idi]
              if 'g_NMDA' in dosave: gnmdai = cd[0]["events"]["g_NMDA"][idi]
              if 'g_GABA_A' in dosave: ggabaai = cd[0]["events"]["g_GABA_A"][idi]
              if 'g_GABA_B' in dosave: ggababi = cd[0]["events"]["g_GABA_B"][idi]
              if 'I_NaP' in dosave: inapi = -cd[0]["events"]["I_NaP"][idi]
              if 'I_KNa' in dosave: iknai = -cd[0]["events"]["I_KNa"][idi]
              if 'I_h' in dosave: ihi = -cd[0]["events"]["I_h"][idi]
              if 'I_T' in dosave: iti = -cd[0]["events"]["I_T"][idi]
              if 'theta' in dosave: thetai = cd[0]["events"]["theta"][idi]
              tsi = cd[0]["events"]["times"][idi]
              j = 0; ij = 0; ii = 0; In_cells = []
              while ij < nInVm[i]:
                  tsj = np.argsort(tsi[j:j+nts])
                  Vmj = Vmi[j:j+nts][tsj]
                  if antialias == 'yes': Vmj = downsample(Vmj)
                  allVm.append(Vmj); In_Vm.append(Vmj)
                  if 'g_AMPA' in dosave: 
                      gampaj = gampai[j:j+nts][tsj]
                      if antialias == 'yes': gampaj = downsample(gampaj)
                      allgampa.append(gampaj); In_gampa.append(gampaj)
                  if 'g_NMDA' in dosave: 
                      gnmdaj = gnmdai[j:j+nts][tsj]
                      if antialias == 'yes': gnmdaj = downsample(gnmdaj)
                      allgnmda.append(gnmdaj); In_gnmda.append(gnmdaj)
                  if 'g_GABA_A' in dosave: 
                      ggabaaj = ggabaai[j:j+nts][tsj]
                      if antialias == 'yes': ggabaaj = downsample(ggabaaj)
                      allggabaa.append(ggabaaj); In_ggabaa.append(ggabaaj)
                  if 'g_GABA_B' in dosave: 
                      ggababj = ggababi[j:j+nts][tsj]
                      if antialias == 'yes': ggababj = downsample(ggababj)
                      allggabab.append(ggababj); In_ggabab.append(ggababj)
                  if 'I_NaP' in dosave:
                      inapj = inapi[j:j+nts][tsj]
                      if antialias == 'yes': inapj = downsample(inapj)
                      allinap.append(inapj); In_inap.append(inapj)
                  if 'I_KNa' in dosave:
                      iknaj = iknai[j:j+nts][tsj]
                      if antialias == 'yes': iknaj = downsample(iknaj)
                      allikna.append(iknaj); In_ikna.append(iknaj)
                  if 'I_h' in dosave:
                      ihj = ihi[j:j+nts][tsj]
                      if antialias == 'yes': ihj = downsample(ihj)
                      allih.append(ihj); In_ih.append(ihj)
                  if 'I_T' in dosave:
                      itj = iti[j:j+nts][tsj]
                      if antialias == 'yes': itj = downsample(itj)
                      allit.append(itj); In_it.append(itj)
                  if 'theta' in dosave: 
                      thetaj = thetai[j:j+nts][tsj]
                      if antialias == 'yes': thetaj = downsample(thetaj)
                      alltheta.append(thetaj); In_theta.append(thetaj)
                  if ii < len(cIn[i]) and gid[j] == cIn[i][ii]:
                      cIn_Vm.append(Vmj); In_cells.append(cIn[i][ii])
                      if 'g_AMPA' in dosave: cIn_gampa.append(gampaj)
                      if 'g_NMDA' in dosave: cIn_gnmda.append(gnmdaj)
                      if 'g_GABA_A' in dosave: cIn_ggabaa.append(ggabaaj)
                      if 'g_GABA_B' in dosave: cIn_ggabab.append(ggababj)
                      if 'I_NaP' in dosave: cIn_inap.append(inapj)
                      if 'I_KNa' in dosave: cIn_ikna.append(iknaj)
                      if 'I_h' in dosave: cIn_ih.append(ihj)
                      if 'I_T' in dosave: cIn_it.append(itj)
                      if 'theta' in dosave: cIn_theta.append(thetaj)
                      ii = ii + 1
                  j = j + nts
                  ij = ij + 1
              dsd = nest.GetStatus(In_spikes[i])
              In_spikeid =  dsd[0]["events"]["senders"].tolist()
              In_spiket = dsd[0]["events"]["times"].tolist()
              nest.SetStatus(InVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(In_spikes[i],{'n_events': 0})      #clear list for next simulation interval

          #now save the data
          j = 0; n = len(ts); nf = nf0; iav = 0
          while j < n:
              iav = iav + 1; trp[0] = ts[j]; trp[1] = ts[j] 
              if iav == 1: tav0 = ts[j]; nf = nf + 1
              ijk = 0
              while ijk < len(dosave):
                  if dosave[ijk] == 'V_m': 
                          Ex_data = Ex_Vm
                          In_data = In_Vm
                          cEx_data = cEx_Vm
                          cIn_data = cIn_Vm
                          units = '(mV)'
                  if dosave[ijk] == 'g_AMPA': 
                          Ex_data = Ex_gampa
                          In_data = In_gampa
                          cEx_data = cEx_gampa
                          cIn_data = cIn_gampa
                          units = ''
                  if dosave[ijk] == 'g_NMDA': 
                          Ex_data = Ex_gnmda
                          In_data = In_gnmda
                          cEx_data = cEx_gnmda
                          cIn_data = cIn_gnmda
                          units = ''
                  if dosave[ijk] == 'g_GABA_A': 
                          Ex_data = Ex_ggabaa
                          In_data = In_ggabaa
                          cEx_data = cEx_ggabaa
                          cIn_data = cIn_ggabaa
                          units = ''
                  if dosave[ijk] == 'g_GABA_B': 
                          Ex_data = Ex_ggabab
                          In_data = In_ggabab
                          cEx_data = cEx_ggabab
                          cIn_data = cIn_ggabab
                          units = ''
                  if dosave[ijk] == 'I_NaP': 
                          Ex_data = Ex_inap
                          In_data = In_inap
                          cEx_data = cEx_inap
                          cIn_data = cIn_inap
                          units = '(mV)'
                  if dosave[ijk] == 'I_KNa': 
                          Ex_data = Ex_ikna
                          In_data = In_ikna
                          cEx_data = cEx_ikna
                          cIn_data = cIn_ikna
                          units = '(mV)'
                  if dosave[ijk] == 'I_h': 
                          Ex_data = Ex_ih
                          In_data = In_ih
                          cEx_data = cEx_ih
                          cIn_data = cIn_ih
                          units = '(mV)'
                  if dosave[ijk] == 'I_T': 
                          Ex_data = Ex_it
                          In_data = In_it
                          cEx_data = cEx_it
                          cIn_data = cIn_it
                          units = '(mV)'
                  if dosave[ijk] == 'theta': 
                          Ex_data = Ex_theta
                          In_data = In_theta
                          cEx_data = cEx_theta
                          cIn_data = cIn_theta
                          units = '(mV)'
                  nam = dosave[ijk].replace('_','')
                  if colnam[i][ijk] == 0:   #column headings not written yet so do so now
                      s = '%15s'%'time(ms)'
                      if dispersion_measure == 'sd':
                          s = s + '%15s'%(nam+units) + '%15s'%('SD('+nam+')')
                          if nExVm[i] > 0: s = s + '%15s'%('Ex_'+nam+units) + '%15s'%('SD(Ex_'+nam+')')
                          if nInVm[i] > 0: s = s + '%15s'%('In_'+nam+units) + '%15s'%('SD(In_'+nam+')')
                      else:
                          s = s + '%15s'%(nam+units) + '%15s'%('Q1('+nam+')') + '%15s'%('Q3('+nam+')')
                          if nExVm[i] > 0: s = s + '%15s'%('Ex_'+nam+units) + '%15s'%('Q1(Ex_'+nam+')') + '%15s'%('Q3(Ex_'+nam+')')
                          if nInVm[i] > 0: s = s + '%15s'%('In_'+nam+units) + '%15s'%('Q1(In_'+nam+')') + '%15s'%('Q3(In_'+nam+')')
                      if nExVm[i] > 0:
                          k = 0
                          while k < nEx:
                              if 'L56' in layers[i] and L56_burster_frac > 0 and Ex_cells[k] in cIBs[iarea]:
                                  s = s + '%15s'%('IB'+str(Ex_cells[k])+units)     #ids of chosen Exc cells
                              elif 'L56' in layers[i] and L56_burster_frac_nd > 0 and Ex_cells[k] in cIBnds[iarea]:
                                  s = s + '%15s'%('ND'+str(Ex_cells[k])+units)     #ids of chosen Exc cells
                              else:
                                  s = s + '%15s'%('Ex'+str(Ex_cells[k])+units)     #ids of chosen Exc cells
                              k = k + 1
                      if nInVm[i] > 0:
                          k = 0
                          while k < nIn:
                              s = s + '%15s'%('In'+str(In_cells[k])+units)     #ids of chosen Inh cells
                              k = k + 1
                      f[i][ijk].write(s+'\r')
                      colnam[i][ijk] = 1   #column headings now written
                  s = '%15.2f'%ts[j]
                  Exdata = []; Indata = []; Alldata = []
                  if nExVm[i] > 0:
                      k = 0
                      while k < nExVm[i]:
                          Alldata.append(Ex_data[k][j])
                          Exdata.append(Ex_data[k][j])
                          k = k + 1
                      if location_measure == 'median':
                          medExdata = np.median(Exdata)
                      else:
                          meanExdata = np.mean(Exdata)
                      if dispersion_measure == 'sd':
                          sdExdata = np.std(Exdata)
                      else:
                          ExQ1 = np.percentile(Exdata, 25, interpolation = 'midpoint')
                          ExQ3 = np.percentile(Exdata, 75, interpolation = 'midpoint')
                  if nInVm[i] > 0:
                      k = 0
                      while k < nInVm[i]:
                          Alldata.append(In_data[k][j])
                          Indata.append(In_data[k][j])
                          k = k + 1
                      if location_measure == 'median':
                          medIndata = np.median(Indata)
                      else:
                          meanIndata = np.mean(Indata)
                      if dispersion_measure == 'sd':
                          sdIndata = np.std(Indata)
                      else:
                          InQ1 = np.percentile(Indata, 25, interpolation = 'midpoint')
                          InQ3 = np.percentile(Indata, 75, interpolation = 'midpoint')                          
                  if location_measure == 'median':
                      medAlldata = np.median(Alldata)
                  else:
                      meanAlldata = np.mean(Alldata)
                  if dispersion_measure == 'sd':
                      sdAlldata = np.std(Alldata)
                  else:
                      AllQ1 = np.percentile(Alldata, 25, interpolation = 'midpoint')
                      AllQ3 = np.percentile(Alldata, 75, interpolation = 'midpoint')                          
                  if location_measure == 'median':
                      s = s + '%15.5e'%medAlldata
                  else:
                      s = s + '%15.5e'%meanAlldata
                  if dispersion_measure == 'sd':
                      s = s + '%15.5e'%sdAlldata
                  else:
                      s = s + '%15.5e'%AllQ1 + '%15.5e'%AllQ3
                  if nExVm[i] > 0: 
                      if location_measure == 'median':
                          s = s + '%15.5e'%medExdata
                      else:
                          s = s + '%15.5e'%meanExdata
                      if dispersion_measure == 'sd':
                          s = s + '%15.5e'%sdExdata
                      else:
                          s = s + '%15.5e'%ExQ1 + '%15.5e'%ExQ3
                  if nInVm[i] > 0:
                      if location_measure == 'median':
                          s = s + '%15.5e'%medIndata
                      else:
                          s = s + '%15.5e'%meanIndata
                      if dispersion_measure == 'sd':
                          s = s + '%15.5e'%sdIndata
                      else:
                          s = s + '%15.5e'%InQ1 + '%15.5e'%InQ3
                  if nExVm[i] > 0:
                      k = 0
                      while k < nEx:
                          s = s + '%15.5e'%cEx_data[k][j]    #data for chosen Exc cells
                          k = k + 1
                  if nInVm[i] > 0:                   #similarly for In
                      k = 0
                      while k < nIn:
                          s = s + '%15.5e'%cIn_data[k][j]    #Vm for chosen Inh cells
                          k = k + 1
                  f[i][ijk].write(s+'\r')
                  ijk = ijk + 1

              #write Exc Isyn sum for LFP
              if nExVm[i] > 0:
                 if ExIsynSumcol[i] == 0:
                     s = '%15s'%'time(ms)'
                     s = s + '%15s'%'I_AMPA(mV)'
                     s = s + '%15s'%'I_NMDA(mV)'
                     s = s + '%15s'%'I_GABAA(mV)'
                     s = s + '%15s'%'I_GABAB(mV)'
                     ExIsynSumf[i].write(s+'\r'); 
                     ExIsynSumcol[i] = 1
                 k = 0; I_AMPA = 0; I_NMDA = 0
                 I_GABAA = 0; I_GABAB = 0
                 nEx_iampa = len(Ex_iampa)
                 while k < nEx_iampa:
                     I_AMPA = I_AMPA + Ex_iampa[k][j]
                     I_NMDA = I_NMDA + Ex_inmda[k][j]
                     I_GABAA = I_GABAA + Ex_igabaa[k][j]
                     I_GABAB = I_GABAB + Ex_igabab[k][j]
                     k = k + 1
                 s = '%15.2f'%ts[j]
                 s = s + '%15.5e'%(I_AMPA/nEx_iampa)
                 s = s + '%15.5e'%(I_NMDA/nEx_iampa)
                 s = s + '%15.5e'%(I_GABAA/nEx_iampa)
                 s = s + '%15.5e'%(I_GABAB/nEx_iampa)
                 ExIsynSumf[i].write(s+'\r')
    
              k = 0  #write topographic Vm data to file ftop
              while k < ntop:
                  if layers[i] in fntop[k]: break    #write topographic data for this layer
                  k = k + 1
              if k < ntop:
                    ijk = 0
                    while ijk < len(dotop):
                        if dotop[ijk] == 'V_m': 
                                all = allVm; topunits = '(mV)'
                        if dotop[ijk] == 'g_AMPA': 
                                all = allgampa; topunits = ''
                        if dotop[ijk] == 'g_NMDA': 
                                all = allgnmda; topunits = ''
                        if dotop[ijk] == 'g_GABA_A': 
                                all = allggabaa; topunits = ''
                        if dotop[ijk] == 'g_GABA_B': 
                                all = allggabab; topunits = ''
                        if dotop[ijk] == 'I_NaP':
                                all = allinap; topunits = '(mV)'
                        if dotop[ijk] == 'I_KNa':
                                all = allikna; topunits = '(mV)'
                        if dotop[ijk] == 'I_h':
                                all = allih; topunits = '(mV)'
                        if dotop[ijk] == 'I_T':
                                all = allit; topunits = '(mV)'
                        if dotop[ijk] == 'theta':
                                all = alltheta; topunits = '(mV)'

                        if topheader[k][ijk] == 0:   #file header not written yet so do so now
                          ftop[k][ijk].write(layers[i]+':  '+dotop[ijk].replace('_','')+topunits+'\r')
                          ftop[k][ijk].write('Rows: '+str(rows[i])+'\r')
                          ftop[k][ijk].write('Columns: '+str(cols[i])+'\r')
                          xy = tp.GetPosition((layernodes[i][0],))
                          ftop[k][ijk].write('Top_left_(x,y): '+str(xy[0])+'\r')
                          xy = tp.GetPosition((layernodes[0][len(layernodes[i])-1],))
                          ftop[k][ijk].write('Bottom_right_(x,y): '+str(xy[0])+'\r')
                          m = 0; s = ''
                          while m < nmods:     #elements contains the model names
                              s = s+' '+elements[i][m]
                              m = m + 1
                          ftop[k][ijk].write('Models: '+s+'\r')
                          ftop[k][ijk].write('Run time (ms): '+'%8.1f'%tstop+'\r')
                          ftop[k][ijk].write('Sampling interval (ms): '+'%8.1f'%(nav*dt)+'\r')
                          topheader[k][ijk] = 1   #file header now written
                        if iav == nav or j == n-1:
                          ftop[k][ijk].write('\r')
                          tav = 0.5*(ts[j] + tav0)
                          ftop[k][ijk].write('t = '+('%10.1f'%tav).ljust(10)+'\r')    #time
                        if nrast > 0 and rastheader[i] == 0:   #file header not written yet so do so now
                          frast[i].write(layers[i]+':  $V$ (mV) for the central '+str(nels)+' cells\r')
                          frast[i].write('Rows: '+str(r2-r1+1)+'\r')
                          frast[i].write('Columns: '+str(c2-c1+1)+'\r')
                          m = 0; s = ''
                          while m < nmods:     #elements contains the model names
                              s = s+' '+elements[i][m]
                              m = m + 1
                          frast[i].write('Models; '+s+'\r')
                          frast[i].write('time (ms): '+'%8.1f'%tstop+'\r')
                          frast[i].write('  dt (ms): '+'%8.1f'%(dt)+'\r')
                          rastheader[i] = 1   #file header now written
                    
                        m = 0   #save raster and topographic data
                        if nrast > 0:
                          frast[i].write('\r')
                          frast[i].write('t = '+('%10.1f'%ts[j]).ljust(10)+'\r')    #time
                        while m < nmods:                                #for each model type,
                          if (iav == nav or j == n-1) and k < len(savetop): ftop[k][ijk].write(elements[i][m]+'\r')    #iterate through the rows
                          if nrast > 0: frast[i].write(elements[i][m]+'\r')    #iterate through the rows
                          nrc = rows[i]*cols[i]; r = 1; ij = 0                           #and columns, writing the
                          while r <= rows[i]:                                    #the recorded Vm 
                              c = 1
                              while c <= cols[i]:
                                  el = m*nrc + (c - 1)*rows[i] + r - 1
                                  if nrast > 0 and r >= r1 and r <= r2 and c >= c1 and c <= c2:
                                      frast[i].write('%10.1f'%all[el][j])
                                      if c == c2: frast[i].write('\r')
                                  if k < len(savetop):
                                      if do_top_av == 'yes':
                                          zav[ijk][m][r-1][c-1] = all[el][j] + zav[ijk][m][r-1][c-1]   #save sum to an array for the topograohic plot
                                      else:
                                          zav[ijk][m][r-1][c-1] = all[el][j]
                                      if (iav == nav or j == n-1) and k < len(savetop):
                                          if do_top_av == 'yes':
                                              ftop[k][ijk].write('%15.5e'%(zav[ijk][m][r-1][c-1]/iav))   #write mean column entries for row r at time ts[j]
                                          else:
                                              ftop[k][ijk].write('%15.5e'%(zav[ijk][m][r-1][c-1]))
                                  c = c + 1
                              if (iav == nav or j == n-1) and k < len(savetop): ftop[k][ijk].write('\r')
                              r = r + 1
                          m = m + 1
                        if (iav == nav or j == n-1): 
                           zav[ijk] = np.zeros((nmods,rows[i],cols[i]))
                        ijk = ijk + 1
              if (iav == nav or j == n-1): iav = 0
              j = j + 1

          #save dt-averaged layer firing rates
          if nExVm[i] > 0:
              frmult = 1000/(dt*nExVm[i])
              if colsExFR[i] == 0: #column headings not written yet so do so now
                   s = '%15s'%'time(ms)' + '%15s'%'ExFR(Hz)'
                   ExFRf[i].write(s+'\r'); colsExFR[i] = 1
              m = 0; count = 0; tsp0 = ts[0] 
              if len(np.array(Ex_spiket)) > 0:
                  tsp = np.sort(np.array(Ex_spiket) - t0) 
                  while m < len(tsp):
                      if tsp[m] <= tsp0:
                          count = count + 1
                      else:
                          s = '%15.1f'%(tsp0) + '%15.5e'%(frmult*count)
                          ExFRf[i].write(s+'\r')
                          tsp0 = tsp0 + dt
                          count = 0
                      m = m + 1
                  while tsp0 <= ts[len(ts)-1]:
                      s = '%15.1f'%(tsp0) + '%15.5e'%(0.0)
                      ExFRf[i].write(s+'\r')
                      tsp0 = tsp0 + dt
              else:
                  while m < len(ts):
                      s = '%15.1f'%(ts[m]) + '%15.5e'%(0.0)
                      ExFRf[i].write(s+'\r')
                      m = m + 1
          if nInVm[i] > 0:
              frmult = 1000/(dt*nInVm[i])
              if colsInFR[i] == 0: #column headings not written yet so do so now
                   s = '%15s'%'time(ms)' + '%15s'%'InFR(Hz)'
                   InFRf[i].write(s+'\r'); colsInFR[i] = 1
              m = 0; count = 0; tsp0 = ts[0] 
              if len(np.array(In_spiket)) > 0:
                  tsp = np.sort(np.array(In_spiket) - t0) 
                  while m < len(tsp):
                      if tsp[m] <= tsp0:
                          count = count + 1
                      else:
                          s = '%15.1f'%(tsp0) + '%15.5e'%(frmult*count)
                          InFRf[i].write(s+'\r')
                          tsp0 = tsp0 + dt
                          count = 0
                      m = m + 1
                  while tsp0 <= ts[len(ts)-1]:
                      s = '%15.1f'%(tsp0) + '%15.5e'%(0.0)
                      InFRf[i].write(s+'\r')
                      tsp0 = tsp0 + dt
              else:
                  while m < len(ts):
                      s = '%15.1f'%(ts[m]) + '%15.5e'%(0.0)
                      InFRf[i].write(s+'\r')
                      m = m + 1
                      
          #save spike times and accumulate spike counts; first the excitatory cells
          if colsExsp[i] == 0: #column headings not written yet so do so now
               s = '%15s'%'time(ms)' + '%15s'%'Ex_id' + '%15s'%'Ex#'
               if saveallspikes > 0: fspEx[i].write(s+'\r')
               if nExVm[i] > 0: fspExVm[i].write(s+'\r')
               colsExsp[i] = 1   #column headings now written
          nExsp[i] = len(Ex_spiket) + nExsp[i]
          m = 0
          while m < len(Ex_spiket):                              #absolute spike times
              tsp = Ex_spiket[m] - t0     #relative spike time
              s = '%15.1f'%(tsp)                #spike time
              s = s + '%15d'%Ex_spikeid[m]                #global id
              s = s + '%15d'%(Ex_spikeid[m]-minEX_id[i])    #rank
              if saveallspikes > 0: fspEx[i].write(s+'\r')
              if i < nlayers:
                  k = 0     #write spike times for the chosen Ex cells
                  while k < nEx:
                      if Ex_spikeid[m] == Ex_cells[k]: fspExVm[i].write(s+'\r')
                      k = k + 1
              m = m + 1

          if i < nlayers:          #similarly for inhibitory cells 
              if colsInsp[i] == 0 :
                   s = '%15s'%'time(ms)' + '%15s'%'In_id' + '%15s'%'In#'
                   if saveallspikes > 0: fspIn[i].write(s+'\r')
                   if nInVm[i] > 0: fspInVm[i].write(s+'\r')
                   colsInsp[i] = 1   #column headings now written
              nInsp[i] = len(In_spiket) + nInsp[i]
              m = 0
              while m < len(In_spiket):
                  tsp = In_spiket[m] - t0 
                  s = '%15.1f'%(tsp)
                  s = s + '%15d'%In_spikeid[m]
                  s = s + '%15d'%(In_spikeid[m]-minIn_id[i])
                  if saveallspikes > 0: fspIn[i].write(s+'\r')
                  k = 0     #write spike times for the chosen In cells
                  while k < nIn:
                      if In_spikeid[m] == In_cells[k]: fspInVm[i].write(s+'\r')
                      k = k + 1
                  m = m + 1
          user_layer_analysis(i)
          i = i + 1
      nf0 = nf0 + nf

      print('Time = ', 0.001*t, 's')
      print('Time = ', 0.001*t, 's',file=printfile)
      simtime = time.time()-time0
      if t <= simt: dsimtime = 0.0; prevsimtime = 0.0
      if t > simt: dsimtime = simtime - prevsimtime
      prevsimtime = simtime
      ss = '%5.2f'%(dsimtime) + ' s'
      #if dsimtime > 60: ss = '%5.2f'%(dsimtime/60) + ' min'
      s = '%5.2f'%(simtime) + ' s'
      if simtime > 60:
          s = '%5.2f'%(simtime/60) + ' min'
          if simtime > 3600:
              s = '%5.2f'%(simtime/3600) + ' h'
      if t > simt: print(str(simt)+' ms run time = ' + ss)
      if t > simt: print(str(simt)+' ms run time = ' + ss,file=printfile)
      print('Run time = ' + s)
      print('Run time = ' + s,file=printfile,flush=True)
  
      j = 1
      while j <= nt:   #calculate firing rates
          pooled_frates(j)
          frates(j)
          j = j + 1
      if doTMS != 0 and t >= tTMS and TMSdone == 0:
          ftms = open(fntms,'a')
          ftms.write('%10.1f'%t+'\r')
          ftms.close()
          if TMSAP > 0:
              i = 0
              while i < nlayers:
                  j = 0
                  while j < len(TMStarget):
                      if layers[i] == TMStarget[j]:
                        if xtms0 > 0 or ytms0 > 0 or xtms1 < 1 or ytms1 < 1:
                          TMScells = []
                          xy = tp.GetPosition((layernodes[i][0],))
                          x0 = xy[0][0]; y0 = xy[0][1]
                          xy = tp.GetPosition((layernodes[i][len(layernodes[i])-1],))
                          x1 = xy[0][0]; y1 = xy[0][1]
                          xt0 = x0 + xtms0*(x1 - x0)
                          xt1 = x0 + xtms1*(x1 - x0)
                          yt0 = y0 + ytms0*(y1 - y0)
                          yt1 = y0 + ytms1*(y1 - y0)
                          TMScellsE = []; k = 0
                          while k < len(ExCells[i]):
                            xy = tp.GetPosition((ExCells[i][k],))
                            xc = xy[0][0]; yc = xy[0][1]
                            if xc >= xt0 and xc <= xt1 and yc <= yt0 and yc >= yt1: 
                                TMScellsE.append(ExCells[i][k])
                            k = k + 1
                          if stim_cell_frac < 1:
                            ns = int(stim_cell_frac*len(TMScellsE))
                            TMScellsE = list(layer_rng[0].choice(TMScellsE, ns, replace=False))
                          TMScells = TMScells + TMScellsE
                          if InTMS == 'yes':
                              TMScellsI = []; k = 0
                              while k < len(InCells[i]):
                                xy = tp.GetPosition((InCells[i][k],))
                                xc = xy[0][0]; yc = xy[0][1]
                                if xc >= xt0 and xc <= xt1 and yc <= yt0 and yc >= yt1: 
                                    TMScellsI.append(InCells[i][k])
                                k = k + 1
                              if stim_cell_frac < 1:
                                ns = int(stim_cell_frac*len(TMScellsI))
                                TMScellsI = list(layer_rng[0].choice(TMScellsI, ns, replace=False))
                              TMScells = TMScells + TMScellsI
                        else:
                          TMScells = ExCells[i]
                          if InTMS == 'yes': TMScells = TMScells + InCells[i]
                        nest.SetStatus(TMScells,{'V_m': 0.0})
                      j = j + 1
                  i = i + 1
          TMSdone = 1

      #set neuron para values
      if len(simparav2) > 0:
          if t-simt >= tbreakn[itb] and itb < len(tbreakn)-1: itb = itb + 1
          if itb < len(tbreakn)-1 and tbreakn[itb] == tbreakn[itb-1]: itb = itb + 1
          t_t2t1 = (t - tbreakn[itb-1])/(tbreakn[itb] - tbreakn[itb-1])
          ip = 0; adjpar = 0
          while ip < len(simparan):
              if simparav2[ip][itb] != simparav2[ip][itb-1]: 
                  adjpar = 1
                  break
              ip = ip + 1
          if adjpar > 0:
              i = 0
              while i < nlayers:    #set para values as appropriate
                  nln = len(layernodes[i])
                  ip = 0
                  while ip < len(simparan):
                      if layertext[ip] in layers[i] or layertext[ip] == '*':
                          paraval = simparav2[ip][itb-1] + t_t2t1*(simparav2[ip][itb]-simparav2[ip][itb-1])
                          if 'T' in layers[i] and simparan[ip] == 'TEx_bomb_rate':
                              nest.SetStatus(Ex_bomb_pg[i], {'rate': paraval})
                          if ('LC' in layers[i] or 'RC' in layers[i]) and simparan[ip] == 'CEx_bomb_rate':
                              nest.SetStatus(Ex_bomb_pg[i], {'rate': paraval})
                          if ('LR' in layers[i] or 'RR' in layers[i]) and simparan[ip] == 'Ret_bomb_rate':
                              nest.SetStatus(In_bomb_pg[i], {'rate': paraval})
                          if 'T' in layers[i] and simparan[ip] == 'TIn_bomb_rate':
                              nest.SetStatus(In_bomb_pg[i], {'rate': paraval})
                          if ('LC' in layers[i] or 'RC' in layers[i]) and simparan[ip] == 'CIn_bomb_rate':
                              nest.SetStatus(In_bomb_pg[i], {'rate': paraval})
                          j = 0
                          while j < nln:
                              status = nest.GetStatus((layernodes[i][j],))
                              setburster = 0
                              if 'IB' in modeltext[ip]:
                                  ib = 0
                                  while ib < len(L56IB):
                                      if layernodes[i][j] in L56IB[ib] and layernodes[i][j] not in L56IBnd[ib]: 
                                          setburster = 1
                                          break
                                      ib = ib + 1
                              if 'ND' in modeltext[ip]:
                                  ib = 0
                                  while ib < len(L56IBnd):
                                      if layernodes[i][j] in L56IBnd[ib]: 
                                          setburster = 1
                                          break
                                      ib = ib + 1
                              if modeltext[ip] in str(status[0]['model']) or modeltext[ip] == '*' or setburster == 1:
                                if simparan[ip] in str(status):
                                  nest.SetStatus((layernodes[i][j],),{simparan[ip]: paraval}) 
                              j = j + 1
                      ip = ip + 1
                  i = i + 1
      
      #set synapse para values
      if len(synparav2) > 0:
          if t-simt >= tbreaks[itbs] and itbs < len(tbreaks)-1: itbs = itbs + 1
          if itbs < len(tbreaks)-1 and tbreaks[itbs] == tbreaks[itbs-1]: itbs = itbs + 1
          t_t2t1 = (t - tbreaks[itbs-1])/(tbreaks[itbs] - tbreaks[itbs-1])
          i = 0
          while i < len(condicts):
            ip = 0 
            while ip < len(synparan):
                adjcon = 0
                if synparav2[ip][itbs] != synparav2[ip][itbs-1]: adjcon = 1
                if adjcon > 0:
                    adjcon = [0,0,0,0,0]
                    if sourcelayertext[ip] == '*' or sourcelayertext[ip] in sourcenames[i]: adjcon[0] = 1
                    if targetlayertext[ip] == '*' or targetlayertext[ip] in targetnames[i]: adjcon[1] = 1
                    if sourcemodeltext[ip] == '*' or sourcemodeltext[ip] in sourcemodels[i]: adjcon[2] = 1
                    if targetmodeltext[ip] == '*' or targetmodeltext[ip] in targetmodels[i]: adjcon[3] = 1
                    if syntransmitter[ip] == '*' or syntransmitter[ip] in transmitters[i]: adjcon[4] = 1
                    if 0 not in adjcon: 
                        paraval = synparav2[ip][itbs-1] + t_t2t1*(synparav2[ip][itbs]-synparav2[ip][itbs-1])
                        nest.SetStatus(conids[i],{synparan[ip]: paraval})
                ip = ip + 1
            i = i + 1
      
  #calculate and save pooled firing rates
  CExbar = [0,0,0,0]; nCExbar = [0,0,0,0] 
  CInbar = [0,0,0,0]; nCInbar = [0,0,0,0]       
  ffrn = outdir+'/'+'Pooled_firing_rates.txt'
  ffr = open(ffrn, 'w')
  ffr.write('Overall mean firing rate (Hz)\r\r')
  
  ffr.write('Excitatory cells'.ljust(20)) 
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17))    #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  i = 0
  while i < nlayers:
      if nExcells[i] > 0:
          ffr.write(layers[i].ljust(20))
          j = 1         #write mean firing rates and accumulate data for grand mean rates
          while j <= nt:
              if 'C' in layers[i] and 'T' not in layers[i]: 
                  CExbar[j] = CExbar[j] + frateEx[j][i]
                  nCExbar[j] = nCExbar[j] + 1
              ffr.write((('%17.2f'%frateEx[j][i]).lstrip()).ljust(17))
              j = j + 1
          ffr.write('\r')
      i = i + 1

  ffr.write('\r')
  ffr.write('Inhibitory cells'.ljust(20))
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17))   #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  i = 0
  while i < nlayers:        
      if nIncells[i] > 0:
          ffr.write(layers[i].ljust(20))
          j = 1         #write mean firing rates and accumulate data for grand mean rates
          while j <= nt:
              if 'C' in layers[i] and 'T' not in layers[i]: 
                  CInbar[j] = CInbar[j] + frateIn[j][i]
                  nCInbar[j] = nCInbar[j] + 1
              ffr.write((('%17.2f'%frateIn[j][i]).lstrip()).ljust(17))
              j = j + 1
          ffr.write('\r')
      i = i + 1
  ffr.write('\r')
  
  j = 1                 #grand mean pooled firing rates:
  while j <= nt:
      ffr.write('\r')
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17)+'\r')
      CExbar[j] = CExbar[j]/nCExbar[j]
      ffr.write('Mean_C_Ex'.ljust(20))    
      ffr.write((('%17.2f'%CExbar[j]).lstrip()).ljust(17)+'\r')
      CInbar[j] = CInbar[j]/nCInbar[j]
      ffr.write('Mean_C_In'.ljust(20))    
      ffr.write((('%17.2f'%CInbar[j]).lstrip()).ljust(17)+'\r')
      j = j + 1
  ffr.close()
  
  
  #calculate and save Ex and In cellular firing rates
  if do_cell_firing_rates == 1:
      grandCExrate = [[],[],[],[]]; grandCInrateD = [[],[],[],[]]
      grandCInrate = [[],[],[],[]]; grandCExrateU = [[],[],[],[]]
      grandCExrateD = [[],[],[],[]]; grandCInrateU = [[],[],[],[]]
      layergrps = ['C_Ex', 'C_In']; ffr = []
      ffrn = outdir+'/'+'Ex_In_firing_rates.txt'
      ffr.append(open(ffrn, 'w'))
      ffrn = outdir+'/'+'Ex_In_firing_rates_stats.txt'
      ffr.append(open(ffrn, 'w')); j = 0
      while j < 2:
          ffr[j].write('Overall mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "", j,'Excitatory', nExcells, frateExcells, grandCExrate)
          save_firing_rates(ffr[j], "", j,'Inhibitory', nIncells, frateIncells, grandCInrate)
          ffr[j].write('Down state mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "D", j,'Excitatory', nExcells, frateExcellsD, grandCExrateD)
          save_firing_rates(ffr[j], "D", j,'Inhibitory', nIncells, frateIncellsD, grandCInrateD)
          ffr[j].write('Up state mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "U", j,'Excitatory', nExcells, frateExcellsU, grandCExrateU)
          save_firing_rates(ffr[j], "U", j,'Inhibitory', nIncells, frateIncellsU, grandCInrateU)
          ffr[j].write('Overall mean firing rates (Hz):\r')
          grandrates = [grandCExrate, grandCInrate]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].write('Down state mean firing rates (Hz):\r')
          grandrates = [grandCExrateD, grandCInrateD]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].write('Up state mean firing rates (Hz):\r')
          grandrates = [grandCExrateU, grandCInrateU]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].close()
          j = j + 1
      if len(minipsps) > 0:
          print('\r'); j = 0
          print('Mean mini rates (Hz)\r')
          while j < nlayers:
            denom = (nExcells[j]+nIncells[j])*tbreak[nt]
            minirate.append(1000*minicount[j]/denom)
            print(layers[j]+': '+str(minirate[j])+'\r')
            j = j + 1 
          print('\r')
      
  
  #close files:
  i = 0
  while i < nlayers:
      if nrast > 0: frast[i].close()
      ExIsynSumf[i].close()
      ExFRf[i].close()
      InFRf[i].close()
      fspEx[i].close()
      fspExVm[i].close()
      fspIn[i].close()
      fspInVm[i].close()
      if do_cell_firing_rates == 1:
          fExtdu[i].close()
          fIntdu[i].close()
      i = i + 1
  i = 0
  while i < ntop:
      ijk = 0
      while ijk < len(dotop):
          ftop[i][ijk].close()
          ijk = ijk + 1
      i = i + 1
  i = 0
  while i < nlayers:
      ijk = 0
      while ijk < len(dosave):
          f[i][ijk].close()
          ijk = ijk + 1
      i = i + 1
      
  #LFP
  i = 0
  while i < nlayers:
      if nExVm[i] > 0:
         fin = open(ExIsynSumfn[i], 'r')
         l = fin.readlines(); fin.close()
         ts = []; RWS = []; DeltaIsyn = []; I_GABA = []; I_AMPA_NMDA = []
         nshift = int(tauLFP/dt); j = 1
         while j < len(l):
             v = l[j].split()
             ts.append(float(v[0]))
             I_AMPA_NMDA.append(float(v[1]) + float(v[2]))
             I_GABA.append(float(v[3]) + float(v[4]))
             j = j + 1
         ts = ts[nshift:len(ts)]
         I_Ex_shifted = np.array(I_AMPA_NMDA[0:len(I_AMPA_NMDA)-nshift])
         I_AMPA_NMDA = np.array(I_AMPA_NMDA[nshift:len(I_AMPA_NMDA)])
         I_GABA = np.array(I_GABA[nshift:len(I_GABA)])
         RWS = I_Ex_shifted - alphaLFP*I_GABA
         DeltaIsyn = I_AMPA_NMDA - I_GABA
         j = 0; RWS0 = []; DeltaIsyn0 = []; I_GABA0 = []
         if doTMS > 0:
            while j < len(l):
                if ts[j] >= ton: break
                RWS0.append(RWS[j])
                DeltaIsyn0.append(DeltaIsyn[j])
                I_GABA0.append(I_GABA[j])
                j = j + 1
            meanIGABA = np.mean(I_GABA0)
            meanRWS = np.mean(RWS0)
            meanDeltaIsyn = np.mean(DeltaIsyn0)
            I_GABA = I_GABA - meanIGABA
            RWS = RWS - meanRWS
            DeltaIsyn = DeltaIsyn - meanDeltaIsyn
         outdir = outdir0
         if nsims > 1: outdir = outdir0+'/output_'+ fmt.format(isim)
         fout = open(outdir+'/'+layers[i]+'/'+layers[i]+'_LFP.txt', 'w')
         s = '%15s'%'time(ms)'
         s = s + '%15s'%'-RWS(mV)'
         s = s + '%15s'%'-DeltaI(mV)'
         s = s + '%15s'%'I_GABA(mV)'
         fout.write(s+'\r');
         j = 0
         while j < len(ts):
             s = '%15.2f'%ts[j]
             s = s + '%15.5e'%-RWS[j]   #change sign for consistency with Mazzoni (2015)
             s = s + '%15.5e'%-DeltaIsyn[j]
             s = s + '%15.5e'%I_GABA[j]
             fout.write(s+'\r')
             j = j + 1
         fout.close()
      i = i + 1      
  isim = isim + 1
if doTMS != 0: ftms.close()

if save_condicts == 'yes':
    fcondict = open(outdir0+'/connection_dictionaries.txt', 'w')
    i = 0
    while i < len(condicts):
        fcondict.write('condicts['+str(i)+'], line '+str(linenum[i])+' in connections file: ')
        fcondict.write(str(sourcenames[i])+' -> '+str(targetnames[i])+'\r')
        fcondict.write(str(condicts[i])+'\r')
        fcondict.write('\r') 
        i = i + 1
    fcondict.close()
user_finish()             

if copy_py_files == 'yes':
    copyFile(runfile,outdir0)
    copyFile(funfile,outdir0)
    copyFile(netfile,outdir0)
    copyFile(simfile,outdir0)
if copy_in_files == 'yes':
    copyFile(userfuncsfile+'.py',outdir0)
    copyFile(simparafn+'.txt',outdir0)
    copyFile(synparafn+'.txt',outdir0)
    copyFile(netparafn+'.txt',outdir0)
    copyFile(parafn+'.txt',outdir0)
    copyFile(fneuron+'.txt',outdir0)
    copyFile(flayers+'.txt',outdir0)
    copyFile(fconnections+'.txt',outdir0)
    
if compress == 'yes':
    os.system('tar -czf '+outdir0+'.tar.gz '+outdir0)
    shutil.rmtree(outdir0, ignore_errors=True)
    os.system('rm -r '+outdir0)
print('Done')
print('Done',file=printfile)  
printfile.close()

