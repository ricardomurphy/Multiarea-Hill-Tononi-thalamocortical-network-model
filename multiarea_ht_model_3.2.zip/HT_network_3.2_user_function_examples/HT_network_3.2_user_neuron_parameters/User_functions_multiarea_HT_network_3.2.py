#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

"""
The user may add his/her own code to the functions listed below.
If it is desired to run several simulations using different 
parameter values, this can be done by adding lines of the 
following type to the end of simulation_parameters_3.2.txt:

#    para1    para2    para3
1    1        0.6      100
2    2        0.7      200
3    4        0.8      300

The entries in the optional # column can be anything, and will 
be read into a list sim_name. Simulation output will then be 
saved to folders sim_name[0]..., sim_name[1]... (outdir0 below). 
If you omit the # column then sim_name defaults to [1,2...].
The parameter names (para1...) can be anything you like; 
they're just for your information, and will be read into a 
list netparan. The values will be read into a list netpara.
Then several simulations will be performed (netsims0 = 3 in the 
above example) where "para1", "para2"... will appear in 
netparan[0], netparan[1]..., while the values will appear in 
netpara[0][0], netpara[0][1].... for inetsims = 0, 
netpara[1][0], netpara[1][1].... for inetsims = 1 etc.., 
where inetsims tracks the simulations (0...netsims0-1). If 
array_job_var = '' or its value is None, the simulations will 
be performed consecutively; otherwise they will be performed as 
an array job (of course you will need to set up the job submission).
The values in netpara may then be used in the user functions below. 
In order to change model variables they must be declared as 
"global" in the functions. Lists are indicated by "list". If 
you want to create your own global variables/lists it is 
recommended that you start their names with "my_" or some such 
to avoid possible conflicts. netpara should be empty if a list 
of input folders is given in a .txt file (see simulation_parameters_3.2.txt), 
otherwise the list of input folders will be ignored. Any value 
assigned to Number_of_simulations in simulation_parameters_3.2.txt 
will also be ignored if netpara is not empty or if a list of input 
folders is given in a .txt file. Otherwise Number_of_simulations sets 
the value of netsims0 (see below).
"""


def user_simulation_parameters():
    """
    user_simulation_parameters() is called for inetsims = 0,1,2... 
    and before building the network (which is done for inetsims = 0 
    or if rebuild_network = 'yes'). It allows the user to override 
    some parameter values set in simulation_parameters_3.2.txt 
    (threads, msd and itdt cannot be reset if rebuild_network = 'no'):

    threads = number of local threads
    array_job_var = array job environment variable name
    netsims0 = number of simulations
    netsims = netsims0 (successive simmulations) or the value of array_job_var (array jobs)
    msd0 = seed for random number generators (< 0 for a 'random' choice)
    itdt = resolution (ms)
    dt = sampling interval (ms)
    simdt = simulation interval (ms)
    simt = between-saves interval (ms)
    rebuild_network = 'yes' to rebuild the network for each simulation (inetsims = 1,2,...)
    resetnetwork > 0 to perform a nest.ResetNetwork() at the start of each simulation
    zero_gsyn = 1 to zero synaptic conductances during settle; then V_m -> RMP
    store_conids = 'yes' to store connection descriptors in list conids
    snapshots = list of times (s) at which to take snapshots of the network (V_m and neuron settables)
    TMSruns = number of TMS runs (replicates)
    TMStarget = list of names(s) of target layer(s) for TMS pulse
    antialias = 'yes' or 'no' for antialias low-pass filtering
    ftype = filter type: 'butter' (Butterworth, default) or 'Bessel'
    fc = filter cut-off frequency (Hz)
    poles = number of filter poles (default = 4)
    backwards = 1 to filter backwards as well as forwards (default = 0; forwards only)
    settle = Settling_time(s) but in ms
    tbreak[0] = 0 (must not be changed)
    tbreak[1], ton = On_time(s) but in ms
    tbreak[2], toff = Off_time(s) but in ms
    tbreak[3], tstop = Run_time(s) but in ms
    input_folder = absolute or relative path (used if inputfolders = ''; default = current working directory)
    input_folder_file = file name ending in ".txt "; the file must contain a list of input folders (one per line)
    inputfolders = list of input folder names supplied in input_folder_file
    state = optional prefix for input files (next seven files)
    netparafn0 = network parameters file name
    fneuron0 = model parameters file name
    flayers0 = neuron layers file name
    fconnections0 = network connections file name
    parafn0 = neuron parameters file name
    synparafn0 = synapse parameters file name
    userfuncsfile0 = User functions file name
    output_folder = output folder (relative to input folder)
    """


def user_model_parameters():
    """
    user_model_parameters() is called after loading a model  
    parameters file but before creating neuron layers or synapse 
    models. Model parameter values may be changed here. The 
    following variables may be useful:

    models = list of model names (use nest.SetDefaults() as required)
    modparas = list of model parameter dictionaries (same order as models)
    models_modparas = list of dictionarise of model names and paras (i.e. models and modparas combined)
    CEx_bomb_rate = synaptic bombardment rate (Hz) to excitatory cortical cells
    CIn_bomb_rate = synaptic bombardment rate (Hz) to inhibitory cortical cells
    TEx_bomb_rate = synaptic bombardment rate (Hz) to excitatory thalamic cells
    TIn_bomb_rate = synaptic bombardment rate (Hz) to inhibitory thalamic cells
    Ret_bomb_rate = synaptic bombardment rate (Hz) to reticular thalamic cells
    bombwt = synaptic weight for synaptic bombardment
    Ex_deltaP = fractional depression for Exc synapses (0 = no depression, 1 = 100% vesicle depletion)
    In_deltaP = fractional depression for Inh synapses (0 = no depression, 1 = 100% vesicle depletion)
    tauP = time constant for recovery from synaptic depression (ms)
    """


def user_network_parameters():
    """
    user_network_parameters() is called after loading 
    network_parameters_3.2.txt but before creating neuron layers. 
    Parameter values in network_parameters_3.2.txt may be  
    overridden here. The following variables may be useful (weight 
    multipliers exclude synaptic bombardment):

    pyrngs = per process Python RNGs (see NEST documentation on random numbers).
    layer_rng = RNG for randomly selecting cells in a layer.
    Pmax0 = global Gaussian Pmax (overridden by Pmax in network_connections_3.2.txt).
    sigma0 = minimum value of Gaussian kernel SD (default 0.31).
    beta0 = global beta (overridden by beta in network_connections_3.2.txt).
    r0 = global mask radius (overridden by Radius in network_connections_3.2.txt).
    rmult = mask radius multiplier (default 1.0).
    roffset = offset for mask 'radius'; actually masks are square with sides of length 2*(Radius+roffset) grid units.
    alphaLFP = GABA current multiplier for LFP (alpha; default 1.65).
    tauLFP = I_AMPA+NMDA delay (ms) for LFP (tau; (default 6.0).
    delay0 = global transmission delay (overridden by Delay(ms) in network_connections_3.2.txt).
    sd0 = global SD(delay) (overridden by SD(delay) in network_connections_3.2.txt).
    weight0 = global connections weight (overridden by Weight in network_connections_3.2.txt).
    sdwt0 = global SD(weight) (overridden by SD(weight) in network_connections_3.2.txt).
    wtmult = multiplier for all synaptic weights (default 1.0)
    ampawtmult = multiplier for AMPA synaptic weights (default 1.0).
    nmdawtmult = multiplier for NMDA synaptic weights (default 1.0).
    gabaawtmult = multiplier for GABA_A synaptic weights (default 1.0).
    gababwtmult = multiplier for GABA_B synaptic weights (default 1.0).
    edgewrap = True/False (default True).
    instant_unblock_NMDA = True/False (default False).
    multapses = True/False (default True).
    autapses = True/False (default True).
    L56_burster_frac = fraction of Exc cells in L56 that are bursters (IB).
    L56_burster_frac_nd = fraction of bursters that are network drivers (ND).
    popVmin, popVmax, mode = Parameters of the initial triangular distribution of membrane potentials (mV).
    model_gs = List of settable, nonzero neuron parameters to be varied randomly.
    gCV = List of coefficient of variation for parameters.
    model_gs_layers = List of layers in which parameters are to be varied.
    model_gs_models = List of neuron models for which parameters are to be varied.
    min_max_g = List of maximum (for -ve paras) or minimum (for +ve paras) parameter values.
    g_distrib = Parameter distribution ("normal" or "triangular").
    """


def user_connections():
    """
    user_connections() is called immediately after loading the data 
    in network_connections_3.2.txt, but before assembling the 
    connection dictionary (condict). The following variables may be 
    useful:

    layers = list of layer names
    elements = list of neuron models in each layer
    sourcename = source layer name 
    targetname = target layer name 
    smodel = source neuron model
    tmodel = target neuron model
    beta = "beta" in network_connections_3.2.txt
    pmax = "Pmax" in network_connections_3.2.txt (condict entry)
    r = "Radius" in network_connections_3.2.txt (after scaling by rmult; condict entry)
    htsynapse = "Transmitter" in network_connections_3.2.txt (condict entry)
    w = "Weight" in network_connections_3.2.txt (after scaling by any multipliers such as wtmult; condict entry))
    sdwt = "SD(Weight)" in network_connections_3.2.txt (condict entry) 
    d = "Delay(ms)" in network_connections_3.2.txt (condict entry)
    sd = "SD(delay)" in network_connections_3.2.txt (condict entry)
    min_delay = minimum delay (ms) (condict entry)
    s = Gaussian kernel SD (condict entry; default = sigma0 + beta*r)
    dl = list of entries from the data line in network_connections_3.2.txt
         corresponding to condict, with the data line number as 
         the first entry. 
    con_class = connection 'class' (the line immediately above a column header line in network_connections_3.2.txt)
    """


def user_stimulus():
    """
    user_stimulus() is called after building the network and before 
    loading neuron_parameters_3.2.txt and synapse_parameters_3.2.txt. 
    Te user may add his/her own stimulus here. The following 
    variables may be useful:
    
    layers = list of layer names
    layer = list of layer id's
    layernodes = list of cell id's for each layer
    ExCells = list of Exc cell id's for each layer
    InCells = list of Inh cell id's for each layer
    L56IB = list of id's for IB (including ND) cells in LC1L56, LC2L56...RC3L56
    L56IBnd = list of id's for network driver (ND) cells in LC1L56, LC2L56...RC3L56
    models = list of neuron model names (same order as modparas)
    modparas = list of model parameter dictionaries
    models_modparas = list of dictionarise of model names and paras (i.e. models and modparas combined)
    elements = list of neuron models in each layer
    Ex_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Exc cells
    In_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Inh cells
    """


def user_neuron_parameters():
    #Assuming the supplied file wake-sleep_neuron_parameters_3.2.txt 
    #was specified in simulation_parameters_3.2.txt, set g_KL 
    #for the reticular nucleii according to para2 during sleep.
    i = 0
    while i < len(layertext):
        if ('LR' in layertext[i] or 'RR' in layertext[i]) and simparan[i] == 'g_KL':
            simparav2[i][2] = netpara[inetsims][1]
            simparav2[i][3] = netpara[inetsims][1]
        i = i + 1
    """
    user_neuron_parameters() is called after loading 
    neuron_parameters_3.2.txt but before the start of a simulation 
    (i.e. before the settling time, if any). Parameter values set 
    in neuron_parameters_3.2.txt may be overridden here. The 
    following variables may be useful (the first six relate to 
    those set in neuron_parameters_3.2.txt):

    layertext = list of strings identifying layers
    modeltext = list of strings identifying neuron models
    tbreakn = list of times specified in neuron_parameters_3.2.txt, 
              with tbreakn[0] = 0 and tbreakn[len(tbreakn)-1] = tstop
    simparan = list of strings identifying model parameter names
    simparav1 = list of parameter values at t = tbreakn[0] = 0
    simparav2 = lists of parameter values (if present) for tbreakn[0], 
                tbreakn[1]...tbreakn[len(tbreakn)-1]
    layers = list of layer names
    layer = list of layer id's
    layernodes = list of cell id's for each layer
    ExCells = list of Exc cell id's for each layer
    InCells = list of Inh cell id's for each layer
    L56IB = list of id's for IB (including ND) cells in LC1L56, LC2L56...RC3L56
    L56IBnd = list of id's for network driver (ND) cells in LC1L56, LC2L56...RC3L56
    models = list of neuron model names (same order as modparas)
    modparas = list of model parameter dictionaries
    models_modparas = list of dictionarise of model names and paras (i.e. models and modparas combined)
    elements = list of neuron models in each layer
    Ex_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Exc cells
    In_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Inh cells
    """


def user_synapse_parameters():
    """
    user_synapse_parameters() is called after loading 
    synapse_parameters_3.2.txt but before the start of a simulation 
    (i.e. before the settling time, if any). Parameter values set 
    in synapse_parameters_3.2.txt may be overridden here. The 
    following variables may be useful (the first nine relate to 
    those set in synapse_parameters_3.2.txt):

    sourcelayertext = list of strings identifying source layers
    targetlayertext = list of strings identifying target layers
    sourcemodeltext = list of strings identifying source models
    targetmodeltext = list of strings identifying target models
    syntransmitter = list of transmitters in synapse_parameters_3.2.txt
    tbreaks = list of times specified in synapse_parameters_3.2.txt, 
              with tbreaks[0] = 0 and tbreaks[len(tbreaks)-1] = tstop
    synparan = list of strings identifying synapse parameter names
    synparav1 = list of parameter values at t = tbreaks[0] = 0
    synparav2 = lists of parameter values (if present) for tbreaks[0], 
                tbreaks[1]...tbreakn[len(tbreaks)-1]
    layers = list of layer names
    models = list of neuron model names
    condicts = list of connection dictionaries corresponding to the data lines in network_connections_3.2.txt
    linenum = list of corresponding data line numbers from network_connections_3.2.txt
    sourcenames, targetnames = lists of source and target layer names (one per entry in condicts)
    sources, targets = lists of source and target layer ids (one per entry in condicts)
    sourcenodes, targetnodes = lists of node ids in source and target layers (one per entry in condicts)
    sourcemodels, targetmodels = lists of source and target neuron models (one per entry in condicts)
    transmitters = list of synapse types (one per entry in condicts)
    conids = lists of connection descriptors (one per entry in condicts).
             If store_conids = 'no' then conids = [] and you must 
             use nest.GetConnections() to access connections.
    """


def user_models():
    """
    user_models() is called immediately before the start of a 
    simulation interval (simdt). Neuron model and connection parameters 
    may be changed here, allowing more flexibility than is available 
    with neuron_parameters_3.2.txt and synapse_parameters_3.2.txt. 
    The following variables may be useful:

    outdir0 = input_folder+'/'+output_folder if netsims = 1
    outdir0 = input_folder+'/'+sim_name[inetsims]+'_'+output_folder+pnv if netsims > 1,
              where pnv = '_'+netparan[i]+'='+str(netpara[inetsims][i])+... for i = 0,1,...netsims-1
    simdt = actual simulation interval (ms)
    simdt0 = the value set in simulation_parameters_3.2.txt
    simt = actual between-saves interval (ms)          
    simt0 = the value set in simulation_parameters_3.2.txt 
    t0 = simulation start time (ms)
    t = time relative to t0 (ms)
    tbreak[0] = 0 (must not be changed)
    tbreak[1], ton = On_time(s) but in ms
    tbreak[2], toff = Off_time(s) but in ms
    tbreak[3], tstop = Run_time(s) but in ms
    tbreakn = list of times specified in neuron_parameters_3.2.txt
    tbreaks = list of times specified in synapse_parameters_3.2.txt
    layers = list of layer names
    layer = list of layer id's
    layernodes = list of cell id's for each layer
    ExCells = list of Exc cell id's for each layer
    InCells = list of Inh cell id's for each layer
    L56IB = list of id's for IB (including ND) cells in LC1L56, LC2L56...RC3L56
    L56IBnd = list of id's for network driver (ND) cells in LC1L56, LC2L56...RC3L56
    models = list of neuron model names (same order as modparas)
    modparas = list of model parameter dictionaries
    elements = list of neuron models in each layer
    Ex_bomb_pg = list of Poisson generator ids for synaptic bombardment to Exc cells
    In_bomb_pg = list of Poisson generator ids for synaptic bombardment to Inh cells
    condicts = list of connection dictionaries corresponding to the data lines in network_connections_3.2.txt
    linenum = list of corresponding data line numbers from network_connections_3.2.txt
    sourcenames, targetnames = lists of source and target layer names (one per entry in condicts)
    sources, targets = lists of source and target layer ids (one per entry in condicts)
    sourcenodes, targetnodes = lists of node ids in source and target layers (one per entry in condicts)
    sourcemodels, targetmodels = lists of source and target neuron models (one per entry in condicts)
    transmitters = list of synapse types (one per entry in condicts)
    conids = lists of connection descriptors (one per entry in condicts).
             If store_conids = 'no' then conids = [] and you must 
             use nest.GetConnections() to access connections.
    """


def user_analysis():
    """
    user_analysis() is called every Between_saves_interval_(ms) 
    (simt) and BEFORE any antialias filtering or down sampling. The 
    following variables may be useful:
        
    outdir0 = input_folder+'/'+output_folder if netsims = 1
    outdir0 = input_folder+'/'+sim_name[inetsims]+'_'+output_folder+pnv if netsims > 1,
              where pnv = '_'+netparan[i]+'='+str(netpara[inetsims][i])+... for i = 0,1,...netsims-1
    t0 = simulation start time (ms)
    t = time (ms) relative to t0 at the end of the current simulation interval (t = simt for the first simulation interval)
    ts = list of sample times (ms), relative to t0
    tbreak[0] = 0 (must not be changed)
    tbreak[1], ton = On_time(s) but in ms
    tbreak[2], toff = Off_time(s) but in ms
    tbreak[3], tstop = Run_time(s) but in ms
    tbreakn = list of times specified in neuron_parameters_3.2.txt
    tbreaks = list of times specified in synapse_parameters_3.2.txt
    layers = list of layer names
    layer = list of layer id's
    layernodes = list of cell id's for each layer
    dosave = list of recorded variable names
    ExCells = list of Exc cell id's for each layer
    ExVm = multimeter ids for Exc cells in each layer (all recorded data, not just V_m) 
    Ex_spikes = Exc cell spike detector ids for each layer
    InCells = list of Inh cell id's for each layer
    InVm = multimeter ids for Inh cells in each layer (all recorded data, not just V_m) 
    In_spikes = Inh cell spike detector ids for each layer
    L56IB = list of id's for IB (including ND) cells in LC1L56, LC2L56...RC3L56
    L56IBnd = list of id's for network driver (ND) cells in LC1L56, LC2L56...RC3L56
    """

def user_layer_analysis(i):
    """
    user_layer_analysis(i) is called every Simulation_interval(ms) 
    and for each neuronal layer in turn (i = 0...len(layers)-1). 
    The call is made AFTER any antialias filtering or down sampling, 
    and this is reflected in the list of sampling times (ts). In 
    addition to the other lists defined under user_analysis(), the 
    following lists of recorded data are available, provided the 
    corresponding variable names are present in dosave ("Ex" = 
    excitatory cells, "In" = inhibitory cells; variable names are 
    given in parenthesis). Each list is of the form [v[0],v[1]..] 
    where v[j] is a list of values for the jth cell in the ith 
    layer: [v[j][0], v[j][1]...], corresponding to the times 
    [ts[0], ts[1]...]. Lists of spike times and associated cell 
    ids are also provided for the ith layer.

    layers(i) = layer name
    Ex_Vm, In_Vm = membrane potential (V_m, mV)
    Ex_gampa, In_gampa = AMPA conductance (g_AMPA, relative to g_KL)
    Ex_gnmda, In_gnmda = NMDA conductance (g_NMDA, relative to g_KL)
    Ex_ggabaa, In_ggabaa = GABA_A conductance (g_GABA_A, relative to g_KL)
    Ex_ggabab, In_ggabab = GABA_B conductance (g_GABA_B, relative to g_KL)
    Ex_inap, In_inap = NaP current (I_NaP, mV)
    Ex_ikna, In_ikna = Na/K=activated K current (I_KNa, mV)
    Ex_ih, In_ih = h current (I_h, mV)
    Ex_it, In_it = T-type Ca current (I_T, mV)
    Ex_theta, In_theta = time-dependent AP threshold (theta, mV)
    Ex_spiket, In_spiket = spike times
    Ex_spikeid, In_spikeid = cell ids
    """

def user_finish():
    """
    user_finish() is called at the very end of a simulation (i.e.
    for each inetsims = 0,1...netsims-1). The user may 'tidy up' 
    here (e.g. close files).
    """

