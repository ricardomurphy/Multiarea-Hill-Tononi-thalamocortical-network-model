#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

ver = 3.2

import sys
import numpy as np
import scipy
from scipy import stats
from scipy import signal
import time
import os
import shutil
import nest
import nest.topology as tp

input_folder = os.getcwd()
if len(sys.argv) > 1: input_folder = str(sys.argv[1])
netparafn0 = 'network_parameters_'+str(ver)
fneuron0 = 'model_parameters_'+str(ver)
flayers0 = 'neuron_layers_'+str(ver)
fconnections0 = 'network_connections_'+str(ver)
parafn0 = 'neuron_parameters_'+str(ver)
synparafn0 = 'synapse_parameters_'+str(ver)
userfuncsfile0 = "User_functions_multiarea_HT_network_"+str(ver)   

parafiles = 1  #>1 = parameters_1.txt, parameters_2.txt...
parafiles0 = 0    #starting #-1 for para files
synparafiles = 1  #>1 = parameters_1.txt, parameters_2.txt...
synparafiles0 = 0    #starting #-1 for para files
sim_name = []
rebuild_network = 'yes'; reset_network = 'yes'
zero_gsyn = 0; resetnetwork = 1

simparafn = input_folder+'/simulation_parameters_'+str(ver)
f = open(simparafn+'.txt')
l = f.readlines(); f.close()

saveparas = 0; netparan = []; netsims = 1; netpara = []; dosave = ['V_m']
state = ''; settle = 1000.0; stoptime = 3.0; threads = 4; gCV = []
TMStarget = ['LC1L23','LC1L4','LC1L56']; doTMS = 0;  #doTMS = -1,0,1
msd0 = -123456; saveallspikes = 0; print_layers = 1; printdl = 1
dotop = ['V_m']; tbreak = [0,0,0,0]; saveall = 0; savetop = []; compress = 'no'
tbreak[1] = 1000.0; tbreak[2] = 2000.0; tbreak[3] = 3000.0
record0 = ['V_m','g_AMPA','g_NMDA','g_GABA_A','g_GABA_B','I_NaP','I_KNa','I_h','I_T','theta'] 
record = ['V_m','g_AMPA','g_NMDA','g_GABA_A','g_GABA_B']; indep_sims = 'yes'
simt0 = 100.0; toptime = 10.0; topos = 'no'; nc = 3   #cells to record from
antialias = 'no'; ftype = 'butter'; fc = 300; poles = 4; save_condicts = 'yes'
norm = 'mag'; backwards = 0; btype='lowpass'; InTMS = 'yes'; store_conids = 'yes'
output_folder = 'output'; del_out = 'yes'; copyfiles = 'yes'; synp_inf = 'yes'
input_folder_file = ''; inputfolders = []; netp_inf = 'yes'; neup_inf = 'yes'
state_inf = 'yes'; neul_inf = 'yes'; netc_inf = 'yes'; user_inf = 'yes'; TMSAP = 1
copy_in_files = 'yes'; copy_py_files = 'yes'; cortices = 2; model_gs = []
mode = -70.0; popVmin = -90.0; popVmax = -55.0; state_ = ''; model_gs_layers = []
location_measure = 'median'; dispersion_measure = 'quartiles'; tms_exsg = []
r0 = 5.0; Pmax0 = 1.0; beta0 = 0.5; weight0 = 1.0; sd0 = 0.0; tms_insg = []
sdwt0 = 0.0; delay0 = 1.0; do_top_av = 'yes'; snapshots = []; TMSpulse = 0.0
array_job_var = ''; simdt0 = 10.0; Number_of_simulations = 1; model_layers = ['all']
g_distrib = 'normal'; min_max_g = []; model_gs_models = []; model_models = ['all']
xtms0 = 0; xtms1 = 1; ytms0 = 0; ytms1 = 1; stim_cell_frac = 1

i = 0
while i < len(l):
    l[i] = l[i].replace('\n','')
    p = l[i].split()
    if ':' in str(p):
        if 'Threads' in p[0]: threads = int(p[1])
        if 'Array_job_env_variable' in p[0] and len(p) > 1:
            array_job_var = p[1]
        if 'RNG_seed' in p[0]: msd0 = int(p[1])
        if 'Independent_simulations_(yes/no)' in p[0]: indep_sims = p[1]
        if 'Number_of_simulations' in p[0]: 
            Number_of_simulations = int(p[1])
            netsims = int(p[1])
            if netsims > 1:
                nz = len(str(netsims))
                isn = 0; j = 0
                while j < netsims:
                    sim_name0 = "{:0>"+str(nz)+"d}"
                    sim_name.append(sim_name0.format(j+1))
                    j = j + 1
        if 'Resolution(ms)' in p[0]: itdt = float(p[1])
        if 'Sampling_interval(ms)' in p[0]: dt = float(p[1])
        if 'Simulation_interval(ms)' in p[0]: simdt0 = float(p[1])
        if 'Between_saves_interval_(ms)' in p[0]: simt0 = float(p[1])
        if 'Rebuild_network(yes/no)' in p[0]: rebuild_network = p[1]
        if 'Reset_network(yes/no)' in p[0]: 
            reset_network = p[1]
            if reset_network == 'no': resetnetwork = 0
        if 'Store_connection_descriptors_(yes/no)' in p[0]: store_conids = p[1]
        if 'Settling_time(s)' in p[0]: settle = 1000*float(p[1])
        if 'Zero_synaptic_conductances_during_settle' in p[0]: 
            if p[1] == 'yes': zero_gsyn = 1
        if 'Run_time(s)' in p[0]: 
            stoptime = float(p[1]); tstop = 1000*stoptime; tbreak[3] = tstop
        if 'Record_all_spike_times' in p[0] and 'yes' in p[1]: saveallspikes = 1
        if 'Time_series_for_variables' in p[0]:
            if p[1] == 'all':
               dosave = record0.copy()
               record = record0.copy()
            else:
               dosave = []; j = 1
               while j < len(p):
                   dosave.append(p[j])
                   j = j + 1
            if 'V_m' not in dosave: dosave.insert(0, 'V_m')
            record = dosave.copy()
            if 'g_AMPA' not in record: record.append('g_AMPA')
            if 'g_NMDA' not in record: record.append('g_NMDA')
            if 'g_GABA_A' not in record: record.append('g_GABA_A')
            if 'g_GABA_B' not in record: record.append('g_GABA_B')
        if 'Number_of_example_cells_per_layer' in p[0]: 
            nc = int(p[1]); 
            if nc < 3: nc = 3
        if 'Measure_of_location_(mean/median)' in p[0]: location_measure = p[1]
        if 'Measure_of_dispersion_(sd/quartiles)' in p[0]: dispersion_measure = p[1]
        if 'Save_topographic_data_(yes/no)' in p[0]: topos = p[1]
        if 'Topographics_for_layers' in p[0] and topos == 'yes':
            if p[1] == 'all':
               saveall = 1
            else:
               savetop = []; j = 1
               while j < len(p):
                  if 'TM' not in p[j] and 'TC' not in p[j]:
                     savetop.append(p[j])
                  j = j + 1
        if 'Topographics_for_variables' in p[0] and topos == 'yes':
            if p[1] == 'all':
               dotop = record0.copy()
               dosave = record0.copy()
               record = record0.copy()
            else:
               dotop = []; j = 1
               while j < len(p):
                   dotop.append(p[j])
                   if p[j] not in dosave: dosave.insert(len(dosave),p[j])
                   if p[j] not in record: record.insert(len(record),p[j])
                   j = j + 1
        if 'Topographic_sampling_interval(ms)' in p[0]: toptime = float(p[1])
        if 'Average_over_sampling_interval' in p[0]: do_top_av = p[1]
        if 'Take_snapshots_at_times_(s)' in p[0] and len(p) > 1:
            if ':' in str(p[1]):
                ss = p[1].split(':')
                sst1 = float(ss[0])
                ssdt = float(ss[1])
                sst2 = float(ss[2])
                nss = int((sst2-sst1)/ssdt)+1
                j = 0
                while j < nss:
                    snapshots.append(sst1+j*ssdt)
                    j = j + 1
            else:
                j = 1
                while j < len(p):
                    snapshots.append(float(p[j]))
                    j = j + 1
        if 'TMS(yes/no)' in p[0]:
            doTMS = 0
            if p[1] == 'yes': doTMS = 1
        if 'TMS_activates_interneurons(yes/no)' in p[0]:
            InTMS = p[1]
        if 'TMS_target' in p[0]:
            TMStarget = []; j = 1
            while j < len(p):
                TMStarget.append(p[j])
                j = j + 1
        if 'Stimulus_area_coordinates_(xmin_xmax_ymin_ymax)' in p[0] and len(p) > 1:
            xtms0 = float(p[1]); xtms1 = float(p[2])
            ytms0 = float(p[3]); ytms1 = float(p[4])
        if 'Fraction_of_cells_activated' in p[0] and len(p) > 1:
            stim_cell_frac = float(p[1])
        if 'Number_of_TMS_runs' in p[0]: TMSruns = int(p[1])
        if 'On_time(s)' in p[0]: 
            TMSon = float(p[1]); ton = 1000*TMSon; tbreak[1] = ton
        if 'Off_time(s)' in p[0]: 
            TMSoff = float(p[1]); toff = 1000*TMSoff; tbreak[2] = toff
        if 'Antialias_filter(yes/no)' in p[0]: antialias = p[1]
        if 'Filter_type(butter/bessel)' in p[0]: ftype = p[1]
        if 'Filter_cutoff_frequency_(Hz)' in p[0]: fc = float(p[1])
        if 'Input_folder' in p[0] and len(p) > 1: 
            if '.txt' not in p[1]:
                input_folder = p[1]
            else:
                if Number_of_simulations > 1:
                    print('WARNING: ignoring Number_of_simulations in favour of input_folder_file\r')
                input_folder_file = p[1]
                f = open(input_folder_file)
                ll = f.readlines(); f.close()
                netsims = 0; j = 0
                while j < len(ll):
                    ll[j] = ll[j].replace('\n','')
                    if len(ll[j]) > 0:
                        inputfolders.append(ll[j])
                        netsims = netsims + 1
                    j = j + 1
        if 'Prefix_for_input_files' in p[0] and len(p) > 1: 
            state = p[1]
            if len(state.split()) > 0: state_ = state+'_'
        if 'Model_parameters_file' in p[0] and len(p) > 1: fneuron0 = p[1]
        if 'Network_parameters_file' in p[0] and len(p) > 1: netparafn0 = p[1]
        if 'Neuron_layers_file' in p[0] and len(p) > 1: flayers0 = p[1]
        if 'Network_connections_file' in p[0] and len(p) > 1: fconnections0 = p[1]
        if 'Neuron_parameters_file' in p[0] and len(p) > 1: parafn0 = p[1]
        if 'Synapse_parameters_file' in p[0] and len(p) > 1: synparafn0 = p[1]
        if 'User_functions_file' in p[0] and len(p) > 1: userfuncsfile0 = p[1]
        if 'Output_folder' in p[0] and len(p) > 1: output_folder = p[1]
        if 'Copy_input_files_to_output_folder' in p[0]: copy_in_files = p[1] 
        if 'Copy_python_scripts_to_output_folder' in p[0]: copy_py_files = p[1]        
        if 'Save_connection_dictionaries' in p[0]: save_condicts = p[1]
        if 'Delete_output_folder_if_already_present' in p[0]: del_out = p[1]
        if 'Compress_output_folder' in p[0]: compress = p[1]
    if len(p) > 0 and ':' not in str(p) and len(inputfolders) == 0:
        if len(netparan) == 0: 
            if '#' not in l[i]: l[i] = '#   '+l[i]; saveparas = 1
            p = l[i].split(); j = 1
            while j < len(p):
                netparan.append(p[j])
                j = j + 1
            iparas = i
            sim_name = []
            netsims = 0
            if Number_of_simulations > 1:
                print('WARNING: ignoring Number_of_simulations in favour of netpara\r')
            if len(input_folder_file) > 0:
                print('WARNING: ignoring input_folder_file in favour of netpara\r')
                input_folder_file = ''; inputfolders = []
        else:
            netsims = netsims + 1
            j = 1; npvals = []
            p = l[i].split()
            if saveparas == 1: 
                j = 0
            else:
                sim_name.append(p[0])
            while j < len(p):
                npvals.append(float(p[j]))
                j = j + 1
            netpara.append(npvals)
    i = i + 1
if saveparas > 0:
    nz = len(str(netsims))
    isn = 0; i = 0
    while i < netsims:
        sim_name0 = "{:0>"+str(nz)+"d}"
        sim_name.append(sim_name0.format(i+1))
        i = i + 1
    f = open(simparafn+'.txt','w')
    fmt = '%'+str(nz)+'s'; i = 0
    while i < len(l):
        if i > iparas and isn < len(sim_name):
            l[i] = fmt%sim_name[isn]+'  '+l[i]
            isn = isn + 1
        f.write(l[i]+'\r')
        i = i + 1
    f.close()
saveparas = 0    
if netsims == 0: netsims = 1  
if parafiles > netsims: netsims = parafiles
netsims0 = netsims

runfile = "Run_multiarea_HT_network_"+str(ver)+".py"
funfile = "Functions_multiarea_HT_network_"+str(ver)+".py"
netfile = "Build_multiarea_HT_network_"+str(ver)+".py"
simfile = "Simulate_multiarea_HT_network_"+str(ver)+".py"
exec(open(funfile).read(), globals())
if user_inf == 'yes':
    userfuncsfile = input_folder+"/"+state_+userfuncsfile0
else:
    userfuncsfile = state_+userfuncsfile0
exec(open(userfuncsfile+'.py').read(), globals())

inetsims = 0
array_job_id = os.environ.get(array_job_var)
if array_job_id == None:
    array_job_var = ''
else:
    rebuild_network = 'yes'
    reset_network == 'yes'
    resetnetwork = 1
    netsims = int(array_job_id)
    inetsims = netsims - 1
if array_job_var != '':
    print_layers = 0; printdl = 0
while inetsims < netsims:
    user_simulation_parameters(); print('\r')
    if len(state.split()) > 0: state_ = state+'_'
    if user_inf == 'yes':
        userfuncsfile = input_folder+"/"+state_+userfuncsfile0
    else:
        userfuncsfile = state_+userfuncsfile0
    exec(open(userfuncsfile+'.py').read(), globals())
    if netsims > 1 or array_job_var != '': print('Simulation: ',inetsims+1)
    if len(inputfolders) > 0: input_folder = inputfolders[inetsims]
    if inetsims == 0 or rebuild_network == 'yes' or array_job_var != '': 
        exec(open(netfile).read(), globals())
    exec(open(simfile).read(), globals())
    inetsims = inetsims + 1

