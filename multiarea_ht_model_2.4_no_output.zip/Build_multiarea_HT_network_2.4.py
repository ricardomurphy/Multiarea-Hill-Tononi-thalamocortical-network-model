#!/usr/bin/env     
# -*- coding: utf-8 -*-
#@author: ricardom

#htneuron = 'ht_neuron'
htneuron = 'ht_neuron_sh_DKhep'
wtmult = 1.0
ampawtmult = 1.0
nmdawtmult = 1.0
gabaawtmult = 1.0
gababwtmult = 1.0
min_delay = itdt
doL56 = 1   #1 = bursters in L56
L56_burster_frac = 0.3
rcdiv = 1   #divide row and cols by this factor (e.g. 10; useful for testing)
rmult = 1.0
sigma0 = 0.308

roffset = 0.5
edgewrap = True
instant_unblock_NMDA = False
multapses = True
autapses = True
lr = ['L','R']; cortices = 2  #for cortices = 1 use a connection file w/o callosal connections!   
width = -1  #2.0   #width in columns of sources/targets for callosal connections 
            #(0 = cut callosum, -1 = connect whole layers via callosum)
alphaLFP = 1.65   
tauLFP = 6.0
diagnostics = 0   #1 = get some extra information for diagnostic purposes
printdl = 1       #1 = print data lines from connection file

if netp_inf == 'yes':
    netparafn = input_folder+'/network_parameters_'+str(ver)+'.txt'
else:
    netparafn = 'network_parameters_'+str(ver)+'.txt'
f = open(netparafn); 
l = f.readlines(); f.close()
nl = len(l); i = 0
while i < nl:
    p = l[i].split()
    if 'Minimum_value_of_Gaussian_kernel_SD_(sigma0)' in l[i]:
        sigma0 = float(p[1])
    if 'Mask_diameter_multiplier:' in l[i]:
        rmult = float(p[1])
    if 'GABA_current_multiplier_for_LFP' in l[i]:
        alphaLFP = float(p[1])
    if 'I_AMPA+NMDA_delay_(ms)_for_LFP' in l[i]:
        tauLFP = float(p[1])
    if 'Edgewrap_(True/False)' in l[i]:
        edgewrap = bool(p[1])
    if 'Instant_unblock_NMDA_(True/False)' in l[i]:
        instant_unblock_NMDA = bool(p[1])
    if 'Allow_multapses_(True/False)' in l[i]:
        multapses = bool(p[1])
    if 'Allow_autapses_(True/False)' in l[i]:
        autapses = bool(p[1])   
    if 'AMPA_weight_multiplier' in l[i]:
        ampawtmult = float(p[1])
    if 'NMDA_weight_multiplier' in l[i]:
        nmdawtmult = float(p[1])
    if 'GABA-A_weight_multiplier' in l[i]:
        gabaawtmult = float(p[1])
    if 'GABA-B_weight_multiplier' in l[i]:
        gababwtmult = float(p[1])
    if 'Layer_5/6_burster_fraction_(0-1)' in l[i]:
        L56_burster_frac = float(p[1])
        if L56_burster_frac == 0: doL56 = 0
    i = i + 1

nest.ResetKernel()
nest.SetKernelStatus({"local_num_threads": threads})
if msd < 0: 
    msd = np.random.randint(100000,999999+1)
else:
    np.random.RandomState(seed = msd)
N_vp = nest.GetKernelStatus(['total_num_virtual_procs'])[0]
pyrngs = [np.random.RandomState(s) for s in range(msd, msd+N_vp)]
nest.SetKernelStatus({'grng_seed' : msd+N_vp})
nest.SetKernelStatus({'rng_seeds' : range(msd+N_vp+1, msd+2*N_vp+1)})
nest.SetKernelStatus({'resolution': itdt})
net_time0 = time.time()    

#Set up neuron models
if state_inf == 'yes':
    fneuron = input_folder+'/'+state+'_parameters_'+str(ver)
else:
    fneuron = state+'_parameters_'+str(ver)
f = open(fneuron+'.txt'); modparas = []
l = f.readlines(); f.close()
nl = len(l); i = 0; j = 0; models = []
while i < nl:
    while not ':' in l[i]:
        i = i + 1
        if i == nl: break
    else:
        if 'Synaptic' in l[i]:
            if 'bombardment' in l[i]:
                i = i + 1
                p = l[i].split()
                if 'Cortical_Excitatory' in p[0]: CEx_bomb_rate = float(p[1])
                i = i + 1
                p = l[i].split()
                if 'Cortical_Inhibitory' in p[0]: CIn_bomb_rate = float(p[1])
                i = i + 1
                p = l[i].split()
                if 'Thalamic_Excitatory' in p[0]: TEx_bomb_rate = float(p[1])
                i = i + 1
                p = l[i].split()
                if 'Thalamic_Inhibitory' in p[0]: TIn_bomb_rate = float(p[1])
                i = i + 1
                p = l[i].split()
                if 'Synaptic_bombardment_weight' in p[0]: bombwt = float(p[1])
            if 'depression' in l[i]:
                i = i + 1
                p = l[i].split()
                if 'tauP(ms)' in p[0]: tauP = float(p[1])
                i = i + 1
                p = l[i].split()
                if 'deltaP' in p[0]: 
                    Ex_deltaP = float(p[1])
                    In_deltaP = float(p[1])
        else:
            s = l[i].partition(':')   #":" at the end of the line shows this is the model name
            models.append(s[0])
            if models[j] == 'ExCortIB': ibmod = j
            if j == 0:   #if this is the first model read, use it as the basis for all others
                nest.CopyModel(htneuron,models[0]); paras = {}
                nest.SetDefaults(models[0], {'instant_unblock_NMDA': instant_unblock_NMDA})
            else:
                nest.CopyModel(models[0],models[j])
                paras = modparas[0].copy()
            i = i + 1
            while len(l[i]) > 1:  #read the model parameter names and values and add them to the "paras" dictionary
                p = l[i].split()
                nest.SetDefaults(models[j], {p[0]: float(p[1])})
                paras[p[0]] = float(p[1])
                i = i + 1
                if i > nl-1: break
            modparas.append(paras)
            j = j + 1
    i = i + 1
nmodels = j; j = 0

user_model_parameters()
   
#Set up synapse models
htr = nest.GetDefaults(htneuron)['receptor_types']
htrn = list(htr.keys()); nhtr = len(htrn); i = 0
while i < nhtr:
    if htrn[i] == 'AMPA' or htrn[i] == 'NMDA':
        deltaP = Ex_deltaP
    else:
        deltaP = In_deltaP
    nest.CopyModel('ht_synapse', htrn[i], 
        {'receptor_type': htr[htrn[i]], 'delta_P': deltaP, 'tau_P': tauP})
    #nest.CopyModel('static_synapse',htrn[i], 
        #{'receptor_type': htr[htrn[i]]})
    #print(str(htr[htrn[i]]), htrn[i])
    i = i + 1
nest.CopyModel('static_synapse','AMPA_static', 
        {'receptor_type': htr['AMPA']})
nest.CopyModel('static_synapse','NMDA_static', 
        {'receptor_type': htr['NMDA']})
        
user_network_parameters()

#Set up neuron layers
if neul_inf == 'yes':
    flayers = input_folder+'/neuron_layers_'+str(ver)
else:
    flayers = 'neuron_layers_'+str(ver)
f = open(flayers+'.txt')
l = f.readlines(); f.close()
nl = len(l); i = 0; j = 0
ncons = 0; ncells = 0; L56IB = []; L56 = []
layers = []; layer = []; rows = []; cols = []
nExcells = []; nIncells = []; layernodes = []
imatrix = 0; im = -1; irc = []; elements = []
while i < nl:
    if 'Areas:' in l[i]: break
    i = i + 1
nareas = int(l[i].split()[1])
i = i + 1; print('Layers:')
while i < nl:
    while not ':' in l[i]:
        i = i + 1
    else:    #":" at the end of the line means this line contains the layer names
        print(l[i].strip('\n')); i0 = i; ij = 0
        while ij < cortices:
            i = i0
            s = l[i].partition(':'); lyr = s[0].split()
            i = i + 1; s = l[i].split(); r = int(s[1])//rcdiv    #rows
            i = i + 1; s = l[i].split(); c = int(s[1])//rcdiv    #columns
            i = i + 1; neurons = []; neuronprop = []; cellspernode = 0
            while len(l[i]) > 1:
              s = l[i].split();
              neurons.append(s[0])   #accumulate neuron model names and the number per node
              neunum = int(float(s[1]))
              prop = float(s[1])
              neuronprop.append(prop)
              if prop < 1.0: break
              neurons.append(neunum)
              cellspernode = cellspernode + neunum
              i = i + 1          
            nlyr = len(lyr); k = 0
            while k < nlyr:
              layers.append(lr[ij]+lyr[k]); els = []
              if prop >= 1.0:
                numcells = r*c*cellspernode 
                la = tp.CreateLayer({'rows': r, 'columns': c,
                  'extent': [float(c), float(r)], 'edge_wrap': edgewrap,  
                  'elements': neurons})
                m = 1
                while m < len(neurons):
                    mm = 0
                    while mm < neurons[m]:
                        els.append(neurons[m-1])
                        mm = mm + 1
                    m = m + 2
              else:
                if imatrix >= cortices*nareas:
                  im = imatrix - cortices*nareas
                  irc[im] = diff(rc,irc[im])
                  numcells = len(irc[im])
                else:
                  if k == 0 and ij == 0:
                    numcells = round(prop*r*c)
                    rc = [x+1 for x in range(r*c)]
                  irc.append(np.random.choice(rc, numcells, replace=False))
                  im = im + 1
                print(j,layers[j],numcells,k,im,len(irc[im]))                                                                                                                                          
                jrc = 0; pos = []
                cadj = 0.5*float(c) + 0.5
                radj = 0.5*float(r) + 0.5
                while jrc < len(irc[im]):
                  ir = irc[im][jrc]//c
                  if irc[im][jrc]%c > 0: ir = ir + 1     #row
                  ic = irc[im][jrc] - (ir-1)*c           #col
                  ec = float(ic) - cadj                 #convert to units 
                  er = radj - float(ir)                 # of extent
                  pos.append([ec,er])
                  jrc = jrc + 1
                la = tp.CreateLayer({'positions': pos,
                  'extent': [float(c), float(r)], 'edge_wrap': edgewrap,  
                  'elements': neurons})
                els.append(neurons[0])
                imatrix = imatrix + 1
                if imatrix == 2*cortices*nareas:
                  imatrix = 0; irc = []; im = -1
              nodes = nest.GetNodes(la); jj = 0
              layer.append(la)   #accumulate layers and layer nodes
              layernodes.append(nodes[0])
              elements.append(els)   #accumulate elements and the number of rows and columns for each layer
              rows.append(r)
              cols.append(c)
              sn = str(neurons)    #now accumulate the number of excitatory and inhibitory cells in each layer
              if 'Ex' in sn:
                  if prop >= 1.0:
                    ii = 0; n =  0
                    while ii < len(neurons)-1:
                        if 'Ex' in neurons[ii]: n = neurons[ii+1] + n
                        ii = ii + 2
                    nExcells.append(n*r*c)
                  else:
                    nExcells.append(numcells)
              else:
                  nExcells.append(0)
              if 'In' in sn:
                  if prop >= 1.0:
                    ii = 0; n =  0
                    while ii < len(neurons)-1:
                        if 'In' in neurons[ii]: n = neurons[ii+1] + n
                        ii = ii + 2
                    nIncells.append(n*r*c)
                  else:
                    nIncells.append(numcells)
              else:
                  nIncells.append(0)
              ncells = ncells + numcells
              
              #randomly select 100*L56_burster_frac of cells in L56 as bursters
              if 'L56' in lyr[k] and doL56 == 1:
                nd = len(layernodes[j]); ib = 0; L56Ex = []
                while ib < nd:
                    model = nest.GetStatus((layernodes[j][ib],),'model')
                    if 'ExCort' in str(model): L56Ex.append(layernodes[j][ib])
                    ib = ib + 1
                nb = int(L56_burster_frac*len(L56Ex)); ib = 0; bursters = []
                b = np.random.choice(L56Ex, nb, replace=False)
                while ib < nb:
                    nest.SetStatus((b[ib],),modparas[ibmod])
                    bursters.append(b[ib]) 
                    ib = ib + 1
                L56IB.append(bursters)
                L56.append(lr[ij]+lyr[k])
              k = k + 1; j = j + 1 
            ij = ij + 1
    i = i + 1
nlayers = j

#Set up connections
if netc_inf == 'yes':
    fconnections = input_folder+'/network_connections_'+str(ver)
else:
    fconnections = 'network_connections_'+str(ver)
f = open(fconnections+'.txt')
l = f.readlines(); f.close()
nl = len(l); i = 1; dataline = []; linenum = []
sources = []; targets = []; condicts = []
sourcenodes = []; targetnodes = []; transmitters = []
sourcenames = []; targetnames = []; pn = []

while i < nl:
    while not '+/-' in l[i]:   #"+/-" identifies a data line
        if 'connections' in l[i]: 
            contype = l[i].split(); pn = []
        i = i + 1
        if i == nl: break
    else:
        if len(pn) == 0:
            pn = l[i].split(); npn = len(pn); datacolnames = l[i]
            i = i + 1
        p = l[i].split()
        if contype[0] == 'Forward':
          na1 = nareas-1; na2 = 1; ii = 1; jj = 2
        elif contype[0] == 'Backward':
          na1 = nareas-1; na2 = 1; ii = 2; jj = 1
        elif contype[0] == 'Matrix':
          na1 = nareas; na2 = nareas; ii = 1; jj = 1
        else:
          na1 = nareas; na2 = 1; ii = 1; jj = 1
        lrs = ['L','R']; lrt = ['L','R']
        if contype[1] == 'contralateral':
          lrs = ['L','R']; lrt = ['R','L']
        
        ijk = 0
        while ijk < cortices:
            iarea = 0  
            while iarea < na1:
              jarea = 0
              while jarea < na2:
                if na2 == 1: jarea = iarea
                sourcename = lrs[ijk]+p[0]+str(iarea+ii)
                if not '*' in p[1]: sourcename = sourcename+p[1]
                scell = p[2]; k = 0; smodel = ''
                if scell == 'E': scell = 'Ex'
                if scell == 'I': scell = 'In'
                while k < nlayers:
                    if sourcename == layers[k]:   #source layer name
                        scols = cols[k]
                        source = layer[k]; m = 0
                        nodes = layernodes[k]
                        slayernodes = nodes
                        while m < len(layernodes[k]):  #get the model name (smodel) from the layer that corresponds to scell
                            model = nest.GetStatus((layernodes[k][m],),'model')
                            j = 0
                            while j < nmodels:
                                if scell in models[j] and models[j] in model: 
                                    smodel = models[j]
                                    break
                                j = j + 1
                            if len(smodel) > 0: break
                            m = m + 1
                    if len(smodel) > 0: break
                    k = k + 1
                nodelist = []; m = 0
                while m < len(layernodes[k]):
                    model = nest.GetStatus((layernodes[k][m],),'model')
                    if smodel in model:
                        nodelist.append(layernodes[k][m])
                    m = m + 1
                snodes = tuple(nodelist)
                targetname = lrt[ijk]+p[3]+str(jarea+jj)    #do the same for the target layer
                if not '*' in p[4]: targetname = targetname+p[4]
                tcell = p[5]; k = 0; tmodel = ''
                if tcell == 'E': tcell = 'Ex'
                if tcell == 'I': tcell = 'In'
                while k < nlayers:
                    if targetname == layers[k]:
                        tcols = cols[k]
                        target = layer[k]; m = 0
                        nodes = layernodes[k]
                        tlayernodes = nodes
                        while m < len(layernodes[k]):
                            model = nest.GetStatus((layernodes[k][m],),'model')
                            j = 0
                            while j < nmodels:
                                if tcell in models[j] and models[j] in model: 
                                    tmodel = models[j]
                                    break
                                j = j + 1
                            if len(tmodel) > 0: break
                            m = m + 1
                    if len(tmodel) > 0: break
                    k = k + 1
                nodelist = []; m = 0
                while m < len(layernodes[k]):
                    model = nest.GetStatus((layernodes[k][m],),'model')
                    if tmodel in model:
                        nodelist.append(layernodes[k][m])
                    m = m + 1
                tnodes = tuple(nodelist)
                j = 6
                while j < npn:   #get the various parameter values for connections
                  if pn[j] == 'Pmax': pmax = float(p[j])
                  if pn[j] == 'beta': beta = float(p[j])
                  #if pn[j] == 'Sigma': s = float(p[j])
                  if pn[j] == 'Radius': r = float(p[j])/rcdiv
                  if pn[j] == 'Transmitter': htsynapse = p[j]
                  if pn[j] == 'Strength': w = wtmult*float(p[j])
                  if pn[j] == 'Mean_Delay': d = float(p[j]) 
                  if pn[j] == 'SD': sd = float(p[j])
                  j = j + 1
              
                #now assemble the connection dictionary
                condict = {'connection_type': 'divergent'}
                r = rmult*r
                s = sigma0 + beta*r
                condict['mask'] = {'rectangular': {'lower_left': [-(r+roffset),-(r+roffset)], 'upper_right': [(r+roffset),(r+roffset)]}}
                condict['synapse_model'] = htsynapse
                if htsynapse == 'AMPA': w = ampawtmult*w
                if htsynapse == 'NMDA': w = nmdawtmult*w                
                if htsynapse == 'GABA_A': w = gabaawtmult*w
                if htsynapse == 'GABA_B': w = gababwtmult*w
                condict['weights'] = w
                condict['kernel'] = {'gaussian': {'p_center': pmax, 'sigma': s, "c": 0.0, 'mean': 0.0}}
                condict['delays'] = {'normal': {'mean': d, 'sigma': sd, 'min': min_delay}}
                condict['sources'] = {'model': smodel}
                condict['targets'] = {'model': tmodel}
                condict['allow_multapses'] = multapses
                condict['allow_autapses'] = autapses
                dl = p.copy(); dl.insert(0, str(i+1))
                dataline.append(dl)
                linenum.append(i+1)
                user_connections()
                tp.ConnectLayers(source, target, condict)
                cons = nest.GetConnections(snodes,tnodes,htsynapse)
                ncons = ncons + len(cons); cons = []
                sourcenames.append(sourcename)
                targetnames.append(targetname)
                sources.append(source)
                targets.append(target)
                if diagnostics > 0:
                    sourcenodes.append(snodes)
                    targetnodes.append(tnodes)
                    transmitters.append(htsynapse)
                condicts.append(condict)
                if contype[1] == 'contralateral' and width > -1:
                    cons = nest.GetConnections(snodes,tnodes,htsynapse)
                    if width > 0:
                        spos0 = tp.GetPosition((slayernodes[0],))
                        tpos0 = tp.GetPosition((tlayernodes[0],))
                        ll = 0
                        while ll < len(cons):
                            status = nest.GetStatus([cons[ll]])
                            sn = status[0]['source']
                            tn = status[0]['target']
                            spos = tp.GetPosition((sn,))
                            tpos = tp.GetPosition((tn,))
                            dsc = abs(spos[0][0] - spos0[0][0])
                            dtc = abs(tpos[0][0] - tpos0[0][0])
                            if sourcename[0] == 'L':
                                if dtc >= width or dsc < scols-width:
                                    nest.SetStatus((cons[ll],),{'weight': 0.0})
                            else:
                                if dtc < tcols-width or dsc >= width:
                                    nest.SetStatus((cons[ll],),{'weight': 0.0})
                            ll = ll + 1
                    else:
                        nest.SetStatus(cons, {'weight': 0.0})
                if printdl > 0: print(dl)
                jarea = jarea + 1
              iarea = iarea + 1
            ijk =ijk + 1
    i = i + 1

print('')
print("      total layers = ", nlayers)
print("       total cells = ", ncells)
print("    total synapses = ", ncons)

#Set up recorders and synaptic bombardment
InVm = []; ExVm = []
minEX_id = []; minIn_id = []; nVm = []; nExVm = []; nInVm = []
In_spikes = []; Ex_spikes = []; Vm = []; cIBs = []
Ex_bomb_pg = []; In_bomb_pg = [];Ex_bomb_pn = []; 
In_bomb_pn = [];Ex_bomb_sp = []; In_bomb_sp = [];
k = 0; ExCells = []; InCells = []; cEx = []; cIn = []

#sample at resolution if antialias filtering (downsample later)
sdt = dt; n0 = 0; nsteps = 1
if antialias == 'yes': 
    sdt = itdt
    nsteps = int(dt/itdt)
    n0 = nsteps-1
sample_times = nest.Create("multimeter", 1)
nest.SetStatus(sample_times, {"interval": sdt, "record_from": ["V_m"],
  "withgid": True, "withtime": True})
nest.Connect(sample_times, (layernodes[0][0],))
    
while k < nlayers:
    nodes = layernodes[k]
    n = len(layernodes[k]); nVm.append(n)

    InNodes = []; ExNodes = []; j = 0
    while j < n:   #accumulate the excitatory and inhibitory nodes in layer k in lists
      model = nest.GetStatus((layernodes[k][j],),'model')
      if 'Ex' in str(model): ExNodes.append(layernodes[k][j])
      if 'In' in str(model): InNodes.append(layernodes[k][j])
      j = j + 1
    nEx = len(ExNodes); nIn = len(InNodes)
    nExVm.append(nEx); nInVm.append(nIn)
    ExCells.append(ExNodes); InCells.append(InNodes)
    #random selection of nc cells to save data from:
    if nEx > 0:
        cEx.append(np.sort(np.random.choice(ExNodes, nc, replace=False)))
        if doL56 > 0:
            ijk = 0
            while ijk < len(L56):    #and be sure to include bursters for L56
                if layers[k] == L56[ijk]: 
                    ExNodesCopy = ExNodes.copy()
                    iii = 0
                    while iii < len(L56IB[ijk]):
                        ExNodesCopy.remove(L56IB[ijk][iii])
                        iii = iii + 1
                    NnonIBs = int(0.7*nc); NIBs = nc-NnonIBs
                    nonIBs = np.random.choice(ExNodesCopy, NnonIBs, replace=False)
                    IBs = np.random.choice(L56IB[ijk], NIBs, replace=False)
                    cEx[k] = np.sort(np.concatenate((nonIBs,IBs)))
                    cIBs.append(IBs)
                    break
                ijk = ijk + 1
    else:
        cEx.append([])
    if nIn > 0:
        cIn.append(np.sort(np.random.choice(InNodes, nc, replace=False)))
    else:
        cIn.append([])
    
    if nEx > 0:   #if there are excitatory cells in layer k then record from them
     mm = nest.Create("multimeter", 1)   #record variable for excitatory cells
     nest.SetStatus(mm, {"interval": sdt, "withtime": True,
        "record_from": record, "withgid": True})
     nest.Connect(mm, tuple(ExNodes))
     ExVm.append(mm)
     sd = nest.Create("spike_detector", 1)   #record spike time for excitatory cells
     nest.Connect(tuple(ExNodes), sd)
     Ex_spikes.append(sd)
     minEX_id.append(min(ExNodes))
     mpg = nest.Create('poisson_generator', 1)
     if 'T' in layers[k]:
         nest.SetStatus(mpg, {'rate': TEx_bomb_rate})
     elif 'L4' in layers[k]:
     #elif 'LC' in layers[k] or 'RC' in layers[k]:
         nest.SetStatus(mpg, {'rate': CEx_bomb_rate})
     syndict = {'model': 'AMPA_static', 'weight': bombwt}
     nest.Connect(mpg, tuple(ExNodes), syn_spec = syndict)    
     Ex_bomb_pg.append(mpg)
    else:
     ExVm.append([])
     Ex_spikes.append([])
     minEX_id.append(-1)
     Ex_bomb_pg.append([])
     
    if nIn > 0:   #do the same for inhibitory neurons
     mm = nest.Create("multimeter", 1)
     nest.SetStatus(mm, {"interval": sdt, "withtime": True,
        "record_from":record, "withgid": True})
     nest.Connect(mm, tuple(InNodes))
     InVm.append(mm)
     sd = nest.Create("spike_detector", 1)
     nest.Connect(tuple(InNodes), sd)
     In_spikes.append(sd)
     minIn_id.append(min(InNodes))
     mpg = nest.Create('poisson_generator', 1)
     if 'T' in layers[k]:
       nest.SetStatus(mpg, {'rate': TIn_bomb_rate})
     elif 'L4' in layers[k]:
     #elif 'LC' in layers[k] or 'RC' in layers[k]:
       nest.SetStatus(mpg, {'rate': CIn_bomb_rate})
     syndict = {'model': 'AMPA_static', 'weight': bombwt}
     nest.Connect(mpg, tuple(InNodes), syn_spec = syndict)
     In_bomb_pg.append(mpg)
    else:
     InVm.append([])
     In_spikes.append([])
     minIn_id.append(-1)
     In_bomb_pg.append([])

    k = k + 1
network_build_time = time.time()-net_time0
print('network build time = '+'%5.1f'%(time.time()-net_time0)+' s') 

