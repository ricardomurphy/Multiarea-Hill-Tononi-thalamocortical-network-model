#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 16:49:47 2019

@author: ricardom
"""

"""
The user may add his/her own code to the functions listed below.
If it is desired to run several simulations using different 
parameter values, this can be done by adding lines of the 
following type to the end of simulation_parameters_2.3.txt:

#    para1    para2    para3
1    1.0      10.0     100.0
2    2.0      20.0     200.0
3    3.0      30.0     300.0

The parameter names (para1...) can be anything you like; 
they're just for your information, and will be read into a 
list netparan. The values will be read into a list netpara.
Then several simulations will be performed (netsims = 3 in the 
above example) where "para1", "para2"... will appear in 
netparan[0], netparan[1]..., while the values will appear in 
netpara[0][0], netpara[0][1].... for inetsims = 0, 
netpara[1][0], netpara[1][1].... for inetsims = 1 etc.., 
where inetsims tracks the simulations (0...netsims-1). The 
values in netpara may then be used in the user functions below. 
In order to change model variables they must be declared as 
"global" in the functions. Lists are indicated by "list".
"""


def user_simulation_parameters():
    return
"""
user_simulation_parameters() is called for inetsims = 0,1,2... 
and before building the network (which is done for inetsims = 0 
or if rebuild_network = 'yes'). It allows the user to override 
some parameter values set in simulation_parameters_2.3.txt:

threads = number of local threads
msd = seed for random number generator (< 0 for a 'random' choice)
itdt = resolution (ms)
dt = sampling interval (ms)
simt = simulation interval (ms)
state = prefix of state file (e.g. wake_parameters_2.3.txt if state = 'wake')
rebuild_network = 'yes' to rebuild the network for each simulation (inetsims = 1,2,...)
TMSruns = number of TMS runs (replicates)
TMStarget = list of names(s) of target layer(s) for TMS pulse
antialias = 'yes' or 'no' for antialias low-pass filtering
ftype = filter type: 'butter' (butterworth, default) or 'bessel'
fc = filter cutoff frequency (Hz)
poles = number of filter poles (default = 4)
backwards = 1 to filter backwards as well as forwards (default = 0; forwards only)
settle = Settling_time(s) but in ms
tbreak[1] = On_time(s) but in ms
tbreak[2] = Off_time(s) but in ms
tbreak[3] = Run_time(s) but in ms
input_folder = absolute or relative path (used if inputfolders = ''; default = current working directory)
inputfolders = file name ending in ".txt "; the file must contain a list of input folders (one per line)
"""


def user_model_parameters():
    return
"""
user_model_parameters() is called after loading a state 
_parameters_2.3.txt file but before creating neuron layers. 
State parameter values may be changed here. The following 
variables may be useful:

models = list of model names (use nest.SetDefaults() as required)
CEx_bomb_rate = synaptic bombardment rate (Hz) to L4 excitatory cortical cells
CIn_bomb_rate = synaptic bombardment rate (Hz) to L4 inhibitory cortical cells
TEx_bomb_rate = synaptic bombardment rate (Hz) to excitatory thalamic cells
TIn_bomb_rate = synaptic bombardment rate (Hz) to inhibitory thalamic cells
bombwt = synaptic weight for synaptic bombardment
Ex_deltaP = fractional depression for Exc synapses (0 = no depression, 1 = 100% vesicle depletion)
In_deltaP = fractional depression for Inh synapses (0 = no depression, 1 = 100% vesicle depletion)
tauP = time constant for recovery from synaptic depression (ms)
"""


def user_network_parameters():
    return
"""
user_network_parameters() is called after loading 
network_parameters_2.3.txt but before creating neuron layers. 
Parameter values in network_parameters_2.3.txt may be  
overridden here. The following variables may be useful (weight 
multipliers exclude synaptic bombardment):

sigma0 = minimum value of Gaussian kernel SD (default 0.308)
rmult = mask diameter multiplier (default 1.0)
roffset = offset for mask 'radius'; actually masks are square with sides of length 2*(Radius+roffset) grid units.
alphaLFP = GABA current multiplier for LFP (alpha)(default 1.65)
tauLFP = I_AMPA+NMDA delay (ms) for LFP (tau) (default 6.0)
wtmult = multiplier for all synaptic weights (default 1.0)
ampawtmult = multiplier for AMPA synaptic weights (default 1.0)
nmdawtmult = multiplier for NMDA synaptic weights (default 1.0)
gabaawtmult = multiplier for GABA_A synaptic weights (default 1.0)
gababwtmult = multiplier for GABA_B synaptic weights (default 1.0)
edgewrap = True/False (default True)
instant_unblock_NMDA = True/False (default False)
multapses = True/False (default True) 
autapses = True/False (default True) 
L56_burster_frac = fraction of Exc cells in L56 that are bursters (default = 0.3)
"""


def user_connections():
   return
"""
user_connections() is called immediately after the connection
dictionary (condict) is assembled according to the data in 
network_connections_2.3.txt. The user may change the entries 
in condict here. The following variables may be useful:

layers = list of layer names
elements = list of neuron models in each layer
sourcename = source layer name 
targetname = target layer name 
dl = list of entries from the data line in network_connections_2.3.txt
     corresponding to condict, with the data line number as 
     the first entry.
"""


def user_neuron_parameters():
    return
"""
user_neuron_parameters() is called after loading 
neuron_parameters_2.3.txt but before the start of a simulation 
(i.e. before the settling time, if any). Parameter values set 
in neuron_parameters_2.3.txt may be overridden here. The 
following variables may be useful (the first five relate to 
those set in neuron_parameters_2.3.txt):

layertext = list of strings identifying layers
modeltext = list of strings identifying neuron models
simparan = list of strings identifying model parameter names
simparav1 = list of first parameter values
simparav2 = list of second parameter values (if present)
layers = list of layer names
layer = list of layer id's
layernodes = list of cell id's for each layer
ExCells = list of Exc cell id's for each layer
InCells = list of Inh cell id's for each layer
L56IB = list of id's for IB cells in LC1L56, LC2L56...RC3L56
models = list of neuron model names (same order as modparas)
modparas = list of model parameter dictionaries
elements = list of neuron models in each layer
Ex_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Exc cells
In_bomb_pg = list of Poisson generator ids (one per layer) for synaptic bombardment to Inh cells
"""


def user_models():
    return
"""
user_models() is called immediately before the start of a 
simulation interval. Neuron model and connection parameters 
may be changed here, allowing more flexibility than is 
available with neuron_parameters_2.3.txt. The following 
variables may be useful (use nest.GetConnections() to access 
synaptic connections):

simt = Simulation_interval(ms)
t0 = simulation start time (ms)
t = time relative to t0 (ms)
tbreak[1] = On_time(s) but in ms
tbreak[2] = Off_time(s) but in ms
tbreak[3] = Run_time(s) but in ms
layers = list of layer names
layer = list of layer id's
layernodes = list of cell id's for each layer
ExCells = list of Exc cell id's for each layer
InCells = list of Inh cell id's for each layer
L56IB = list of id's for IB cells in LC1L56, LC2L56...RC3L56
models = list of neuron model names (same order as modparas)
modparas = list of model parameter dictionaries
elements = list of neuron models in each layer
Ex_bomb_pg = list of Poisson generator ids for synaptic bombardment to Exc cells
In_bomb_pg = list of Poisson generator ids for synaptic bombardment to Inh cells
"""


def user_analysis():
    return
"""
user_analysis() is called every Simulation_interval(ms) and 
BEFORE any antialias filtering or downsampling. The following 
variables may be useful:
    
t0 = simulation start time (ms)
ts = list of sample times (ms), relative to t0
tbreak[1] = On_time(s) but in ms
tbreak[2] = Off_time(s) but in ms
tbreak[3] = Run_time(s) but in ms
layers = list of layer names
layer = list of layer id's
layernodes = list of cell id's for each layer
ExCells = list of Exc cell id's for each layer
ExVm = list of recorded data (not just V_m) for Exc cells in each layer
Ex_spikes = list of Exc cell spike times for each layer
InCells = list of Inh cell id's for each layer
InVm = list of recorded data (not just V_m) for Inh cells in each layer
In_spikes = list of Inh cell spike times for each layer
L56IB = list of id's for IB cells in LC1L56, LC2L56...RC3L56
"""
