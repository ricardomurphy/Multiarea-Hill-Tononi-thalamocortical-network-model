#!/usr/bin/env     
# -*- coding: utf-8 -*-
#@author: ricardom

simparan = []; simparav1 = []; simparav2 = []; simpara0 = []
zcbar = np.zeros((3,1000)); paranames = []; paravalues = []
parathresh = []; fsim = []; layertext = []; modeltext = []
paravalues0 = []; paraop = []

if neup_inf == 'yes':
    parafn = input_folder+'/neuron_parameters_'+str(ver)+'.txt'
else:
    parafn = 'neuron_parameters_'+str(ver)+'.txt'
if parafiles > 1 or parafiles0 > 0:
    parafn = 'neuron_parameters_'+str(ver)+'_'+str(parafiles0+inetsims+1)+'.txt'
f = open(parafn); l = f.readlines(); f.close()
i = 0; donet2 = 1; doneP = 0; nsims = 1
while i < len(l):
    if len(l[i].strip()) > 1:
        if 'simulations' in l[i]:
            p = l[i].split()  #number of sims
            nsims = int(p[1])
            if nsims > 1:
                j = 0
                while j < nsims:
                    fsim.append(str(j+1))
                    j = j + 1
        else:
            break
    i = i + 1
if i < len(l) and '#' not in l[i]: 
    i = i + 1
    while i < len(l):
        p = l[i].split()
        #print(l[i])
        if len(p) == 0 or '#' in l[i]: break
        pn =  p[2].split('(')
        layertext.append(p[0])
        modeltext.append(p[1])
        simparan.append(pn[0])
        simparav1.append(float(p[3]))
        if len(pn) > 1:
          simpara0.append(float(pn[1].strip(')')))
        else:
          simpara0.append(0.0)
        if len(p) > 4:
          donet2 = 0
          simparav2.append(float(p[4]))
        else:
          simparav2.append(float(p[3]))
        i = i + 1
saveparas = 0
while i < len(l):
    if len(l[i].strip()) > 1: break
    i = i + 1
if i < len(l):
      if '#' not in l[i]: l[i] = '#   '+l[i]; saveparas = 1
      nsims = 0; paran = l[i].split(); i = i + 1
      while i < len(l) and len(l[i]) > 1:
        nsims = nsims + 1
        if saveparas == 1: l[i] = str(nsims).ljust(4)+l[i]
        p = l[i].split(); paradata = []
        fsim.append(p[0]); k = 0
        while k < len(paran)-1:                
          paradata.append(float(p[k+1]))
          k = k + 1
        paravalues.append(paradata); k = 0
        if nsims == 1:
            while k < len(paran)-1:
              pn =  paran[k+1].split('(')
              paraop.append(pn[0][len(pn[0])-1:len(pn[0])])
              paranames.append(pn[0].strip('*/-+'))
              paravalues0.append(0.0)
              if len(pn) > 1:
                parathresh.append(float(pn[1].strip(')')))
              else:
                parathresh.append(0.0)
              k = k + 1
        i = i + 1
if saveparas > 0:
    f = open(parafn,'w'); i = 0
    while i < len(l):
        f.write(l[i])
        i = i + 1
    f.close()
saveparas = 0

#total simulation time is divided into three periods
#(tbreak). Data are saved after simt ms.
time0 = time.time(); resetnetwork = 1
settle = int(settle/itdt)*itdt; dt = int(dt/itdt)*itdt
sim_interval = [0,0,0,0]; simt = int(simt/itdt)*itdt
toptime = int(toptime/itdt)*itdt; nav = int(toptime/dt)
tbreak[3] = int(tbreak[3]/itdt)*itdt
tbreak[2] = int(tbreak[2]/itdt)*itdt
tbreak[1] = int(tbreak[1]/itdt)*itdt
tstop = tbreak[3]; nt = 3
if tstop == tbreak[2]: nt = 2
if tstop == tbreak[1]: nt = 1
if nt < 3: doTMS = 0

mis = -999.0; do_cell_firing_rates = 0; nEx = nc; nIn = nc
print_time = False; nf = 0

if doTMS > 0:
    nsims = TMSruns
    if nsims == 1: doTMS = -1
    if nsims > 1:
        j = 0
        while j < nsims:
            fsim.append(str(j+1))
            j = j + 1
dtTMS = 0.0
if doTMS > 0 and nsims > 1: 
    dtTMS = (tbreak[2]-tbreak[1])/(nsims-1)
    nitdt = int(dtTMS/itdt)
    if np.mod(nitdt,2) > 0: nitdt = nitdt + 1
    dtTMS = nitdt*itdt
    if simt >= dtTMS: 
        simt = dtTMS
    else:
        nsimt = int(dtTMS/simt)
        if np.mod(nsimt,2) > 0: nsimt = nsimt + 1
        simt = float(int(dtTMS/nsimt))
i = 1
while i <= nt:
    if simt > 0:
        sim_interval[i] = simt
    else:
        sim_interval[i] = tbreak[i] - tbreak[i-1]
    i = i + 1

if saveall > 0:    #doesn't work for TM and TC
    i = 0
    while i < nlayers:
        if 'TM' not in layers[i] and 'TC' not in layers[i]: savetop.append(layers[i])
        i = i + 1

#rasters don't seem to work now but in pronciple allow
#saving of topographic data for a subset of cells    
saveallraster = 0; saverast = []
rasternels = -1   #100   <0 => rasternels = rows*cols
if saveallraster > 0:    #needs fixing
    i = 0
    while i < nlayers:
        saverast.append(layers[i])
        i = i + 1
else:                 #needs fixing
    saverast = []
    #saverast = ['LC1L4', 'LC1L56', 'LC2L4', 'LC2L56', 'LC3L4', 'LC3L56']

frateExcells = []; frateIncells = []
frateEx = []; frateIn = []
i = 0
while i <= nt:
    frateEx.append([])    #lists for pooled firing rates
    frateIn.append([])
    frateExcells.append([])    #lists for cellular firing rates
    frateIncells.append([])
    i = i + 1


nf0 = 0
outdir0 = input_folder+'/'+output_folder
if netsims > 1 and len(inputfolders) == 0: 
    outdir0 = input_folder+'/'+output_folder+'_'+str(inetsim[inetsims])
if del_out == 'yes': 
    shutil.rmtree(outdir0, ignore_errors=True)
    os.system('rm -r '+outdir0)
os.mkdir(outdir0)
printfile = open(outdir0+'/output.txt','w')
if copy_py_files == 'yes':
    copyFile(runfile,outdir0)
    copyFile(funfile,outdir0)
    copyFile(netfile,outdir0)
    copyFile(simfile,outdir0)
if copy_in_files == 'yes':
    copyFile(userfuncsfile,outdir0)
    copyFile(simparafn,outdir0)
    copyFile(netparafn,outdir0)
    copyFile(parafn,outdir0)
    copyFile(fneuron+'.txt',outdir0)
    copyFile(flayers+'.txt',outdir0)
    copyFile(fconnections+'.txt',outdir0)

if doTMS != 0:
    fntms = outdir0+'/TMS_times.txt'
    ftms = open(fntms, 'w')
    ftms.write('%10s'%'Time(ms)\r')
if nsims > 1:   #make subfolders if more than one simulation
    isim = 1
    while isim <= nsims:
        outdir = outdir0+'/output_'+fsim[isim-1]   
        os.mkdir(outdir)
        i = 0    
        while i < nlayers:
          os.mkdir(outdir+'/'+layers[i])
          i = i + 1
        isim = isim + 1
else:
    i = 0    
    while i < nlayers:   
        os.mkdir(outdir0+'/'+layers[i])
        i = i + 1

user_neuron_parameters() 

isim = 1; outdir = outdir0 
while isim <= nsims:
  if isim == 1:
      print('      total layers = ',nlayers,file=printfile)
      print('       total cells = ',ncells,file=printfile)
      print('    total synapses = ',ncons,file=printfile)
      print('network build time = %5.1f'%network_build_time+' s',file=printfile)
      print('\r')
      print('\r',file=printfile)
      s0 = nest.GetStatus((0,))
      for keys,values in s0[0].items():
          print(keys,values)
      for keys,values in s0[0].items():
          print(keys,values,file=printfile)
  print('\r',file=printfile)
  print('\r')
  if nsims > 1: print('Simulation: '+str(isim))
  if nsims > 1: print('Simulation: '+str(isim),file=printfile)
  print('RNG seed = ',msd)
  print('RNG seed = ',msd,file=printfile)
  print('Simulation interval = ',sim_interval[1],' ms\r')
  print('Simulation interval = ',sim_interval[1],' ms',file=printfile)
  print('Initializing\r')
  print('Initializing\r',file=printfile)
  if nsims > 1: outdir = outdir0+'/output_'+fsim[isim-1]   
  if isim == 1 or resetnetwork > 0: nest.ResetNetwork()
  nest.SetStatus([0],{"print_time": print_time})

  f = []; fn = []; ExIsynSumcol = []; colnam = []; colsExFR = []
  colsExsp = []; colsInsp = []; fspEx = []; fspIn = []
  ExIsynSumf = []; ExIsynSumfn = []; ntop = 0; nrast = 0
  fnspEx = []; fnspIn = []; nExsp = []; nInsp = []
  nExcellsp = []; nIncellsp = []; thetaEx = []; thetaIn = []
  fntop = []; ftopout = []; ftop = []; topheader = []
  ExFRfn = []; ExFRf = []; InFRfn = []; InFRf = []; colsInFR = []
  fspExVm = []; fspInVm = []; fnth = []; fnspInVm = []
  fnspExVm = []; cbardone = np.zeros((nlayers,3))
  rastheader = []; frast = []; fnrast = []; donet = [0,0,0,0]
  donetf = [0,0,0,0]; minicount = []; minirate = []
  
  frateExcells = []; frateIncells = []
  frateIn = []; frateEx = []; i = 0
  while i <= nt:
    frateEx.append([])    #lists for firing rates
    frateIn.append([])
    frateExcells.append([])    #lists for cellular firing rates
    frateIncells.append([])
    i = i + 1
  TMSdone = 1; tTMS = tbreak[1]
  if doTMS == 1: tTMS = tTMS + (isim-1)*dtTMS
  if doTMS != 0: TMSdone = 0

  #for each layer:
  i = 0    
  while i < nlayers:
      thetaEx.append([]); thetaIn.append([])
      nln = len(layernodes[i])
      
      ip = 0
      while ip < len(simparan):
          if 'T' in layers[i] and simparan[ip] == 'TEx_bomb_rate':
              nest.SetStatus(Ex_bomb_pg[i], {'rate': simparav1[ip]})
          if 'L4' in layers[i] and simparan[ip] == 'CEx_bomb_rate':
              nest.SetStatus(Ex_bomb_pg[i], {'rate': simparav1[ip]})
          if 'T' in layers[i] and simparan[ip] == 'TIn_bomb_rate':
              nest.SetStatus(In_bomb_pg[i], {'rate': simparav1[ip]})
          if 'L4' in layers[i] and simparan[ip] == 'CIn_bomb_rate':
              nest.SetStatus(In_bomb_pg[i], {'rate': simparav1[ip]})
          ip = ip + 1    
              
      #randomize the inital Vm and set parameter values (if different from defaults)
      mode = np.random.uniform(-90.0,-55.0)    #-70.0
      popVm = np.random.triangular(-90.0,mode,-55.0,len(layernodes[i]))
      j = 0   
      while j < nln:
          nest.SetStatus((layernodes[i][j],), {'V_m': popVm[j]})
          j = j + 1
      status = nest.GetStatus((layernodes[i][0],))
      if 'Ex' in str(status): 
          thetaEx[i] = status[0]['theta_eq']
      status = nest.GetStatus((layernodes[i][nln-1],))
      if 'In' in str(status): 
          thetaIn[i] = status[0]['theta_eq'] 
      if len(simparan) > 0 or len(paranames) > 0:
          j = 0
          while j < nln:
              status = nest.GetStatus((layernodes[i][j],))
              ip = 0
              while ip < len(simparan):
                  if layertext[ip] in layers[i] or layertext[ip] == '*':
                      setburster = 0
                      if 'IB' in modeltext[ip]:
                          ib = 0
                          while ib < len(L56IB):
                              if layernodes[i][j] in L56IB[ib]: 
                                  setburster = 1
                                  break
                              ib = ib + 1
                      if modeltext[ip] in str(status[0]['model']) or modeltext[ip] == '*' or setburster == 1:
                          if simparan[ip] in str(status) and abs(status[0][simparan[ip]]) > simpara0[ip]:
                              nest.SetStatus((layernodes[i][j],),{simparan[ip]: simparav1[ip]})
                  ip = ip + 1
              ip = 0
              while ip < len(paranames):
                  if paranames[ip] in str(status) and abs(status[0][paranames[ip]]) > parathresh[ip]:
                      if isim == 1: paravalues0[ip] = status[0][paranames[ip]] 
                      nest.SetStatus((layernodes[i][j],),{paranames[ip]: setpara(paravalues0[ip], paravalues[isim-1][ip], paraop[ip])})
                  ip = ip + 1
              j = j + 1
        
      #initialise some lists
      nExsp.append(0); nInsp.append(0)
      nExcellsp.append([]); nIncellsp.append([])
      j = 0
      while j < nExVm[i]:
          nExcellsp[i].append(0)
          j = j + 1
      j = 0
      while j < nInVm[i]:
          nIncellsp[i].append(0)
          j = j + 1
          
      #files for time series
      j = 0; f.append([]); fn.append([])
      while j < len(dosave):
          fname = outdir+'/'+layers[i]+'/'+layers[i]+'_'+dosave[j]+'.txt'
          fout = open(fname, 'w')
          fn[i].append(fname)
          f[i].append(fout)
          j = j + 1
      ExFRfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_ExFR.txt')
      fout = open(ExFRfn[i], 'w')
      ExFRf.append(fout)
      colsExFR.append(0)
      InFRfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_InFR.txt')
      fout = open(InFRfn[i], 'w')
      InFRf.append(fout)
      colsInFR.append(0)
      ExIsynSumfn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_ExIsynSum.txt')
      fout = open(ExIsynSumfn[i], 'w')
      ExIsynSumf.append(fout)
      ExIsynSumcol.append(0)
      colnam.append([]); ijk = 0
      while ijk < len(dosave):
        colnam[i].append(0)
        ijk = ijk + 1
      
      j = 0   #files for topographic data
      while j < len(savetop):
          if savetop[j] == layers[i]:
            fname = outdir+'/'+layers[i]+'/'+layers[i]
            fntop.append(fname)
            ftop.append([]); topheader.append([])
            ijk = 0
            while ijk < len(dotop):
                if dotop[ijk] in record:
                    ftopout = open(fname+'_'+dotop[ijk]+'_top.txt', 'w')
                    ftop[ntop].append(ftopout)
                    topheader[ntop].append(0)
                ijk = ijk + 1
            ntop = ntop + 1
          j = j + 1
   
      j = 0   #files for raster data - doesn't seem to work
      while j < len(saverast):
          if saverast[j] == layers[i]:
            fname = outdir+'/'+layers[i]+'/'+layers[i]
            fnrast.append(fname)
            frast[nrast] = []; rastheader.append(0)
            ijk = 0
            while ijk < len(dotop):
                if dotop[ijk] in record:
                  frastout = open(fname+'_'+dotop[ijk]+'_raster.txt', 'w')
                  frast[nrast].append(frastout)
                ijk = ijk + 1
            nrast = nrast + 1
          j = j + 1
          
      #Set up spike and down/up files, initialize nExsp and nInsp          
      fnspEx.append(outdir+'/'+layers[i]+'/'+layers[i]+'_Ex_sp.txt')
      if saveallspikes > 0: fout = open(fnspEx[i], 'w')  #if saving all spike times for all Ex cells (a lot of data)
      fspEx.append(fout)
      fnspExVm.append(outdir+'/'+layers[i]+'/'+layers[i]+'_Ex_Vm_sp.txt')
      fout = open(fnspExVm[i], 'w')   #otherwise just save spike times for the cells selected for Vm saving
      fspExVm.append(fout)
      colsExsp.append(0)
      nExsp.append(0);

      #similarly for inhibitory neurons
      fnspIn.append(outdir+'/'+layers[i]+'/'+layers[i]+'_In_sp.txt')
      if saveallspikes > 0: fout = open(fnspIn[i], 'w')
      fspIn.append(fout)
      fnspInVm.append(outdir+'/'+layers[i]+'/'+layers[i]+'_In_Vm_sp.txt')
      fout = open(fnspInVm[i], 'w')
      fspInVm.append(fout)
      colsInsp.append(0)
      nInsp.append(0)

      i = i + 1

  #settling time
  if settle > 0.0:
      if settle < simt: settle = simt
      nsettle = int(settle/simt)
      settle = nsettle*simt
      print ('%g'%settle+' ms settling time\r')
      print ('%g'%settle+' ms settling time\r',file=printfile)
      if zero_gsyn  == 1:
          i = 0
          while i < nlayers:
              j = 0   
              while j < len(layernodes[i]):
                  nest.SetStatus((layernodes[i][j],), {
                  'g_peak_AMPA': 0.0, 'g_peak_NMDA': 0.0, 
                  'g_peak_GABA_A': 0.0, 'g_peak_GABA_B': 0.0})
                  j = j + 1
              i = i + 1
      ij = 0
      while ij < nsettle:
          nest.Simulate(simt)
          i = 0
          while i < nlayers:
              nest.SetStatus(ExVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(Ex_spikes[i],{'n_events': 0})      #clear list for next simulation interval
              nest.SetStatus(InVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(In_spikes[i],{'n_events': 0})      #clear list for next simulation interval
              i = i + 1 
          nest.SetStatus(sample_times,{'n_events': 0})
          ij = ij + 1
      if zero_gsyn  == 1:
          i = 0
          while i < nlayers:
              mode = np.random.uniform(-90.0,-70.0)    #-40.0
              popVm = np.random.triangular(-90.0,mode,-55.0,len(layernodes[i]))    #-70.0 to eliminate intrinsic cortical activity
              j = 0   
              while j < len(layernodes[i]):
                  if state == 'wake':
                      if 'C' in layers[i] and 'T' not in layers[i]:
                          nest.SetStatus((layernodes[i][j],), {'V_m': popVm[j],
                          'g_peak_AMPA': 0.025, 'g_peak_NMDA': 0.02, 
                          'g_peak_GABA_A': 0.33, 'g_peak_GABA_B': 0.0132})
                      else:
                          nest.SetStatus((layernodes[i][j],), {'V_m': popVm[j],
                          'g_peak_AMPA': 0.025, 'g_peak_NMDA': 0.02, 
                          'g_peak_GABA_A': 0.33, 'g_peak_GABA_B': 0.0132})
                  else: 
                      if 'C' in layers[i] and 'T' not in layers[i]:
                          nest.SetStatus((layernodes[i][j],), {'V_m': popVm[j],
                          'g_peak_AMPA': 0.0375, 'g_peak_NMDA': 0.02, 
                          'g_peak_GABA_A': 0.33, 'g_peak_GABA_B': 0.0132})
                      else:
                          nest.SetStatus((layernodes[i][j],), {'V_m': popVm[j],
                          'g_peak_AMPA': 0.025, 'g_peak_NMDA': 0.02, 
                          'g_peak_GABA_A': 0.33, 'g_peak_GABA_B': 0.0132})
                  j = j + 1
              i = i + 1

  #start simulation
  print ('Starting simulation\r')
  print ('Starting simulation\r',file=printfile)
  t0 = nest.GetStatus((0,),'time')[0]; t = 0.0  
  print('Start time = ',0.001*t0,' s')
  print('\r')
  print('Start time = ',0.001*t0,' s',file=printfile)
  print('\r',file=printfile)
  while t < tstop:
      i = 1
      while i <= nt:
          if t < tbreak[i]:
              simt = sim_interval[i]
              break
          i = i + 1
      if tstop-t < simt: simt = tstop-t
      simtime0 = time.time()
      user_models()      
      nest.Simulate(simt)   #to ensure it gets to simt
      #print('Literal '+str(simt)+' ms run time = '+'%5.1f'%(time.time()-simtime0)+' s')
      #print('Literal '+str(simt)+' ms run time = '+'%5.1f'%(time.time()-simtime0)+' s',file=printfile)
      dmm = nest.GetStatus(sample_times)
      ts = dmm[0]["events"]["times"]
      nest.SetStatus(sample_times,{'n_events': 0})
      ts = ts - t0; nts = len(ts)
      user_analysis()
      if antialias == 'yes': ts = ts[n0:nts:nsteps] #downsample
          
      i = 0                      #for each layer
      while i < nlayers:
          #setup for topographic and raster plots
          xtop = np.arange((cols[i]+1))
          ytop = np.arange((rows[i]),-1,-1)
          nmods = len(elements[i])
          trp = np.zeros((2))
          layernels = rows[i]*cols[i]
          if rasternels > layernels or rasternels < 0:
              r1 = 1; r2 = rows[i]
              c1 = 1; c2 = cols[i]
              nels = layernels
          else:
              rc = np.sqrt(rasternels)
              r1 = int(0.5*(rows[i] - rc)) + 1
              r2 = int(r1 + rc - 1)
              c1 = r1; c2 = r2
              nels = rasternels
          yp = np.arange(nels,-1,-1); 
          zp = np.zeros((nmods,1,nels))
          ijk = 0; zav = []
          while ijk < len(dotop):
              zav.append(np.zeros((nmods,rows[i],cols[i])))
              ijk = ijk + 1
          
          #collect time series and spike time data
          Ex_iampa = []; Ex_inmda = []; Ex_igabaa = []; Ex_igabab = []
          allgampa = []; allgnmda = []; allggabaa = []; allggabab = []
          allinap = []; allikna = []; allih = []; allit = []
          cEx_Vm = []; cEx_theta = []; cIn_Vm = []; cIn_theta = []
          cEx_gampa = []; cEx_gnmda = []; cIn_gampa = []; cIn_gnmda = []
          cEx_ggabaa = []; cEx_ggabab = []; cIn_ggabaa = []; cIn_ggabab = []
          cEx_inap = []; cEx_ikna = []; cIn_inap = []; cIn_ikna = []
          cEx_ih = []; cEx_it = []; cIn_ih = []; cIn_it = []
          allVm = []; Ex_Vm = []; Ex_spiket = []; Ex_spikeid = []
          all = []; In_Vm = []; In_spiket = []; In_spikeid = []
          Ex_gampa = []; Ex_gnmda = []; Ex_ggabaa = []; Ex_ggabab = []
          Ex_inap = []; Ex_ikna = []; Ex_ih = []; Ex_it = []
          In_gampa = []; In_gnmda = []; In_ggabaa = []; In_ggabab = []
          In_inap = []; In_ikna = []; In_ih = []; In_it = []
          Ex_theta = []; In_theta = []; alltheta = [] 

          if nExVm[i] > 0:
              cd = nest.GetStatus(ExVm[i])
              idi = np.argsort(cd[0]["events"]["senders"])
              gid = cd[0]["events"]["senders"][idi]
              Vmi = cd[0]["events"]["V_m"][idi]
              gampai = cd[0]["events"]["g_AMPA"][idi]
              gnmdai = cd[0]["events"]["g_NMDA"][idi]
              ggabaai = cd[0]["events"]["g_GABA_A"][idi]
              ggababi = cd[0]["events"]["g_GABA_B"][idi]
              if 'I_NaP' in dosave: inapi = -cd[0]["events"]["I_NaP"][idi]
              if 'I_KNa' in dosave: iknai = -cd[0]["events"]["I_KNa"][idi]
              if 'I_h' in dosave: ihi = -cd[0]["events"]["I_h"][idi]
              if 'I_T' in dosave: iti = -cd[0]["events"]["I_T"][idi]
              if 'theta' in dosave: thetai = cd[0]["events"]["theta"][idi]
              tsi = cd[0]["events"]["times"][idi]
              e = nest.GetStatus((gid[0],))
              E_rev_AMPA = e[0]['E_rev_AMPA']
              E_rev_NMDA = e[0]['E_rev_NMDA']
              E_rev_GABA_A = e[0]['E_rev_GABA_A']
              E_rev_GABA_B = e[0]['E_rev_GABA_B']
              j = 0; ij = 0; ii = 0; Ex_cells = []
              while ij < nExVm[i]:
                  tsj = np.argsort(tsi[j:j+nts])
                  Vmj = Vmi[j:j+nts][tsj]
                  if antialias == 'yes': Vmj = downsample(Vmj)
                  allVm.append(Vmj); Ex_Vm.append(Vmj)
                  gampaj = gampai[j:j+nts][tsj]
                  if antialias == 'yes': gampaj = downsample(gampaj)
                  if 'g_AMPA' in dosave: allgampa.append(gampaj); Ex_gampa.append(gampaj)
                  gnmdaj = gnmdai[j:j+nts][tsj]
                  if antialias == 'yes': gnmdaj = downsample(gnmdaj)
                  if 'g_NMDA' in dosave: allgnmda.append(gnmdaj); Ex_gnmda.append(gnmdaj)
                  ggabaaj = ggabaai[j:j+nts][tsj]
                  if antialias == 'yes': ggabaaj = downsample(ggabaaj)
                  if 'g_GABA_A' in dosave: allggabaa.append(ggabaaj); Ex_ggabaa.append(ggabaaj)
                  ggababj = ggababi[j:j+nts][tsj]
                  if antialias == 'yes': ggababj = downsample(ggababj)
                  if 'g_GABA_B' in dosave: allggabab.append(ggababj); Ex_ggabab.append(ggababj)
                  if 'I_NaP' in dosave:
                      inapj = inapi[j:j+nts][tsj]
                      if antialias == 'yes': inapj = downsample(inapj)
                      allinap.append(inapj); Ex_inap.append(inapj)
                  if 'I_KNa' in dosave:
                      iknaj = iknai[j:j+nts][tsj]
                      if antialias == 'yes': iknaj = downsample(iknaj)
                      allikna.append(iknaj); Ex_ikna.append(iknaj)
                  if 'I_h' in dosave:
                      ihj = ihi[j:j+nts][tsj]
                      if antialias == 'yes': ihj = downsample(ihj)
                      allih.append(ihj); Ex_ih.append(ihj)
                  if 'I_T' in dosave:
                      itj = iti[j:j+nts][tsj]
                      if antialias == 'yes': itj = downsample(itj)
                      allit.append(itj); Ex_it.append(itj)
                  if 'theta' in dosave: 
                      thetaj = thetai[j:j+nts][tsj]
                      if antialias == 'yes': thetaj = downsample(thetaj)
                      alltheta.append(thetaj); Ex_theta.append(thetaj)
                  iampa = gampaj*(Vmj-E_rev_AMPA)
                  inmda = gnmdaj*(Vmj-E_rev_NMDA)
                  igabaa = ggabaaj*(Vmj-E_rev_GABA_A)
                  igabab = ggababj*(Vmj-E_rev_GABA_B)
                  Ex_iampa.append(iampa); Ex_inmda.append(inmda)
                  Ex_igabaa.append(igabaa); Ex_igabab.append(igabab)
                  if ii < len(cEx[i]) and gid[j] == cEx[i][ii]:
                      cEx_Vm.append(Vmj); Ex_cells.append(cEx[i][ii])
                      if 'g_AMPA' in dosave: cEx_gampa.append(gampaj)
                      if 'g_NMDA' in dosave: cEx_gnmda.append(gnmdaj)
                      if 'g_GABA_A' in dosave: cEx_ggabaa.append(ggabaaj)
                      if 'g_GABA_B' in dosave: cEx_ggabab.append(ggababj)
                      if 'I_NaP' in dosave: cEx_inap.append(inapj)
                      if 'I_KNa' in dosave: cEx_ikna.append(iknaj)
                      if 'I_h' in dosave: cEx_ih.append(ihj)
                      if 'I_T' in dosave: cEx_it.append(itj)
                      if 'theta' in dosave: cEx_theta.append(thetaj)
                      ii = ii + 1
                  j = j + nts
                  ij = ij + 1
              dsd = nest.GetStatus(Ex_spikes[i])
              Ex_spikeid =  dsd[0]["events"]["senders"].tolist()
              Ex_spiket = dsd[0]["events"]["times"].tolist()
              nest.SetStatus(ExVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(Ex_spikes[i],{'n_events': 0})      #clear list for next simulation interval

          if nInVm[i] > 0:
              cd = nest.GetStatus(InVm[i])
              idi = np.argsort(cd[0]["events"]["senders"])
              gid = cd[0]["events"]["senders"][idi]
              Vmi = cd[0]["events"]["V_m"][idi]
              if 'g_AMPA' in dosave: gampai = cd[0]["events"]["g_AMPA"][idi]
              if 'g_NMDA' in dosave: gnmdai = cd[0]["events"]["g_NMDA"][idi]
              if 'g_GABA_A' in dosave: ggabaai = cd[0]["events"]["g_GABA_A"][idi]
              if 'g_GABA_B' in dosave: ggababi = cd[0]["events"]["g_GABA_B"][idi]
              if 'I_NaP' in dosave: inapi = -cd[0]["events"]["I_NaP"][idi]
              if 'I_KNa' in dosave: iknai = -cd[0]["events"]["I_KNa"][idi]
              if 'I_h' in dosave: ihi = -cd[0]["events"]["I_h"][idi]
              if 'I_T' in dosave: iti = -cd[0]["events"]["I_T"][idi]
              if 'theta' in dosave: thetai = cd[0]["events"]["theta"][idi]
              tsi = cd[0]["events"]["times"][idi]
              j = 0; ij = 0; ii = 0; In_cells = []
              while ij < nInVm[i]:
                  tsj = np.argsort(tsi[j:j+nts])
                  Vmj = Vmi[j:j+nts][tsj]
                  if antialias == 'yes': Vmj = downsample(Vmj)
                  allVm.append(Vmj); In_Vm.append(Vmj)
                  if 'g_AMPA' in dosave: 
                      gampaj = gampai[j:j+nts][tsj]
                      if antialias == 'yes': gampaj = downsample(gampaj)
                      allgampa.append(gampaj); In_gampa.append(gampaj)
                  if 'g_NMDA' in dosave: 
                      gnmdaj = gnmdai[j:j+nts][tsj]
                      if antialias == 'yes': gnmdaj = downsample(gnmdaj)
                      allgnmda.append(gnmdaj); In_gnmda.append(gnmdaj)
                  if 'g_GABA_A' in dosave: 
                      ggabaaj = ggabaai[j:j+nts][tsj]
                      if antialias == 'yes': ggabaaj = downsample(ggabaaj)
                      allggabaa.append(ggabaaj); In_ggabaa.append(ggabaaj)
                  if 'g_GABA_B' in dosave: 
                      ggababj = ggababi[j:j+nts][tsj]
                      if antialias == 'yes': ggababj = downsample(ggababj)
                      allggabab.append(ggababj); In_ggabab.append(ggababj)
                  if 'I_NaP' in dosave:
                      inapj = inapi[j:j+nts][tsj]
                      if antialias == 'yes': inapj = downsample(inapj)
                      allinap.append(inapj); In_inap.append(inapj)
                  if 'I_KNa' in dosave:
                      iknaj = iknai[j:j+nts][tsj]
                      if antialias == 'yes': iknaj = downsample(iknaj)
                      allikna.append(iknaj); In_ikna.append(iknaj)
                  if 'I_h' in dosave:
                      ihj = ihi[j:j+nts][tsj]
                      if antialias == 'yes': ihj = downsample(ihj)
                      allih.append(ihj); In_ih.append(ihj)
                  if 'I_T' in dosave:
                      itj = iti[j:j+nts][tsj]
                      if antialias == 'yes': itj = downsample(itj)
                      allit.append(itj); In_it.append(itj)
                  if 'theta' in dosave: 
                      thetaj = thetai[j:j+nts][tsj]
                      if antialias == 'yes': thetaj = downsample(thetaj)
                      alltheta.append(thetaj); In_theta.append(thetaj)
                  if ii < len(cIn[i]) and gid[j] == cIn[i][ii]:
                      cIn_Vm.append(Vmj); In_cells.append(cIn[i][ii])
                      if 'g_AMPA' in dosave: cIn_gampa.append(gampaj)
                      if 'g_NMDA' in dosave: cIn_gnmda.append(gnmdaj)
                      if 'g_GABA_A' in dosave: cIn_ggabaa.append(ggabaaj)
                      if 'g_GABA_B' in dosave: cIn_ggabab.append(ggababj)
                      if 'I_NaP' in dosave: cIn_inap.append(inapj)
                      if 'I_KNa' in dosave: cIn_ikna.append(iknaj)
                      if 'I_h' in dosave: cIn_ih.append(ihj)
                      if 'I_T' in dosave: cIn_it.append(itj)
                      if 'theta' in dosave: cIn_theta.append(thetaj)
                      ii = ii + 1
                  j = j + nts
                  ij = ij + 1
              dsd = nest.GetStatus(In_spikes[i])
              In_spikeid =  dsd[0]["events"]["senders"].tolist()
              In_spiket = dsd[0]["events"]["times"].tolist()
              nest.SetStatus(InVm[i],{'n_events': 0})       #clear list for next simulation interval
              nest.SetStatus(In_spikes[i],{'n_events': 0})      #clear list for next simulation interval

          #now save the data
          j = 0; n = len(ts); nf = nf0; iav = 0
          while j < n:
              iav = iav + 1; trp[0] = ts[j]; trp[1] = ts[j] 
              if iav == 1: tav0 = ts[j]; nf = nf + 1
              ijk = 0
              while ijk < len(dosave):
                  if dosave[ijk] == 'V_m': 
                          Ex_data = Ex_Vm
                          In_data = In_Vm
                          cEx_data = cEx_Vm
                          cIn_data = cIn_Vm
                          units = '(mV)'
                  if dosave[ijk] == 'g_AMPA': 
                          Ex_data = Ex_gampa
                          In_data = In_gampa
                          cEx_data = cEx_gampa
                          cIn_data = cIn_gampa
                          units = ''
                  if dosave[ijk] == 'g_NMDA': 
                          Ex_data = Ex_gnmda
                          In_data = In_gnmda
                          cEx_data = cEx_gnmda
                          cIn_data = cIn_gnmda
                          units = ''
                  if dosave[ijk] == 'g_GABA_A': 
                          Ex_data = Ex_ggabaa
                          In_data = In_ggabaa
                          cEx_data = cEx_ggabaa
                          cIn_data = cIn_ggabaa
                          units = ''
                  if dosave[ijk] == 'g_GABA_B': 
                          Ex_data = Ex_ggabab
                          In_data = In_ggabab
                          cEx_data = cEx_ggabab
                          cIn_data = cIn_ggabab
                          units = ''
                  if dosave[ijk] == 'I_NaP': 
                          Ex_data = Ex_inap
                          In_data = In_inap
                          cEx_data = cEx_inap
                          cIn_data = cIn_inap
                          units = '(mV)'
                  if dosave[ijk] == 'I_KNa': 
                          Ex_data = Ex_ikna
                          In_data = In_ikna
                          cEx_data = cEx_ikna
                          cIn_data = cIn_ikna
                          units = '(mV)'
                  if dosave[ijk] == 'I_h': 
                          Ex_data = Ex_ih
                          In_data = In_ih
                          cEx_data = cEx_ih
                          cIn_data = cIn_ih
                          units = '(mV)'
                  if dosave[ijk] == 'I_T': 
                          Ex_data = Ex_it
                          In_data = In_it
                          cEx_data = cEx_it
                          cIn_data = cIn_it
                          units = '(mV)'
                  if dosave[ijk] == 'theta': 
                          Ex_data = Ex_theta
                          In_data = In_theta
                          cEx_data = cEx_theta
                          cIn_data = cIn_theta
                          units = '(mV)'
                  nam = dosave[ijk].replace('_','')
                  if colnam[i][ijk] == 0:   #column headings not written yet so do so now
                      s = '%15s'%'time(ms)'
                      s = s + '%15s'%(nam+units) + '%15s'%('SD('+nam+')')
                      if nExVm[i] > 0: s = s + '%15s'%('Ex_'+nam+units) + '%15s'%('SD(Ex_'+nam+')')
                      if nInVm[i] > 0: s = s + '%15s'%('In_'+nam+units) + '%15s'%('SD(In_'+nam+')')
                      if nExVm[i] > 0:
                          k = 0
                          while k < nEx:
                              if 'L56' in layers[i] and doL56 > 0 and Ex_cells[k] in cIBs:
                                  s = s + '%15s'%('IB'+str(Ex_cells[k])+units)     #ids of chosen Exc cells
                              else:
                                  s = s + '%15s'%('Ex'+str(Ex_cells[k])+units)     #ids of chosen Exc cells
                              k = k + 1
                      if nInVm[i] > 0:
                          k = 0
                          while k < nIn:
                              s = s + '%15s'%('In'+str(In_cells[k])+units)     #ids of chosen Inh cells
                              k = k + 1
                      f[i][ijk].write(s+'\r')
                      colnam[i][ijk] = 1   #column headings now written
                  s = '%15.2f'%ts[j]
                  Exdata = []; Indata = []; Alldata = []
                  if nExVm[i] > 0:
                      k = 0
                      while k < nExVm[i]:
                          Alldata.append(Ex_data[k][j])
                          Exdata.append(Ex_data[k][j])
                          k = k + 1
                      medExdata = np.median(Exdata)
                      sdExdata = np.std(Exdata)
                  if nInVm[i] > 0:
                      k = 0
                      while k < nInVm[i]:
                          Alldata.append(In_data[k][j])
                          Indata.append(In_data[k][j])
                          k = k + 1
                      medIndata = np.median(Indata)
                      sdIndata = np.std(Indata)
                  medAlldata = np.median(Alldata)
                  sdAlldata = np.std(Alldata)
                  s = s + '%15.5e'%medAlldata + '%15.5e'%sdAlldata
                  if nExVm[i] > 0: s = s + '%15.5e'%medExdata + '%15.5e'%sdExdata
                  if nInVm[i] > 0: s = s + '%15.5e'%medIndata + '%15.5e'%sdIndata
                  if nExVm[i] > 0:
                      k = 0
                      while k < nEx:
                          s = s + '%15.5e'%cEx_data[k][j]    #data for chosen Exc cells
                          k = k + 1
                  if nInVm[i] > 0:                   #similarly for In
                      k = 0
                      while k < nIn:
                          s = s + '%15.5e'%cIn_data[k][j]    #Vm for chosen Inh cells
                          k = k + 1
                  f[i][ijk].write(s+'\r')
                  ijk = ijk + 1

              #write Exc Isyn sum for LFP
              if nExVm[i] > 0:
                 if ExIsynSumcol[i] == 0:
                     s = '%15s'%'time(ms)'
                     s = s + '%15s'%'I_AMPA(mV)'
                     s = s + '%15s'%'I_NMDA(mV)'
                     s = s + '%15s'%'I_GABAA(mV)'
                     s = s + '%15s'%'I_GABAB(mV)'
                     ExIsynSumf[i].write(s+'\r'); 
                     ExIsynSumcol[i] = 1
                 k = 0; I_AMPA = 0; I_NMDA = 0
                 I_GABAA = 0; I_GABAB = 0
                 while k < len(Ex_iampa):
                     I_AMPA = I_AMPA + Ex_iampa[k][j]
                     I_NMDA = I_NMDA + Ex_inmda[k][j]
                     I_GABAA = I_GABAA + Ex_igabaa[k][j]
                     I_GABAB = I_GABAB + Ex_igabab[k][j]
                     k = k + 1
                 s = '%15.2f'%ts[j]
                 s = s + '%15.5e'%I_AMPA
                 s = s + '%15.5e'%I_NMDA
                 s = s + '%15.5e'%I_GABAA
                 s = s + '%15.5e'%I_GABAB
                 ExIsynSumf[i].write(s+'\r')
    
              k = 0  #write topographic Vm data to file ftop
              while k < ntop:
                  if layers[i] in fntop[k]: break    #write topographic data for this layer
                  k = k + 1
              if k < ntop:
                    ijk = 0
                    while ijk < len(dotop):
                        if dotop[ijk] == 'V_m': 
                                all = allVm; topunits = '(mV)'
                        if dotop[ijk] == 'g_AMPA': 
                                all = allgampa; topunits = ''
                        if dotop[ijk] == 'g_NMDA': 
                                all = allgnmda; topunits = ''
                        if dotop[ijk] == 'g_GABA_A': 
                                all = allggabaa; topunits = ''
                        if dotop[ijk] == 'g_GABA_B': 
                                all = allggabab; topunits = ''
                        if dotop[ijk] == 'I_NaP':
                                all = allinap; topunits = '(mV)'
                        if dotop[ijk] == 'I_KNa':
                                all = allikna; topunits = '(mV)'
                        if dotop[ijk] == 'I_h':
                                all = allih; topunits = '(mV)'
                        if dotop[ijk] == 'I_T':
                                all = allit; topunits = '(mV)'
                        if dotop[ijk] == 'theta':
                                all = alltheta; topunits = '(mV)'

                        if topheader[k][ijk] == 0:   #file header not written yet so do so now
                          ftop[k][ijk].write(layers[i]+':  '+dotop[ijk].replace('_','')+topunits+'\r')
                          ftop[k][ijk].write('Rows: '+str(rows[i])+'\r')
                          ftop[k][ijk].write('Columns: '+str(cols[i])+'\r')
                          m = 0; s = ''
                          while m < nmods:     #elements contains the model names
                              s = s+' '+elements[i][m]
                              m = m + 1
                          ftop[k][ijk].write('Models; '+s+'\r')
                          ftop[k][ijk].write('Run time (ms): '+'%8.1f'%tstop+'\r')
                          ftop[k][ijk].write('Sampling interval (ms): '+'%8.1f'%(nav*dt)+'\r')
                          topheader[k][ijk] = 1   #file header now written
                        if iav == nav or j == n-1:
                          ftop[k][ijk].write('\r')
                          tav = 0.5*(ts[j] + tav0)
                          ftop[k][ijk].write('t = '+('%10.1f'%tav).ljust(10)+'\r')    #time
                        if nrast > 0 and rastheader[i] == 0:   #file header not written yet so do so now
                          frast[i].write(layers[i]+':  $V$ (mV) for the central '+str(nels)+' cells\r')
                          frast[i].write('Rows: '+str(r2-r1+1)+'\r')
                          frast[i].write('Columns: '+str(c2-c1+1)+'\r')
                          m = 0; s = ''
                          while m < nmods:     #elements contains the model names
                              s = s+' '+elements[i][m]
                              m = m + 1
                          frast[i].write('Models; '+s+'\r')
                          frast[i].write('time (ms): '+'%8.1f'%tstop+'\r')
                          frast[i].write('  dt (ms): '+'%8.1f'%(dt)+'\r')
                          rastheader[i] = 1   #file header now written
                    
                        m = 0   #save raster and topographic data
                        if nrast > 0:
                          frast[i].write('\r')
                          frast[i].write('t = '+('%10.1f'%ts[j]).ljust(10)+'\r')    #time
                        while m < nmods:                                #for each model type,
                          if (iav == nav or j == n-1) and k < len(savetop): ftop[k][ijk].write(elements[i][m]+'\r')    #iterate through the rows
                          if nrast > 0: frast[i].write(elements[i][m]+'\r')    #iterate through the rows
                          nrc = rows[i]*cols[i]; r = 1; ij = 0                           #and columns, writing the
                          while r <= rows[i]:                                    #the recorded Vm 
                              c = 1
                              while c <= cols[i]:
                                  el = m*nrc + (c - 1)*rows[i] + r - 1
                                  if nrast > 0 and r >= r1 and r <= r2 and c >= c1 and c <= c2:
                                      frast[i].write('%10.1f'%all[el][j])
                                      if c == c2: frast[i].write('\r')
                                  if k < len(savetop): 
                                      zav[ijk][m][r-1][c-1] = all[el][j] + zav[ijk][m][r-1][c-1]   #save sum to an array for the topograohic plot
                                      if (iav == nav or j == n-1) and k < len(savetop):
                                         ftop[k][ijk].write('%15.5e'%(zav[ijk][m][r-1][c-1]/iav))   #write mean column entries for row r at time ts[j]
                                  c = c + 1
                              if (iav == nav or j == n-1) and k < len(savetop): ftop[k][ijk].write('\r')
                              r = r + 1
                          m = m + 1
                        if (iav == nav or j == n-1): 
                           zav[ijk] = np.zeros((nmods,rows[i],cols[i]))
                        ijk = ijk + 1
              if (iav == nav or j == n-1): iav = 0
              j = j + 1

          #save dt-averaged layer firing rates
          if nExVm[i] > 0:
              frmult = 1000/(dt*nExVm[i])
              if colsExFR[i] == 0: #column headings not written yet so do so now
                   s = '%15s'%'time(ms)' + '%15s'%'ExFR(Hz)'
                   ExFRf[i].write(s+'\r'); colsExFR[i] = 1
              m = 0; count = 0; tsp0 = ts[0] 
              if len(np.array(Ex_spiket)) > 0:
                  tsp = np.sort(np.array(Ex_spiket) - t0) 
                  while m < len(tsp):
                      if tsp[m] <= tsp0:
                          count = count + 1
                      else:
                          s = '%15.1f'%(tsp0) + '%15.5e'%(frmult*count)
                          ExFRf[i].write(s+'\r')
                          tsp0 = tsp0 + dt
                          count = 0
                      m = m + 1
                  while tsp0 <= ts[len(ts)-1]:
                      s = '%15.1f'%(tsp0) + '%15.5e'%(0.0)
                      ExFRf[i].write(s+'\r')
                      tsp0 = tsp0 + dt
              else:
                  while m < len(ts):
                      s = '%15.1f'%(ts[m]) + '%15.5e'%(0.0)
                      ExFRf[i].write(s+'\r')
                      m = m + 1
          if nInVm[i] > 0:
              frmult = 1000/(dt*nInVm[i])
              if colsInFR[i] == 0: #column headings not written yet so do so now
                   s = '%15s'%'time(ms)' + '%15s'%'InFR(Hz)'
                   InFRf[i].write(s+'\r'); colsInFR[i] = 1
              m = 0; count = 0; tsp0 = ts[0] 
              if len(np.array(In_spiket)) > 0:
                  tsp = np.sort(np.array(In_spiket) - t0) 
                  while m < len(tsp):
                      if tsp[m] <= tsp0:
                          count = count + 1
                      else:
                          s = '%15.1f'%(tsp0) + '%15.5e'%(frmult*count)
                          InFRf[i].write(s+'\r')
                          tsp0 = tsp0 + dt
                          count = 0
                      m = m + 1
                  while tsp0 <= ts[len(ts)-1]:
                      s = '%15.1f'%(tsp0) + '%15.5e'%(0.0)
                      InFRf[i].write(s+'\r')
                      tsp0 = tsp0 + dt
              else:
                  while m < len(ts):
                      s = '%15.1f'%(ts[m]) + '%15.5e'%(0.0)
                      InFRf[i].write(s+'\r')
                      m = m + 1
                      
          #save spike times and accumulate spike counts; first the excitatory cells
          if colsExsp[i] == 0: #column headings not written yet so do so now
               s = '%15s'%'time(ms)' + '%15s'%'Ex_id' + '%15s'%'Ex#'
               if saveallspikes > 0: fspEx[i].write(s+'\r')
               if nExVm[i] > 0: fspExVm[i].write(s+'\r')
               colsExsp[i] = 1   #column headings now written
          nExsp[i] = len(Ex_spiket) + nExsp[i]
          m = 0
          while m < len(Ex_spiket):                              #absolute spike times
              tsp = Ex_spiket[m] - t0     #relative spike time
              s = '%15.1f'%(tsp)                #spike time
              s = s + '%15d'%Ex_spikeid[m]                #global id
              s = s + '%15d'%(Ex_spikeid[m]-minEX_id[i])    #rank
              if saveallspikes > 0: fspEx[i].write(s+'\r')
              if i < nlayers:
                  k = 0     #write spike times for the chosen Ex cells
                  while k < nEx:
                      if Ex_spikeid[m] == Ex_cells[k]: fspExVm[i].write(s+'\r')
                      k = k + 1
              m = m + 1

          if i < nlayers:          #similarly for inhibitory cells 
              if colsInsp[i] == 0 :
                   s = '%15s'%'time(ms)' + '%15s'%'In_id' + '%15s'%'In#'
                   if saveallspikes > 0: fspIn[i].write(s+'\r')
                   if nInVm[i] > 0: fspInVm[i].write(s+'\r')
                   colsInsp[i] = 1   #column headings now written
              nInsp[i] = len(In_spiket) + nInsp[i]
              m = 0
              while m < len(In_spiket):
                  tsp = In_spiket[m] - t0 
                  s = '%15.1f'%(tsp)
                  s = s + '%15d'%In_spikeid[m]
                  s = s + '%15d'%(In_spikeid[m]-minIn_id[i])
                  if saveallspikes > 0: fspIn[i].write(s+'\r')
                  k = 0     #write spike times for the chosen In cells
                  while k < nIn:
                      if In_spikeid[m] == In_cells[k]: fspInVm[i].write(s+'\r')
                      k = k + 1
                  m = m + 1
          i = i + 1
      nf0 = nf0 + nf
      t = t + simt
      

      print('Time = ', 0.001*t, 's')
      print('Time = ', 0.001*t, 's',file=printfile)
      simtime = time.time()-time0
      if t <= simt: dsimtime = 0.0; prevsimtime = 0.0
      if t > simt: dsimtime = simtime - prevsimtime
      prevsimtime = simtime
      ss = '%5.2f'%(dsimtime) + ' s'
      #if dsimtime > 60: ss = '%5.2f'%(dsimtime/60) + ' min'
      s = '%5.2f'%(simtime) + ' s'
      if simtime > 60:
          s = '%5.2f'%(simtime/60) + ' min'
          if simtime > 3600:
              s = '%5.2f'%(simtime/3600) + ' h'
      if t > simt: print(str(simt)+' ms run time = ' + ss)
      if t > simt: print(str(simt)+' ms run time = ' + ss,file=printfile)
      print('Run time = ' + s)
      print('Run time = ' + s,file=printfile)
  
      j = 1
      while j <= nt:   #calculate firing rates
          pooled_frates(j)
          frates(j)
          j = j + 1
      if doTMS != 0 and t >= tTMS and TMSdone == 0:
          ftms.write('%10.1f'%t+'\r')
          i = 0
          while i < nlayers:
              j = 0
              while j < len(TMStarget):
                  if layers[i] == TMStarget[j]:
                      nest.SetStatus(ExCells[i],{'V_m': -40.0})
                      if InTMS == 'yes': nest.SetStatus(InCells[i],{'V_m': -40.0})
                  j = j + 1
              i = i + 1
          TMSdone = 1
      if t >= tbreak[1] and len(simparav2) > 0 and donet2 == 0:
          i = 0; t_t2t1 = (t - tbreak[1])/(tbreak[2] - tbreak[1])
          while i < nlayers:    #set para values as appropriate
              nln = len(layernodes[i])
              status = nest.GetStatus((layernodes[i][0],))
              if 'Ex' in str(status): thetaEx[i] = status[0]['theta_eq']
              status = nest.GetStatus((layernodes[i][nln-1],))
              if 'In' in str(status): thetaIn[i] = status[0]['theta_eq']                   
              ip = 0
              while ip < len(simparan):
                  if layertext[ip] in layers[i] or layertext[ip] == '*':
                      if nt == 2 or t >= tbreak[2]:
                        paraval = simparav2[ip]; donet2 = 1
                      else:
                        paraval = simparav1[ip] + t_t2t1*(simparav2[ip]-simparav1[ip])
                      if 'T' in layers[i] and simparan[ip] == 'TEx_bomb_rate':
                          nest.SetStatus(Ex_bomb_pg[i], {'rate': paraval})
                      if 'L4' in layers[i] and simparan[ip] == 'CEx_bomb_rate':
                          nest.SetStatus(Ex_bomb_pg[i], {'rate': paraval})
                      if 'T' in layers[i] and simparan[ip] == 'TIn_bomb_rate':
                          nest.SetStatus(In_bomb_pg[i], {'rate': paraval})
                      if 'L4' in layers[i] and simparan[ip] == 'CIn_bomb_rate':
                          nest.SetStatus(In_bomb_pg[i], {'rate': paraval})
                      j = 0
                      while j < nln:
                          status = nest.GetStatus((layernodes[i][j],))
                          setburster = 0
                          if 'IB' in modeltext[ip]:
                              ib = 0
                              while ib < len(L56IB):
                                  if layernodes[i][j] in L56IB[ib]: 
                                      setburster = 1
                                      break
                                  ib = ib + 1
                          if modeltext[ip] in str(status[0]['model']) or modeltext[ip] == '*' or setburster == 1:
                            if simparan[ip] in str(status) and abs(status[0][simparan[ip]]) > simpara0[ip]:
                              if nt == 2 or t >= tbreak[2]:
                                paraval = simparav2[ip]; donet2 = 1
                                nest.SetStatus((layernodes[i][j],),{simparan[ip]: paraval}) 
                              else:
                                paraval = simparav1[ip] + t_t2t1*(simparav2[ip]-simparav1[ip])
                                nest.SetStatus((layernodes[i][j],),{simparan[ip]: paraval}) 
                          j = j + 1
                  ip = ip + 1
              i = i + 1                                                                             
    
  
  #calculate and save pooled firing rates
  CExbar = [0,0,0,0]; nCExbar = [0,0,0,0] 
  CInbar = [0,0,0,0]; nCInbar = [0,0,0,0]       
  ffrn = outdir+'/'+'Pooled_firing_rates.txt'
  ffr = open(ffrn, 'w')
  ffr.write('Overall mean firing rate (Hz)\r\r')
  
  ffr.write('Excitatory cells'.ljust(20)) 
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17))    #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  i = 0
  while i < nlayers:
      if nExcells[i] > 0:
          ffr.write(layers[i].ljust(20))
          j = 1         #write mean firing rates and accumulate data for grand mean rates
          while j <= nt:
              if 'C' in layers[i] and 'T' not in layers[i]: 
                  CExbar[j] = CExbar[j] + frateEx[j][i]
                  nCExbar[j] = nCExbar[j] + 1
              ffr.write((('%17.2f'%frateEx[j][i]).lstrip()).ljust(17))
              j = j + 1
          ffr.write('\r')
      i = i + 1

  ffr.write('\r')
  ffr.write('Inhibitory cells'.ljust(20))
  j = 1
  while j <= nt:
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17))   #time interval over which the rates are calculated
      j = j + 1
  ffr.write('\r')
  i = 0
  while i < nlayers:        
      if nIncells[i] > 0:
          ffr.write(layers[i].ljust(20))
          j = 1         #write mean firing rates and accumulate data for grand mean rates
          while j <= nt:
              if 'C' in layers[i] and 'T' not in layers[i]: 
                  CInbar[j] = CInbar[j] + frateIn[j][i]
                  nCInbar[j] = nCInbar[j] + 1
              ffr.write((('%17.2f'%frateIn[j][i]).lstrip()).ljust(17))
              j = j + 1
          ffr.write('\r')
      i = i + 1
  ffr.write('\r')
  
  j = 1                 #grand mean pooled firing rates:
  while j <= nt:
      ffr.write('\r')
      Deltat = ('%6.2f'%(0.001*tbreak[j-1])).lstrip()+'-'+('%6.2f'%(0.001*tbreak[j])).lstrip()+' s'
      ffr.write(Deltat.ljust(17)+'\r')
      CExbar[j] = CExbar[j]/nCExbar[j]
      ffr.write('Mean_C_Ex'.ljust(20))    
      ffr.write((('%17.2f'%CExbar[j]).lstrip()).ljust(17)+'\r')
      CInbar[j] = CInbar[j]/nCInbar[j]
      ffr.write('Mean_C_In'.ljust(20))    
      ffr.write((('%17.2f'%CInbar[j]).lstrip()).ljust(17)+'\r')
      j = j + 1
  ffr.close()
  
  
  #calculate and save Ex and In cellular firing rates
  if do_cell_firing_rates == 1:
      grandCExrate = [[],[],[],[]]; grandCInrateD = [[],[],[],[]]
      grandCInrate = [[],[],[],[]]; grandCExrateU = [[],[],[],[]]
      grandCExrateD = [[],[],[],[]]; grandCInrateU = [[],[],[],[]]
      layergrps = ['C_Ex', 'C_In']; ffr = []
      ffrn = outdir+'/'+'Ex_In_firing_rates.txt'
      ffr.append(open(ffrn, 'w'))
      ffrn = outdir+'/'+'Ex_In_firing_rates_stats.txt'
      ffr.append(open(ffrn, 'w')); j = 0
      while j < 2:
          ffr[j].write('Overall mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "", j,'Excitatory', nExcells, frateExcells, grandCExrate)
          save_firing_rates(ffr[j], "", j,'Inhibitory', nIncells, frateIncells, grandCInrate)
          ffr[j].write('Down state mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "D", j,'Excitatory', nExcells, frateExcellsD, grandCExrateD)
          save_firing_rates(ffr[j], "D", j,'Inhibitory', nIncells, frateIncellsD, grandCInrateD)
          ffr[j].write('Up state mean firing rates (Hz):\r')
          save_firing_rates(ffr[j], "U", j,'Excitatory', nExcells, frateExcellsU, grandCExrateU)
          save_firing_rates(ffr[j], "U", j,'Inhibitory', nIncells, frateIncellsU, grandCInrateU)
          ffr[j].write('Overall mean firing rates (Hz):\r')
          grandrates = [grandCExrate, grandCInrate]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].write('Down state mean firing rates (Hz):\r')
          grandrates = [grandCExrateD, grandCInrateD]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].write('Up state mean firing rates (Hz):\r')
          grandrates = [grandCExrateU, grandCInrateU]
          save_grand_firing_rates(ffr[j], j, layergrps, grandrates)
          ffr[j].close()
          j = j + 1
      if len(minipsps) > 0:
          print('\r'); j = 0
          print('Mean mini rates (Hz)\r')
          while j < nlayers:
            denom = (nExcells[j]+nIncells[j])*tbreak[nt]
            minirate.append(1000*minicount[j]/denom)
            print(layers[j]+': '+str(minirate[j])+'\r')
            j = j + 1 
          print('\r')
      
  
  #close files:
  i = 0
  while i < nlayers:
      if nrast > 0: frast[i].close()
      ExIsynSumf[i].close()
      ExFRf[i].close()
      InFRf[i].close()
      fspEx[i].close()
      fspExVm[i].close()
      fspIn[i].close()
      fspInVm[i].close()
      if do_cell_firing_rates == 1:
          fExtdu[i].close()
          fIntdu[i].close()
      i = i + 1
  i = 0
  while i < ntop:
      ijk = 0
      while ijk < len(dotop):
          ftop[i][ijk].close()
          ijk = ijk + 1
      i = i + 1
  i = 0
  while i < nlayers:
      ijk = 0
      while ijk < len(dosave):
          f[i][ijk].close()
          ijk = ijk + 1
      i = i + 1
      
  #LFP
  i = 0
  while i < nlayers:
      if nExVm[i] > 0:
         fin = open(ExIsynSumfn[i], 'r')
         l = fin.readlines(); fin.close()
         ts = []; RWS = []; DeltaIsyn = []; I_GABA = []; I_AMPA_NMDA = []
         nshift = int(tauLFP/dt); j = 1
         while j < len(l):
             v = l[j].split()
             ts.append(float(v[0]))
             I_AMPA_NMDA.append(float(v[1]) + float(v[2]))
             I_GABA.append(float(v[3]) + float(v[4]))
             j = j + 1
         ts = ts[nshift:len(ts)]
         I_Ex_shifted = np.array(I_AMPA_NMDA[0:len(I_AMPA_NMDA)-nshift])
         I_AMPA_NMDA = np.array(I_AMPA_NMDA[nshift:len(I_AMPA_NMDA)])
         I_GABA = -np.array(I_GABA[nshift:len(I_GABA)])
         RWS = I_Ex_shifted + alphaLFP*I_GABA
         DeltaIsyn = I_AMPA_NMDA + I_GABA
         j = 0; RWS0 = []; DeltaIsyn0 = []; I_GABA0 = []
         if doTMS > 0:
            while j < len(l):
                if ts[j] >= tbreak[1]: break
                RWS0.append(RWS[j])
                DeltaIsyn0.append(DeltaIsyn[j])
                I_GABA0.append(I_GABA[j])
                j = j + 1
            meanIGABA = np.mean(I_GABA0)
            meanRWS = np.mean(RWS0)
            meanDeltaIsyn = np.mean(DeltaIsyn0)
            I_GABA = I_GABA - meanIGABA                   
            RWS = RWS - meanRWS
            DeltaIsyn = DeltaIsyn - meanDeltaIsyn
         outdir = outdir0
         if nsims > 1: outdir = outdir0+'/output_'+fsim[isim-1] 
         fout = open(outdir+'/'+layers[i]+'/'+layers[i]+'_LFP.txt', 'w')
         s = '%15s'%'time(ms)'
         s = s + '%15s'%'RWS'
         s = s + '%15s'%'DeltaI'
         s = s + '%15s'%'-I_GABA'
         fout.write(s+'\r');
         j = 0
         while j < len(ts):
             s = '%15.2f'%ts[j]
             s = s + '%15.5e'%RWS[j]
             s = s + '%15.5e'%DeltaIsyn[j]
             s = s + '%15.5e'%I_GABA[j]
             fout.write(s+'\r')
             j = j + 1
         fout.close()
      i = i + 1      
  isim = isim + 1
if doTMS != 0: ftms.close()
printfile.close()

if compress == 'yes':
    os.system('tar -czf '+outdir0+'.tar.gz '+outdir0)
    shutil.rmtree(outdir0, ignore_errors=True)
    os.system('rm -r '+outdir0)
    
    